<?php
session_start();
require_once 'includes/db.php';

// Logout both admin and user
unset($_SESSION['user_id'], $_SESSION['user_name'], $_SESSION['user_email']);
unset($_SESSION['admin_id'], $_SESSION['admin_name']);
session_destroy();

if (isset($_GET['admin'])) {
    header("Location: admin/admin-login.php");
} else {
    header("Location: login.php");
}
exit();
?>
