<?php
session_start();
$base = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
$basePrefix = ($base === '' || $base === '.') ? '' : $base . '/';
$isLoggedIn = isset($_SESSION['user_id']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>NutriGold - Smart Diet Plan Management System</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<!-- ===== NAVBAR ===== -->
<nav class="navbar navbar-expand-lg">
  <div class="container">
    <a class="navbar-brand" href="index.php">
      <i class="fas fa-leaf me-2" style="color:var(--gold)"></i>NutriGold
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navMenu">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link active" href="#hero"><i class="fas fa-home"></i>Home</a></li>
        <li class="nav-item"><a class="nav-link" href="#features"><i class="fas fa-star"></i>Features</a></li>
        <li class="nav-item"><a class="nav-link" href="#diet-photos"><i class="fas fa-utensils"></i>Diet Plans</a></li>
        <li class="nav-item"><a class="nav-link" href="#contact"><i class="fas fa-envelope"></i>Contact</a></li>
      </ul>
      <div class="d-flex gap-3">
        <a href="login.php" class="btn-outline-gold btn">Login</a>
        <a href="register.php" class="btn-gold btn">Get Started Free</a>
      </div>
    </div>
  </div>
</nav>

<!-- ===== HERO SECTION ===== -->
<section class="hero-section" id="hero">
  <div class="container position-relative" style="z-index:2">
    <div class="row align-items-center min-vh-100 py-5">
      <div class="col-lg-6 animate__animated animate__fadeInLeft">
        <div class="badge-gold d-inline-block mb-4"><i class="fas fa-crown me-2"></i>AI-Powered Nutrition Platform</div>
        <h1 class="hero-title">
          Transform Your Health With <span class="gold-text">Smart</span> Diet Planning
        </h1>
        <p class="hero-subtitle">Personalized meal plans, real-time calorie tracking, BMI analysis, and AI-powered diet recommendations — all in one golden platform.</p>
        <div class="d-flex gap-3 flex-wrap">
          <a href="register.php" class="btn-gold btn btn-lg"><i class="fas fa-rocket me-2"></i>Start For Free</a>
          <a href="login.php" class="btn-outline-gold btn btn-lg"><i class="fas fa-play me-2"></i>View Demo</a>
        </div>
        <div class="hero-stats">
          <div class="hero-stat"><div class="num">10K+</div><div class="label">Users</div></div>
          <div class="hero-stat"><div class="num">500+</div><div class="label">Foods</div></div>
          <div class="hero-stat"><div class="num">98%</div><div class="label">Satisfaction</div></div>
          <div class="hero-stat"><div class="num">AI</div><div class="label">Powered</div></div>
        </div>
      </div>
      <div class="col-lg-6 mt-5 mt-lg-0 animate__animated animate__fadeInRight">
        <div class="position-relative">
          <!-- Dashboard Preview Card -->
          <div class="card-gold p-4" style="max-width:420px;margin:auto;border:2px solid var(--gold);">
            <div class="d-flex align-items-center gap-3 mb-4">
              <div style="width:50px;height:50px;background:var(--gold-gradient);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#000;font-size:1.3rem"><i class="fas fa-user"></i></div>
              <div><div style="font-weight:700">Welcome, Alex!</div><div class="text-muted-gold" style="font-size:0.82rem">Your health journey continues</div></div>
              <div class="ms-auto badge-gold">Member</div>
            </div>
            <!-- Stats Row -->
            <div class="row g-3 mb-4">
              <div class="col-6">
                <div style="background:var(--black-input);border:var(--border-gold);border-radius:10px;padding:14px;text-align:center">
                  <div style="font-size:1.5rem;font-weight:800;color:var(--gold)">2,150</div>
                  <div class="text-muted-gold" style="font-size:0.75rem">Daily Calories</div>
                </div>
              </div>
              <div class="col-6">
                <div style="background:var(--black-input);border:var(--border-gold);border-radius:10px;padding:14px;text-align:center">
                  <div style="font-size:1.5rem;font-weight:800;color:#17a2b8">2.1L</div>
                  <div class="text-muted-gold" style="font-size:0.75rem">Water Intake</div>
                </div>
              </div>
              <div class="col-6">
                <div style="background:var(--black-input);border:var(--border-gold);border-radius:10px;padding:14px;text-align:center">
                  <div style="font-size:1.5rem;font-weight:800;color:#28a745">22.5</div>
                  <div class="text-muted-gold" style="font-size:0.75rem">BMI (Normal)</div>
                </div>
              </div>
              <div class="col-6">
                <div style="background:var(--black-input);border:var(--border-gold);border-radius:10px;padding:14px;text-align:center">
                  <div style="font-size:1.5rem;font-weight:800;color:#ffc107">340</div>
                  <div class="text-muted-gold" style="font-size:0.75rem">Cal Burned</div>
                </div>
              </div>
            </div>
            <!-- Progress -->
            <div class="mb-3">
              <div class="d-flex justify-content-between mb-1">
                <small class="text-muted-gold">Calories Today</small>
                <small class="gold-text">1,650 / 2,000</small>
              </div>
              <div class="progress-gold">
                <div class="progress-bar" style="width:82%"></div>
              </div>
            </div>
            <div class="mb-0">
              <div class="d-flex justify-content-between mb-1">
                <small class="text-muted-gold">Water Goal</small>
                <small style="color:#17a2b8">2.1L / 2.5L</small>
              </div>
              <div class="progress-gold">
                <div class="progress-bar" style="width:84%;background:linear-gradient(135deg,#17a2b8,#0d6efd)"></div>
              </div>
            </div>
          </div>
          <a href="dashboard.php" class="d-inline-block text-decoration-none" style="position:absolute;bottom:-15px;left:10px;background:rgba(40,167,69,0.9);color:#fff;border-radius:12px;padding:8px 15px;font-size:0.8rem;font-weight:600;cursor:pointer;transition:opacity 0.2s" onmouseover="this.style.opacity='0.9'" onmouseout="this.style.opacity='1'" title="View your dashboard & goals">
            <i class="fas fa-check-circle me-1"></i>Goal on Track!
          </a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ===== FEATURES ===== -->
<section id="features" style="padding:80px 0;background:linear-gradient(180deg,#050505,#0a0a0a)">
  <div class="container">
    <div class="text-center mb-60">
      <div class="badge-gold mb-3">Complete Platform</div>
      <h2 style="font-size:2.2rem;font-weight:700">Everything You Need For <span class="gold-text">Healthy Living</span></h2>
      <p class="text-muted-gold mt-3 mx-auto" style="max-width:550px">Comprehensive diet management with AI-powered recommendations, tracking tools, and personalized insights.</p>
    </div>
    <div class="row g-4 mt-3">
      <?php
      $features = [
        ['fas fa-calculator','BMI Analysis','Calculate BMI, ideal weight, and get personalized calorie recommendations based on your body metrics.','bmi.php'],
        ['fas fa-brain','AI Diet Suggestions','Machine learning powered diet plans tailored to your age, gender, weight, and fitness goals.','diet.php'],
        ['fas fa-calendar-alt','Meal Planner','Plan your weekly meals with breakfast, lunch, dinner, and track your nutrition goals effortlessly.','mealplanner.php'],
        ['fas fa-chart-pie','Calorie Tracker','Track protein, carbs, and fat with beautiful charts. Daily, weekly, and monthly nutrition reports.','calories.php'],
        ['fas fa-tint','Water Tracker','Monitor daily hydration with smart reminders. Set goals and track your water intake easily.','water.php'],
        ['fas fa-comments','AI Chat Bot','24/7 nutrition chatbot for instant diet advice, recipe suggestions, and health tips.','chat.php'],
        ['fas fa-file-pdf','Report Export','Generate beautiful PDF/Excel reports for daily, weekly progress tracking and sharing with doctors.','report.php'],
      ];
      foreach($features as $f): ?>
      <div class="col-md-4 col-sm-6">
        <?php $featureHref = $isLoggedIn ? $f[3] : ('login.php?redirect=' . urlencode($f[3])); ?>
        <a href="<?= htmlspecialchars($featureHref) ?>" class="card-gold h-100 d-block text-decoration-none" style="cursor:pointer">
          <div class="mb-3" style="font-size:2rem;background:var(--gold-gradient);-webkit-background-clip:text;-webkit-text-fill-color:transparent"><i class="<?= $f[0] ?>"></i></div>
          <h5 style="color:var(--white);font-weight:700;margin-bottom:10px"><?= $f[1] ?></h5>
          <p class="text-muted-gold mb-0" style="font-size:0.88rem"><?= $f[2] ?></p>
        </a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ===== DIET PLAN PHOTOS SECTION ===== -->
<section id="diet-photos" style="padding:80px 0;background:#060606">
  <div class="container">
    <div class="text-center mb-5">
      <div class="badge-gold mb-3"><i class="fas fa-camera me-2"></i>Visual Diet Plans</div>
      <h2 style="font-size:2.2rem;font-weight:700">Click Any Food To See <span class="gold-text">Nutrition Details</span></h2>
      <p class="text-muted-gold mt-2">Interactive food cards with complete calorie, protein, carb, fat information and health benefits</p>
    </div>
    <div class="row g-4">
      <?php
      $foods = [
        ['Grilled Chicken Breast','165 cal / 100g','31g Protein','0g Carbs','3.6g Fat','Best for muscle building and weight loss. Lean protein source.','https://images.unsplash.com/photo-1604503468506-a8da13d82791?w=400','#28a745'],
        ['Brown Rice Bowl','216 cal / cup','5g Protein','45g Carbs','1.8g Fat','Complex carbohydrates for sustained energy. Controls blood sugar.','https://images.unsplash.com/photo-1516684732162-798a0062be99?w=400','#ffc107'],
        ['Salmon Fillet','208 cal / 100g','20g Protein','0g Carbs','13g Fat','Rich in Omega-3 fatty acids. Excellent for brain and heart health.','https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?w=400','#17a2b8'],
        ['Greek Yogurt','100 cal / 170g','17g Protein','6g Carbs','0.7g Fat','Probiotic powerhouse. Supports gut health and muscle recovery.','https://images.unsplash.com/photo-1571212515416-fef01fc43637?w=400','#e91e63'],
        ['Avocado','160 cal / 100g','2g Protein','9g Carbs','15g Fat','Loaded with healthy fats. Great for skin, heart and brain health.','https://images.unsplash.com/photo-1519162808019-7de1683fa2ad?w=400','#28a745'],
        ['Mixed Salad Bowl','85 cal / bowl','4g Protein','12g Carbs','2g Fat','Fiber-rich, antioxidant loaded. Perfect for weight loss plans.','https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=400','#ffc107'],
      ];
      foreach($foods as $i => $food): ?>
      <div class="col-lg-4 col-md-6">
        <div class="food-card" onclick="showFoodModal(<?= $i ?>)">
          <div style="position:relative;overflow:hidden">
            <img src="<?= $food[6] ?>" alt="<?= $food[0] ?>" loading="lazy">
            <div style="position:absolute;top:12px;right:12px;background:rgba(0,0,0,0.8);border:1px solid var(--gold);border-radius:20px;padding:4px 12px;font-size:0.8rem;font-weight:700;color:var(--gold)"><?= $food[1] ?></div>
            <div style="position:absolute;inset:0;background:linear-gradient(transparent 50%,rgba(0,0,0,0.9));display:flex;align-items:flex-end;padding:20px;opacity:0;transition:opacity 0.3s" class="food-hover-overlay">
              <div style="width:100%">
                <div class="d-flex gap-2 flex-wrap">
                  <span style="background:rgba(<?= $food[7] == '#28a745' ? '40,167,69' : ($food[7]=='#ffc107'?'255,193,7':($food[7]=='#17a2b8'?'23,162,184':'233,30,99')) ?>,0.3);border:1px solid <?= $food[7] ?>;color:<?= $food[7] ?>;padding:3px 10px;border-radius:20px;font-size:0.72rem"><?= $food[2] ?></span>
                  <span style="background:rgba(255,215,0,0.15);border:1px solid var(--gold);color:var(--gold);padding:3px 10px;border-radius:20px;font-size:0.72rem"><?= $food[3] ?></span>
                  <span style="background:rgba(255,255,255,0.1);border:1px solid rgba(255,255,255,0.2);color:#fff;padding:3px 10px;border-radius:20px;font-size:0.72rem"><?= $food[4] ?></span>
                </div>
              </div>
            </div>
          </div>
          <div class="food-card-body">
            <h5 class="food-card-title"><?= $food[0] ?></h5>
            <p class="text-muted-gold mb-3" style="font-size:0.82rem"><?= $food[5] ?></p>
            <div class="d-flex justify-content-between align-items-center">
              <span class="food-card-cal"><i class="fas fa-fire me-1"></i><?= $food[1] ?></span>
              <button class="btn btn-sm" style="background:rgba(255,215,0,0.1);border:1px solid rgba(255,215,0,0.3);color:var(--gold);border-radius:20px;font-size:0.78rem;padding:5px 14px"><i class="fas fa-info-circle me-1"></i>Details</button>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <div class="text-center mt-5">
      <a href="login.php" class="btn-gold btn btn-lg"><i class="fas fa-database me-2"></i>Explore Full Food Database (500+ Foods)</a>
    </div>
  </div>
</section>

<!-- Food Detail Modal -->
<div class="modal fade" id="foodModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-dark">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="fas fa-utensils me-2"></i><span id="modalFoodName"></span></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body p-0">
        <img id="modalFoodImg" src="" alt="" style="width:100%;height:220px;object-fit:cover">
        <div class="p-4">
          <div class="row g-3 mb-4">
            <div class="col-3 text-center">
              <div style="background:rgba(255,215,0,0.1);border:1px solid rgba(255,215,0,0.3);border-radius:10px;padding:14px">
                <div style="font-size:1.3rem;font-weight:800;color:var(--gold)" id="mCal">-</div>
                <div class="text-muted-gold" style="font-size:0.72rem">Calories</div>
              </div>
            </div>
            <div class="col-3 text-center">
              <div style="background:rgba(40,167,69,0.1);border:1px solid rgba(40,167,69,0.3);border-radius:10px;padding:14px">
                <div style="font-size:1.3rem;font-weight:800;color:#28a745" id="mProt">-</div>
                <div class="text-muted-gold" style="font-size:0.72rem">Protein</div>
              </div>
            </div>
            <div class="col-3 text-center">
              <div style="background:rgba(255,193,7,0.1);border:1px solid rgba(255,193,7,0.3);border-radius:10px;padding:14px">
                <div style="font-size:1.3rem;font-weight:800;color:#ffc107" id="mCarb">-</div>
                <div class="text-muted-gold" style="font-size:0.72rem">Carbs</div>
              </div>
            </div>
            <div class="col-3 text-center">
              <div style="background:rgba(23,162,184,0.1);border:1px solid rgba(23,162,184,0.3);border-radius:10px;padding:14px">
                <div style="font-size:1.3rem;font-weight:800;color:#17a2b8" id="mFat">-</div>
                <div class="text-muted-gold" style="font-size:0.72rem">Fat</div>
              </div>
            </div>
          </div>
          <div style="background:rgba(255,215,0,0.05);border:var(--border-gold);border-radius:10px;padding:15px">
            <h6 class="gold-text mb-2"><i class="fas fa-leaf me-2"></i>Health Benefits</h6>
            <p class="text-muted-gold mb-0" style="font-size:0.88rem" id="mBenefits">-</p>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <a href="login.php" class="btn-gold btn"><i class="fas fa-plus me-2"></i>Add to Meal Plan</a>
      </div>
    </div>
  </div>
</div>

<!-- (Premium pricing section removed) -->

<!-- ===== CONTACT / FOOTER ===== -->
<section id="contact" style="padding:80px 0;background:#050505">
  <div class="container">
    <div class="row g-5">
      <div class="col-md-6">
        <h2 style="font-weight:700;margin-bottom:20px">Get In <span class="gold-text">Touch</span></h2>
        <p class="text-muted-gold mb-4">Have questions? We're here to help you on your health journey.</p>
        <form action="feedback.php" method="POST">
          <div class="row g-3">
            <div class="col-6"><input type="text" name="name" class="form-control" placeholder="Your Name" required></div>
            <div class="col-6"><input type="email" name="email" class="form-control" placeholder="Email Address" required></div>
            <div class="col-12"><input type="text" name="subject" class="form-control" placeholder="Subject"></div>
            <div class="col-12"><textarea name="message" class="form-control" rows="4" placeholder="Your Message" required></textarea></div>
            <div class="col-12"><button type="submit" class="btn-gold btn w-100"><i class="fas fa-paper-plane me-2"></i>Send Message</button></div>
          </div>
        </form>
      </div>
      <div class="col-md-6">
        <h3 class="gold-text mb-4">Quick Links</h3>
        <div class="row">
          <div class="col-6">
            <ul class="footer-links">
              <?php foreach([['register.php','Register Free'],['login.php','Login'],['dashboard.php','Dashboard'],['bmi.php','BMI Calculator'],['mealplanner.php','Meal Planner']] as $l): ?>
              <li><a href="<?=$l[0]?>"><i class="fas fa-chevron-right me-2" style="color:var(--gold);font-size:0.7rem"></i><?=$l[1]?></a></li>
              <?php endforeach; ?>
            </ul>
          </div>
          <div class="col-6">
            <ul class="footer-links">
              <?php foreach([['calories.php','Calorie Tracker'],['water.php','Water Tracker'],['report.php','Reports'],['admin/admin-login.php','Admin Panel']] as $l): ?>
              <li><a href="<?=$l[0]?>"><i class="fas fa-chevron-right me-2" style="color:var(--gold);font-size:0.7rem"></i><?=$l[1]?></a></li>
              <?php endforeach; ?>
            </ul>
          </div>
        </div>
        <div class="mt-4 p-4" style="background:var(--black-card);border:var(--border-gold);border-radius:var(--radius)">
          <h6 class="gold-text"><i class="fas fa-envelope me-2"></i>Contact Us</h6>
          <p class="text-muted-gold mb-1" style="font-size:0.88rem">admin@nutrigold.com</p>
          <p class="text-muted-gold mb-0" style="font-size:0.88rem">+1 (555) 123-4567</p>
          <div class="d-flex gap-3 mt-3">
            <?php foreach(['facebook-f','twitter','instagram','youtube'] as $s): ?>
            <a href="#" style="width:36px;height:36px;background:rgba(255,215,0,0.1);border:var(--border-gold);border-radius:50%;display:flex;align-items:center;justify-content:center;color:var(--gold);transition:var(--transition)" onmouseover="this.style.background='var(--gold)';this.style.color='#000'" onmouseout="this.style.background='rgba(255,215,0,0.1)';this.style.color='var(--gold)'"><i class="fab fa-<?=$s?>"></i></a>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<footer class="footer">
  <div class="container">
    <div class="footer-bottom">
      
    </div>
  </div>
</footer>

<!-- Calorie Notification Toast -->
<div class="position-fixed bottom-0 end-0 p-3" style="z-index:1080">
  <div id="calorieToast" class="toast align-items-center text-bg-dark border-0" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="d-flex">
      <div class="toast-body" id="calorieToastBody">
        <!-- Filled dynamically -->
      </div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
const foodData = <?php
echo json_encode(array_map(function($f) {
    return ['name'=>$f[0],'cal'=>$f[1],'protein'=>$f[2],'carbs'=>$f[3],'fat'=>$f[4],'benefits'=>$f[5],'img'=>$f[6]];
}, $foods));
?>;

function showFoodModal(i) {
    const f = foodData[i];
    document.getElementById('modalFoodName').textContent = f.name;
    document.getElementById('modalFoodImg').src = f.img;
    document.getElementById('mCal').textContent = f.cal;
    document.getElementById('mProt').textContent = f.protein;
    document.getElementById('mCarb').textContent = f.carbs;
    document.getElementById('mFat').textContent = f.fat;
    document.getElementById('mBenefits').textContent = f.benefits;
    new bootstrap.Modal(document.getElementById('foodModal')).show();
}

const BASE_PATH = '<?= addslashes($basePrefix) ?>';

/**
 * Show a single daily notification when today's calories are over goal.
 * Reads values from localStorage so other pages (like dashboard/calories.php)
 * can update: NUTRIGOLD_TODAY_CALORIES and NUTRIGOLD_GOAL_CALORIES.
 */
function showCalorieNotification(currentCalories, goalCalories) {
    if (!window.bootstrap) return;
    if (!currentCalories || currentCalories <= 0) return;

    const toastBody = document.getElementById('calorieToastBody');
    const toastEl   = document.getElementById('calorieToast');
    if (!toastBody || !toastEl) return;

    const goal = goalCalories && goalCalories > 0 ? goalCalories : 2000;
    const overGoal = currentCalories - goal;

    let statusLine;
    if (overGoal > 0) {
        statusLine = `You are ${overGoal} kcal over your daily goal of ${goal} kcal.`;
    } else {
        statusLine = `You have consumed ${currentCalories} kcal of your daily goal ${goal} kcal.`;
    }

    // Simple activity suggestions (approximate)
    const extraToBurn = Math.max(overGoal, 100); // ensure meaningful suggestion
    const walkMinutes = Math.max(10, Math.round(extraToBurn / 5));   // ~5 kcal/min walking
    const hiitMinutes = Math.max(5, Math.round(extraToBurn / 10));   // ~10 kcal/min HIIT

    const burnSuggestions = [
        `• ${walkMinutes} min brisk walk or light jog`,
        `• ${hiitMinutes} min home HIIT (jumping jacks, squats, mountain climbers)`,
        `• 15–20 min cycling or skipping rope`
    ].join('<br>');

    const preWorkoutTip = `Pre‑workout idea: 1 banana + black coffee or green tea 30 minutes before workout for clean energy.`;

    toastBody.innerHTML = `
        <div class="mb-1"><strong><i class="fas fa-fire me-1"></i>Calorie Update</strong></div>
        <div style="font-size:0.9rem;margin-bottom:6px">${statusLine}</div>
        <div style="font-size:0.85rem;margin-bottom:6px">
          <strong>How to burn it:</strong><br>${burnSuggestions}
        </div>
        <div style="font-size:0.8rem;color:#ffc107">${preWorkoutTip}</div>
    `;

    const toast = bootstrap.Toast.getOrCreateInstance(toastEl, { delay: 12000 });
    toast.show();
}

function checkCalorieNotification() {
    try {
        const current = parseInt(localStorage.getItem('NUTRIGOLD_TODAY_CALORIES') || '0', 10);
        const goal    = parseInt(localStorage.getItem('NUTRIGOLD_GOAL_CALORIES') || '0', 10);
        if (!current || current <= 0 || !goal || goal <= 0) return;

        const today   = new Date().toISOString().slice(0,10);
        const alertedDate = localStorage.getItem('NUTRIGOLD_CAL_ALERT_DATE');

        // Only one toast per day
        if (alertedDate === today) return;

        if (current > goal) {
            showCalorieNotification(current, goal);
            localStorage.setItem('NUTRIGOLD_CAL_ALERT_DATE', today);
        }
    } catch (e) {
        // Fail silently if localStorage not available
    }
}

document.addEventListener('DOMContentLoaded', checkCalorieNotification);

// Food card hover overlay
document.querySelectorAll('.food-card').forEach(card => {
    const overlay = card.querySelector('.food-hover-overlay');
    if(overlay) {
        card.addEventListener('mouseenter', () => overlay.style.opacity = '1');
        card.addEventListener('mouseleave', () => overlay.style.opacity = '0');
    }
});

// Animate on scroll
const observer = new IntersectionObserver((entries) => {
    entries.forEach(e => {
        if(e.isIntersecting) e.target.classList.add('animate-in');
    });
}, { threshold: 0.1 });
document.querySelectorAll('.card-gold, .plan-card, .food-card').forEach(el => observer.observe(el));
</script>
</body>
</html>
