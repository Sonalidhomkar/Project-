# Diet Plan Management System (NutriGold) — Project Report

## 1) Abstract
NutriGold is a diet and health management web application built using PHP and MySQL. The system helps users plan meals, track daily calorie and water intake, calculate BMI, view progress reports, and interact with a nutrition assistant (NutriBot). An admin panel supports management of users, foods, and feedback, and provides analytics dashboards.

## 2) Problem Statement
Many users struggle to maintain consistent healthy habits due to lack of tracking and structured planning. This project provides a centralized platform to plan meals and track essential health metrics with a simple UI and role-based access.

## 3) Objectives
- Provide secure user registration and login.
- Enable meal planning and calorie tracking.
- Track water intake and BMI history.
- Generate diet recommendations based on goals.
- Store chat interactions for user support.
- Provide admin control over users, foods, and feedback.

## 4) Scope
### Included
- User dashboard with charts and summaries
- Meal planner + food database
- Calorie, water, BMI tracking
- Reports and feedback module
- Admin panel

### Not Included (Future scope)
- Real AI model integration
- Mobile app
- Advanced personalization using ML

## 5) Technologies Used
- **Frontend**: HTML, CSS, Bootstrap 5, Font Awesome, Chart.js
- **Backend**: PHP (server-rendered)
- **Database**: MySQL (XAMPP)
- **Auth**: PHP sessions

## 6) System Architecture
### High-level architecture
- Presentation layer: PHP pages + Bootstrap UI
- Business layer: PHP logic in pages and common functions in `includes/`
- Data layer: MySQL database `dietplan_db`

### Key folders
- `includes/`: DB connection, layout, schema
- `admin/`: admin pages
- `api/`: AJAX endpoints (chat, payment)

## 7) Modules Description
### 7.1 User Module
- Registration/Login/Logout
- Dashboard
- Meal planner
- Calories tracker
- Water tracker
- BMI calculator
- Diet plan generator
- Food database viewer
- Reports
- Chat page + widget
- Feedback

### 7.2 Admin Module
- Admin login
- Admin dashboard (stats + charts)
- Manage users
- Manage food items
- View system reports
- Handle feedback

## 8) Database Design
### Main Entities (Tables)
- `users`: user account + profile + flags (premium/active)
- `admins`: admin accounts
- `foods`: nutrition database
- `meal_plans`: user meals by date and meal type
- `water_intake`: water logs
- `bmi_records`: BMI history
- `diet_recommendations`: generated plans stored by date
- `chat_messages`: user/bot messages stored
- `feedback`: feedback messages and status
- `notifications`: user notifications
- `payments`: premium plan payments
- `user_goals`: calorie/water/steps goals

### Relationships (Examples)
- `users (1) -> (M) meal_plans`
- `users (1) -> (M) water_intake`
- `users (1) -> (M) bmi_records`
- `users (1) -> (M) chat_messages`
- `users (1) -> (M) feedback`

## 9) DFD (Data Flow Diagram)
### Context Diagram (Level-0)
- External entities: User, Admin
- System: Diet Plan Management System
- Data store: MySQL database

### DFD Level-1 (Processes)
- Auth
- Dashboard & Goals
- Meal planning
- Tracking (calories/water/BMI)
- Diet recommendations
- Chat
- Feedback
- Admin management (users/foods/reports)

> You can copy the mermaid diagrams from the separate `PPT_OUTLINE.md` section “Diagrams”.

## 10) Testing
### Sample Test Cases
- **Login**: Valid credentials should redirect to dashboard; invalid should show error.
- **Meal plan insert**: Adding a meal creates a row in `meal_plans`.
- **Water log**: Adding intake updates daily total.
- **BMI**: BMI calculation stores record in `bmi_records`.
- **Admin access**: Non-admin cannot access `admin/*` pages.
- **Chat logging**: Sending chat saves messages in `chat_messages`.

## 11) Results / Output
- Users can manage daily diet activities and view summaries in dashboard.
- Admin can monitor system usage and control master data like foods.

## 12) Conclusion
NutriGold provides a complete diet planning and tracking platform using PHP and MySQL with a modern UI. The system is suitable for small-scale deployment and can be enhanced further with real AI and stronger security hardening.

## 13) Future Enhancements
- Prepared statements across all queries
- CSRF protection, rate limiting
- Real AI chatbot integration
- Better reports (weekly/monthly PDFs)
- Notifications scheduling (cron jobs)

