<?php
require_once 'includes/header.php';

// ---- Handle Add Water ----
if (isset($_POST['add_water'])) {
    $amount = (float)$_POST['amount'];
    $time   = date('H:i:s');
    if ($amount > 0) {
        $conn->query("INSERT INTO water_intake (user_id,intake_date,amount_ml,time_logged) VALUES ($uid,'$today',$amount,'$time')");
        $conn->query("INSERT INTO notifications (user_id,message,type) VALUES ($uid,'💧 Logged {$amount}ml of water!','water')");
    }
    redirect('water.php');
}

// ---- Handle delete ----
if (isset($_GET['delete'])) {
    $did = (int)$_GET['delete'];
    $conn->query("DELETE FROM water_intake WHERE id=$did AND user_id=$uid");
    redirect('water.php');
}

// ---- Handle update goal ----
if (isset($_POST['update_goal'])) {
    $newGoal = (int)$_POST['water_goal'];
    $exists  = $conn->query("SELECT id FROM user_goals WHERE user_id=$uid")->num_rows;
    if ($exists)
        $conn->query("UPDATE user_goals SET daily_water_goal=$newGoal WHERE user_id=$uid");
    else
        $conn->query("INSERT INTO user_goals (user_id,daily_water_goal) VALUES ($uid,$newGoal)");
    redirect('water.php');
}

// ---- Data ----
$waterToday = $conn->query("SELECT * FROM water_intake WHERE user_id=$uid AND intake_date='$today' ORDER BY time_logged");
$totalToday = $conn->query("SELECT COALESCE(SUM(amount_ml),0) as t FROM water_intake WHERE user_id=$uid AND intake_date='$today'")->fetch_assoc()['t'];

$goalsRes  = $conn->query("SELECT daily_water_goal FROM user_goals WHERE user_id=$uid");
$waterGoal = $goalsRes->num_rows ? $goalsRes->fetch_assoc()['daily_water_goal'] : 2500;
$pct       = $waterGoal > 0 ? min(100, round($totalToday / $waterGoal * 100)) : 0;

// Weekly water data
$weekData=[]; $weekLbl=[];
for($i=6;$i>=0;$i--) {
    $d   = date('Y-m-d',strtotime("-$i days"));
    $r   = $conn->query("SELECT COALESCE(SUM(amount_ml),0) as t FROM water_intake WHERE user_id=$uid AND intake_date='$d'")->fetch_assoc();
    $weekData[] = round($r['t']);
    $weekLbl[]  = date('D',strtotime("-$i days"));
}
?>

<div class="page-header">
  <h2><i class="fas fa-tint me-3" style="color:#17a2b8"></i>Water Intake Tracker</h2>
  <p>Track your daily hydration and stay healthy</p>
</div>

<div class="row g-4">
  <!-- Left: Today's tracker -->
  <div class="col-lg-4">
    <div class="card-gold text-center mb-4">
      <div class="section-title justify-content-center"><i class="fas fa-tint me-2" style="color:#17a2b8"></i>Today's Hydration</div>

      <!-- Big circle progress -->
      <div style="position:relative;width:180px;height:180px;margin:0 auto 20px">
        <svg width="180" height="180" style="transform:rotate(-90deg)">
          <circle cx="90" cy="90" r="75" fill="none" stroke="rgba(23,162,184,0.15)" stroke-width="12"/>
          <circle cx="90" cy="90" r="75" fill="none" stroke="#17a2b8" stroke-width="12"
                  stroke-dasharray="<?= round(471 * $pct / 100) ?> 471"
                  stroke-linecap="round" style="transition:stroke-dasharray 1s ease"/>
        </svg>
        <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center">
          <div style="font-size:1.8rem;font-weight:800;color:#17a2b8"><?= round($totalToday/1000,1) ?>L</div>
          <div class="text-muted-gold" style="font-size:0.75rem"><?= $pct ?>% of goal</div>
        </div>
      </div>

      <div class="d-flex justify-content-around mb-4">
        <div><div style="font-weight:700;color:#17a2b8"><?= round($totalToday) ?>ml</div><div class="text-muted-gold" style="font-size:0.75rem">Consumed</div></div>
        <div><div style="font-weight:700;color:var(--gold)"><?= $waterGoal ?>ml</div><div class="text-muted-gold" style="font-size:0.75rem">Daily Goal</div></div>
        <div><div style="font-weight:700;color:#28a745"><?= max(0,$waterGoal-$totalToday) ?>ml</div><div class="text-muted-gold" style="font-size:0.75rem">Remaining</div></div>
      </div>

      <!-- Quick Add Buttons -->
      <div class="section-title justify-content-center"><i class="fas fa-plus me-2"></i>Quick Add</div>
      <div class="d-flex flex-wrap gap-2 justify-content-center mb-3">
        <?php foreach([150,250,350,500,750,1000] as $ml): ?>
        <form method="POST" style="display:inline">
          <input type="hidden" name="amount" value="<?=$ml?>">
          <button type="submit" name="add_water" class="btn btn-sm" style="background:rgba(23,162,184,0.15);border:1px solid rgba(23,162,184,0.4);color:#17a2b8;border-radius:20px;font-size:0.8rem;padding:6px 14px;transition:all 0.3s" onmouseover="this.style.background='rgba(23,162,184,0.3)'" onmouseout="this.style.background='rgba(23,162,184,0.15)'">
            <i class="fas fa-tint me-1"></i><?=$ml?>ml
          </button>
        </form>
        <?php endforeach; ?>
      </div>

      <!-- Custom Amount -->
      <form method="POST" class="d-flex gap-2">
        <input type="number" name="amount" class="form-control" placeholder="Custom ml" min="1" max="2000" required style="border-color:rgba(23,162,184,0.4)">
        <button type="submit" name="add_water" class="btn" style="background:linear-gradient(135deg,#17a2b8,#0d6efd);color:#fff;border:none;border-radius:8px;padding:0 16px;white-space:nowrap"><i class="fas fa-plus"></i></button>
      </form>
    </div>

    <!-- Update Goal -->
    <div class="card-gold">
      <div class="section-title"><i class="fas fa-cog me-2"></i>Set Daily Goal</div>
      <form method="POST">
        <div class="input-group">
          <input type="number" name="water_goal" class="form-control" value="<?=$waterGoal?>" min="500" max="5000" step="100">
          <span class="input-group-text">ml</span>
        </div>
        <button type="submit" name="update_goal" class="btn-gold btn w-100 mt-3"><i class="fas fa-save me-2"></i>Update Goal</button>
      </form>
      <div class="mt-3" style="font-size:0.8rem;color:var(--gray-text)">
        <i class="fas fa-info-circle me-2" style="color:var(--gold)"></i>Recommended: 2500ml/day. Increase by 500ml for every 30 min of exercise.
      </div>
    </div>
  </div>

  <!-- Right: Log + Charts -->
  <div class="col-lg-8">
    <!-- Weekly Chart -->
    <div class="chart-container mb-4">
      <div class="section-title"><i class="fas fa-chart-bar me-2"></i>Weekly Water Intake</div>
      <canvas id="waterWeekChart" height="80"></canvas>
    </div>

    <!-- Today's Log -->
    <div class="card-gold">
      <div class="section-title"><i class="fas fa-list me-2"></i>Today's Water Log</div>
      <?php if($waterToday->num_rows > 0): ?>
      <div class="table-responsive">
        <table class="table-dark-gold w-100">
          <thead><tr><th>#</th><th>Amount</th><th>Time</th><th>Action</th></tr></thead>
          <tbody>
          <?php $i=1; while($w=$waterToday->fetch_assoc()): ?>
          <tr>
            <td><?=$i++?></td>
            <td>
              <div class="d-flex align-items-center gap-2">
                <i class="fas fa-tint" style="color:#17a2b8"></i>
                <span style="font-weight:600;color:#17a2b8"><?=$w['amount_ml']?>ml</span>
                <span class="text-muted-gold">(<?= round($w['amount_ml']/1000,2) ?>L)</span>
              </div>
            </td>
            <td class="text-muted-gold"><?= $w['time_logged'] ? date('g:i A',strtotime($w['time_logged'])) : '-' ?></td>
            <td><a href="water.php?delete=<?=$w['id']?>" onclick="return confirm('Delete?')" class="btn btn-sm" style="background:rgba(220,53,69,0.1);border:1px solid rgba(220,53,69,0.3);color:#dc3545;border-radius:6px"><i class="fas fa-trash"></i></a></td>
          </tr>
          <?php endwhile; ?>
          </tbody>
          <tfoot>
            <tr style="background:rgba(255,215,0,0.05)">
              <td colspan="2" style="padding:14px 18px;font-weight:700;color:var(--gold)">Total Today</td>
              <td colspan="2" style="padding:14px 18px;font-weight:700;color:#17a2b8"><?=round($totalToday)?>ml = <?=round($totalToday/1000,2)?>L</td>
            </tr>
          </tfoot>
        </table>
      </div>
      <?php else: ?>
      <div class="text-center py-4">
        <div style="font-size:3rem;margin-bottom:10px">💧</div>
        <p class="text-muted-gold">No water logged today. Start hydrating!</p>
      </div>
      <?php endif; ?>
    </div>

    <!-- Hydration Tips -->
    <div class="row g-3 mt-1">
      <?php
      $tips = [
        ['fas fa-clock','Morning Habit','Drink 500ml of water right after waking up to kickstart metabolism.','#17a2b8'],
        ['fas fa-utensils','Before Meals','Drink 250ml before each meal to aid digestion and reduce overeating.','#28a745'],
        ['fas fa-dumbbell','Exercise','Add 500ml for every 30 minutes of moderate exercise.','#ffc107'],
        ['fas fa-moon','Before Bed','Drink 200ml before bed — but not too much to avoid night interruptions.','#e91e63'],
      ];
      foreach($tips as $t): ?>
      <div class="col-md-6">
        <div style="background:var(--black-card);border:var(--border-gold);border-radius:var(--radius-sm);padding:14px;display:flex;gap:12px;align-items:flex-start">
          <i class="<?=$t[0]?>" style="color:<?=$t[3]?>;font-size:1.2rem;margin-top:2px"></i>
          <div><div style="font-weight:600;font-size:0.88rem"><?=$t[1]?></div><div class="text-muted-gold" style="font-size:0.78rem"><?=$t[2]?></div></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<script>
new Chart(document.getElementById('waterWeekChart'),{
    type:'bar',
    data:{
        labels:<?=json_encode($weekLbl)?>,
        datasets:[{
            label:'Water (ml)',
            data:<?=json_encode($weekData)?>,
            backgroundColor:'rgba(23,162,184,0.35)',
            borderColor:'#17a2b8',
            borderWidth:2,borderRadius:8
        },{
            label:'Goal (<?=$waterGoal?>ml)',
            data:Array(7).fill(<?=$waterGoal?>),
            type:'line',borderColor:'rgba(255,215,0,0.6)',borderDash:[5,5],borderWidth:2,pointRadius:0,fill:false
        }]
    },
    options:{responsive:true,plugins:{legend:{labels:{color:'#aaa'}}},scales:{y:{grid:{color:'rgba(255,215,0,0.05)'},ticks:{color:'#aaa'}},x:{grid:{display:false},ticks:{color:'#aaa'}}}}
});
</script>

<?php require_once 'includes/footer.php'; ?>
