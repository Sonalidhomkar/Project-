<?php
require_once 'includes/header.php';

// ---- Handle Add/Edit/Delete meal plan ----
if (isset($_POST['save_plan'])) {
    $plan_date = sanitize($conn, $_POST['plan_date']);
    $meal_type = sanitize($conn, $_POST['meal_type']);
    $food_id   = (int)$_POST['food_id'];
    $quantity  = (float)$_POST['quantity'];
    $notes     = sanitize($conn, $_POST['notes'] ?? '');

    $food = $conn->query("SELECT * FROM foods WHERE id=$food_id")->fetch_assoc();
    $calories = $food ? round($food['calories'] * $quantity) : 0;

    $result = $conn->query("INSERT INTO meal_plans (user_id,plan_date,meal_type,food_id,quantity,calories,notes) VALUES ($uid,'$plan_date','$meal_type',$food_id,$quantity,$calories,'$notes')");
    if (!$result) {
        die("Insert failed: " . $conn->error);
    }
    redirect('mealplanner.php');
}

if (isset($_GET['delete'])) {
    $conn->query("DELETE FROM meal_plans WHERE id=".(int)$_GET['delete']." AND user_id=$uid");
    redirect('mealplanner.php');
}

if (isset($_GET['favorite'])) {
    $conn->query("UPDATE meal_plans SET is_favorite=1-is_favorite WHERE id=".(int)$_GET['favorite']." AND user_id=$uid");
    redirect('mealplanner.php');
}

// ---- Week dates ----
$weekStart = isset($_GET['week']) ? $_GET['week'] : date('Y-m-d', strtotime('Monday this week'));
$weekDays = [];
for($i=0;$i<7;$i++) {
    $d = date('Y-m-d', strtotime("$weekStart +$i days"));
    $weekDays[$d] = date('D, M j', strtotime($d));
}
$prevWeek = date('Y-m-d', strtotime("$weekStart -7 days"));
$nextWeek = date('Y-m-d', strtotime("$weekStart +7 days"));

// ---- Fetch this week's meals ----
$weekEnd = date('Y-m-d', strtotime("$weekStart +6 days"));
$meals = $conn->query("SELECT mp.*,f.name as food_name,f.protein,f.carbs,f.fat FROM meal_plans mp LEFT JOIN foods f ON mp.food_id=f.id WHERE mp.user_id=$uid AND mp.plan_date BETWEEN '$weekStart' AND '$weekEnd' ORDER BY mp.plan_date,FIELD(mp.meal_type,'breakfast','lunch','dinner','snack')");

$planData = [];
while($m = $meals->fetch_assoc()) {
    $planData[$m['plan_date']][$m['meal_type']][] = $m;
}

$foods = $conn->query("SELECT id,name,calories,protein,carbs,fat FROM foods ORDER BY name");
$foodList=[];
while($f=$foods->fetch_assoc()) $foodList[]=$f;
?>

<div class="page-header">
  <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
    <div>
      <h2><i class="fas fa-calendar-alt me-3"></i>Weekly Meal Planner</h2>
      <p>Plan your meals for the entire week with ease</p>
    </div>
    <div class="d-flex gap-2 align-items-center">
      <a href="mealplanner.php?week=<?=$prevWeek?>" class="btn-dark-card btn"><i class="fas fa-chevron-left"></i></a>
      <span class="gold-text" style="font-weight:600;font-size:0.9rem"><?=date('M j',strtotime($weekStart))?> - <?=date('M j, Y',strtotime($weekEnd))?></span>
      <a href="mealplanner.php?week=<?=$nextWeek?>" class="btn-dark-card btn"><i class="fas fa-chevron-right"></i></a>
      <button class="btn-gold btn btn-sm" data-bs-toggle="modal" data-bs-target="#planModal"><i class="fas fa-plus me-2"></i>Add Meal</button>
    </div>
  </div>
</div>

<!-- Weekly Planner Grid -->
<div class="table-responsive mb-4">
  <table style="width:100%;border-collapse:separate;border-spacing:4px">
    <thead>
      <tr>
        <th style="background:var(--black-input);border:var(--border-gold);border-radius:8px;padding:12px 16px;color:var(--gray-text);font-size:0.78rem;text-transform:uppercase;letter-spacing:1px;width:80px">Meal</th>
        <?php foreach($weekDays as $date=>$label): ?>
        <th style="background:<?=$date==$today?'rgba(255,215,0,0.12)':'var(--black-input)'?>;border:<?=$date==$today?'2px solid var(--gold)':'var(--border-gold)'?>;border-radius:8px;padding:10px 12px;color:<?=$date==$today?'var(--gold)':'var(--gray-text)'?>;font-size:0.8rem;text-align:center;min-width:130px">
          <?=$label?><?=$date==$today?' <span style="display:block;font-size:0.65rem;background:var(--gold);color:#000;border-radius:10px;padding:1px 6px;margin-top:3px">TODAY</span>':''?>
        </th>
        <?php endforeach; ?>
      </tr>
    </thead>
    <tbody>
    <?php foreach(['breakfast'=>['🌅','Breakfast'],'lunch'=>['☀️','Lunch'],'dinner'=>['🌙','Dinner'],'snack'=>['🍎','Snack']] as $type=>[$icon,$label]): ?>
    <tr>
      <td style="padding:8px 12px;vertical-align:middle">
        <div style="background:var(--black-input);border:var(--border-gold);border-radius:8px;padding:8px;text-align:center">
          <div style="font-size:1.2rem"><?=$icon?></div>
          <div style="font-size:0.7rem;color:var(--gold);font-weight:600"><?=$label?></div>
        </div>
      </td>
      <?php foreach(array_keys($weekDays) as $date): ?>
      <td style="padding:4px;vertical-align:top">
        <div style="background:var(--black-card);border:<?=$date==$today?'1px solid rgba(255,215,0,0.4)':'var(--border-gold)'?>;border-radius:8px;padding:8px;min-height:70px">
          <?php if(isset($planData[$date][$type])): ?>
            <?php foreach($planData[$date][$type] as $m): ?>
            <div style="font-size:0.72rem;margin-bottom:3px;padding:4px;background:rgba(255,215,0,0.05);border-radius:4px;position:relative">
              <span style="font-weight:600;color:var(--white)"><?=htmlspecialchars(substr($m['food_name']??$m['custom_food']??'?',0,20))?></span><br>
              <span style="color:var(--gold);font-size:0.68rem"><?=$m['calories']?> kcal</span>
              <div style="position:absolute;top:3px;right:3px;display:flex;gap:2px">
                <a href="mealplanner.php?favorite=<?=$m['id']?>" style="color:<?=$m['is_favorite']?'#ffc107':'var(--gray-text)'?>;font-size:0.65rem" title="Favorite"><i class="fas fa-star"></i></a>
                <a href="mealplanner.php?delete=<?=$m['id']?>" onclick="return confirm('Remove?')" style="color:#dc3545;font-size:0.65rem"><i class="fas fa-times"></i></a>
              </div>
            </div>
            <?php endforeach; ?>
          <?php else: ?>
          <button onclick="openAddMeal('<?=$date?>','<?=$type?>')" style="background:none;border:1px dashed rgba(255,215,0,0.2);color:rgba(255,215,0,0.3);border-radius:6px;width:100%;padding:8px 4px;font-size:0.68rem;transition:all 0.2s;cursor:pointer" onmouseover="this.style.borderColor='rgba(255,215,0,0.5)';this.style.color='var(--gold)'" onmouseout="this.style.borderColor='rgba(255,215,0,0.2)';this.style.color='rgba(255,215,0,0.3)'">
            <i class="fas fa-plus"></i> Add
          </button>
          <?php endif; ?>
        </div>
      </td>
      <?php endforeach; ?>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>

<!-- Weekly Totals Row -->
<div class="row g-3 mb-4">
  <?php foreach($weekDays as $date=>$label):
    $dayTotal = 0;
    foreach(['breakfast','lunch','dinner','snack'] as $t)
        foreach($planData[$date][$t] ?? [] as $m) $dayTotal += $m['calories'];
  ?>
  <div class="col">
    <div style="background:<?=$date==$today?'rgba(255,215,0,0.08)':'var(--black-card)'?>;border:<?=$date==$today?'1px solid rgba(255,215,0,0.5)':'var(--border-gold)'?>;border-radius:8px;padding:10px;text-align:center">
      <div style="font-size:0.68rem;color:var(--gray-text)"><?=date('D',strtotime($date))?></div>
      <div style="font-weight:700;color:<?=$dayTotal>0?'var(--gold)':'var(--gray-text)'?>;font-size:0.9rem"><?=$dayTotal?>kcal</div>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Favorites Section -->
<?php
$favs = $conn->query("SELECT mp.*,f.name as food_name FROM meal_plans mp LEFT JOIN foods f ON mp.food_id=f.id WHERE mp.user_id=$uid AND mp.is_favorite=1 ORDER BY mp.plan_date DESC LIMIT 6");
if($favs->num_rows > 0):
?>
<div class="card-gold">
  <div class="section-title"><i class="fas fa-star me-2" style="color:#ffc107"></i>Favorite Meals</div>
  <div class="row g-3">
  <?php while($fav=$favs->fetch_assoc()): ?>
  <div class="col-md-4">
    <div style="background:var(--black-input);border:var(--border-gold);border-radius:8px;padding:14px;display:flex;align-items:center;gap:12px">
      <i class="fas fa-utensils" style="color:var(--gold);font-size:1.2rem"></i>
      <div>
        <div style="font-weight:600;font-size:0.88rem"><?=htmlspecialchars($fav['food_name']??$fav['custom_food']??'?')?></div>
        <div style="color:var(--gold);font-size:0.78rem"><?=$fav['calories']?> kcal | <?=ucfirst($fav['meal_type'])?></div>
      </div>
    </div>
  </div>
  <?php endwhile; ?>
  </div>
</div>
<?php endif; ?>

<!-- Add Meal Modal -->
<div class="modal fade" id="planModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-dark">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="fas fa-plus me-2"></i>Add Meal to Planner</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST">
        <div class="modal-body">
          <div class="row g-3">
            <div class="col-6">
              <label class="form-label">Date</label>
              <input type="date" name="plan_date" id="planDate" class="form-control" value="<?=$today?>" required>
            </div>
            <div class="col-6">
              <label class="form-label">Meal Type</label>
              <select name="meal_type" id="planMealType" class="form-select">
                <option value="breakfast">🌅 Breakfast</option>
                <option value="lunch">☀️ Lunch</option>
                <option value="dinner">🌙 Dinner</option>
                <option value="snack">🍎 Snack</option>
              </select>
            </div>
            <div class="col-12">
              <label class="form-label">Select Food</label>
              <select name="food_id" class="form-select" required>
                <option value="">-- Choose from food database --</option>
                <?php foreach($foodList as $f): ?>
                <option value="<?=$f['id']?>"><?=htmlspecialchars($f['name'])?> (<?=$f['calories']?> kcal)</option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-6">
              <label class="form-label">Quantity</label>
              <input type="number" name="quantity" class="form-control" value="1" min="0.1" step="0.1" required>
            </div>
            <div class="col-6">
              <label class="form-label">Notes</label>
              <input type="text" name="notes" class="form-control" placeholder="Optional">
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn-dark-card btn" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" name="save_plan" class="btn-gold btn"><i class="fas fa-save me-2"></i>Save to Planner</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
function openAddMeal(date, type) {
    document.getElementById('planDate').value = date;
    document.getElementById('planMealType').value = type;
    new bootstrap.Modal(document.getElementById('planModal')).show();
}
</script>
<?php require_once 'includes/footer.php'; ?>
