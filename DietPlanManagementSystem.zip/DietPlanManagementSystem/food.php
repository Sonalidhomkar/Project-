<?php
require_once 'includes/header.php';

$search   = sanitize($conn, $_GET['search'] ?? '');
$category = sanitize($conn, $_GET['category'] ?? '');

$where = "WHERE 1=1";
if ($search) {
    $where .= " AND f.name LIKE '%$search%'";
}
if ($category) {
    $where .= " AND f.category='$category'";
}

$foods = $conn->query("SELECT f.* FROM foods f $where ORDER BY f.category,f.name");

$categories = $conn->query("SELECT DISTINCT category FROM foods ORDER BY category");
$catList = [];
while ($c = $categories->fetch_assoc()) {
    $catList[] = $c['category'];
}
?>

<div class="page-header">
  <h2><i class="fas fa-database me-3"></i>Food Database</h2>
  <p>Browse 500+ foods with complete nutrition info. Click any food for details.</p>
</div>

<!-- Search & Filter -->
<div class="card-gold mb-4">
  <form method="GET" class="row g-3 align-items-end">
    <div class="col-md-6">
      <label class="form-label">Search Food</label>
      <div class="input-group">
        <span class="input-group-text"><i class="fas fa-search"></i></span>
        <input type="text" name="search" class="form-control" placeholder="Search food name..." value="<?=htmlspecialchars($search)?>">
      </div>
    </div>
    <div class="col-md-3">
      <label class="form-label">Category</label>
      <select name="category" class="form-select">
        <option value="">All Categories</option>
        <?php foreach ($catList as $c): ?>
        <option value="<?=$c?>" <?=$category==$c?'selected':''?>><?=$c?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-2"><button type="submit" class="btn-gold btn w-100"><i class="fas fa-search me-2"></i>Search</button></div>
    <div class="col-md-1"><a href="food.php" class="btn-dark-card btn w-100">Reset</a></div>
  </form>
</div>

<!-- Category Pills -->
<div class="d-flex flex-wrap gap-2 mb-4">
  <a href="food.php" class="btn <?=!$category?'btn-gold':'btn-dark-card'?> btn-sm"><i class="fas fa-th me-1"></i>All</a>
  <?php foreach ($catList as $c): ?>
  <a href="food.php?category=<?=urlencode($c)?>" class="btn <?=$category==$c?'btn-gold':'btn-dark-card'?> btn-sm"><?=$c?></a>
  <?php endforeach; ?>
</div>

<!-- Food Grid with Photos -->
<div class="row g-4" id="foodGrid">
<?php
$foodRows = [];
while ($f = $foods->fetch_assoc()) {
    $foodRows[] = $f;
}
$total = count($foodRows);
echo "<div class='col-12 mb-3'><span class='text-muted-gold' style='font-size:0.85rem'>Showing $total foods</span></div>";

$foodImages = [
    'Boiled Egg'             => 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=400',
    'Brown Rice'             => 'https://images.unsplash.com/photo-1516684732162-798a0062be99?w=400',
    'Grilled Chicken Breast' => 'https://images.unsplash.com/photo-1604503468506-a8da13d82791?w=400',
    'Banana'                 => 'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=400',
    'Apple'                  => 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=400',
    'Oatmeal'                => 'https://images.unsplash.com/photo-1495214783159-3503fd1b572d?w=400',
    'Salmon'                 => 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?w=400',
    'Greek Yogurt'           => 'https://images.unsplash.com/photo-1571212515416-fef01fc43637?w=400',
    'Spinach'                => 'https://images.unsplash.com/photo-1576045057995-568f588f82fb?w=400',
    'Sweet Potato'           => 'https://images.unsplash.com/photo-1596797038530-2c107229654b?w=400',
    'Almonds'                => 'https://images.unsplash.com/photo-1508747703725-719777637510?w=400',
    'Avocado'                => 'https://images.unsplash.com/photo-1519162808019-7de1683fa2ad?w=400',
    'Broccoli'               => 'https://images.unsplash.com/photo-1459411621453-7b03977f4bfc?w=400',
    'Quinoa'                 => 'https://images.unsplash.com/photo-1543352634-99a5d50ae78e?w=400',
    'Milk'                   => 'https://images.unsplash.com/photo-1550583724-b2692b85b150?w=400',
    'Orange'                 => 'https://images.unsplash.com/photo-1582979512210-99b6a53386f9?w=400',
    'Tuna'                   => 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?w=400',
    'Lentils'                => 'https://images.unsplash.com/photo-1608164479264-39c45e94d888?w=400',
    'Whole Wheat Bread'      => 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400',
];
$defaultImg = 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=400';

foreach ($foodRows as $f):
    $img = $foodImages[$f['name']] ?? $defaultImg;
?>
<div class="col-xl-3 col-lg-4 col-md-6">
  <div class="food-card" onclick='showFoodDetail(<?=json_encode(array_merge($f, ['img' => $img]), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT)?>)'>
    <div style="position:relative;overflow:hidden">
      <img src="<?=$img?>" alt="<?=htmlspecialchars($f['name'])?>" loading="lazy">
      <div style="position:absolute;top:10px;left:10px">
        <span style="background:rgba(0,0,0,0.8);border:1px solid var(--gold);border-radius:12px;padding:3px 10px;font-size:0.72rem;color:var(--gold)"><?=$f['category']?></span>
      </div>
      <div style="position:absolute;top:10px;right:10px">
        <span style="background:rgba(0,0,0,0.85);border:1px solid rgba(255,215,0,0.4);border-radius:12px;padding:3px 10px;font-size:0.75rem;font-weight:700;color:#fff"><?=$f['calories']?> kcal</span>
      </div>
    </div>
    <div class="food-card-body">
      <h5 class="food-card-title"><?=htmlspecialchars($f['name'])?></h5>
      <div style="font-size:0.75rem;color:var(--gray-text);margin-bottom:8px"><?=htmlspecialchars($f['serving_size'])?></div>
      <div class="food-macro">
        <span class="macro-badge" style="color:#28a745"><i class="fas fa-drumstick-bite me-1"></i><?=$f['protein']?>g P</span>
        <span class="macro-badge" style="color:#ffc107"><i class="fas fa-bread-slice me-1"></i><?=$f['carbs']?>g C</span>
        <span class="macro-badge" style="color:#17a2b8"><i class="fas fa-bacon me-1"></i><?=$f['fat']?>g F</span>
      </div>
    </div>
  </div>
</div>
<?php endforeach; ?>
</div>

<!-- Food Detail Modal -->
<div class="modal fade" id="foodDetailModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-dark modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="fas fa-leaf me-2"></i><span id="fdName"></span></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body p-0">
        <div class="row g-0">
          <div class="col-md-5">
            <img id="fdImg" src="" alt="" style="width:100%;height:280px;object-fit:cover">
          </div>
          <div class="col-md-7" style="padding:24px">
            <div class="row g-2 mb-4">
              <?php foreach ([['fdCal','Calories','var(--gold)'],['fdProt','Protein','#28a745'],['fdCarb','Carbs','#ffc107'],['fdFat','Fat','#17a2b8'],['fdFib','Fiber','#e91e63'],['fdServ','Serving','var(--gray-text)']] as $m): ?>
              <div class="col-4">
                <div style="background:var(--black-input);border:var(--border-gold);border-radius:8px;padding:10px;text-align:center">
                  <div id="<?=$m[0]?>" style="font-weight:700;color:<?=$m[2]?>;font-size:1rem">-</div>
                  <div style="font-size:0.7rem;color:var(--gray-text)"><?=$m[1]?></div>
                </div>
              </div>
              <?php endforeach; ?>
            </div>
            <div style="background:rgba(255,215,0,0.05);border:var(--border-gold);border-radius:10px;padding:16px;margin-bottom:16px">
              <h6 class="gold-text mb-2"><i class="fas fa-leaf me-2"></i>Health Benefits</h6>
              <p class="text-muted-gold mb-0" id="fdBen" style="font-size:0.85rem;line-height:1.7">-</p>
            </div>
            <div id="fdCategory" style="font-size:0.82rem;color:var(--gray-text)"></div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <a href="calories.php" class="btn-gold btn"><i class="fas fa-plus me-2"></i>Add to Meal Tracker</a>
        <a href="mealplanner.php" class="btn-outline-gold btn"><i class="fas fa-calendar me-2"></i>Add to Meal Plan</a>
      </div>
    </div>
  </div>
</div>

<script>
function showFoodDetail(f) {
    document.getElementById('fdName').textContent = f.name;
    document.getElementById('fdImg').src = f.img;
    document.getElementById('fdCal').textContent = f.calories + ' kcal';
    document.getElementById('fdProt').textContent = f.protein + 'g';
    document.getElementById('fdCarb').textContent = f.carbs + 'g';
    document.getElementById('fdFat').textContent = f.fat + 'g';
    document.getElementById('fdFib').textContent = (f.fiber || 0) + 'g';
    document.getElementById('fdServ').textContent = f.serving_size;
    document.getElementById('fdBen').textContent = f.benefits || 'No benefit information available.';
    document.getElementById('fdCategory').innerHTML = '<i class="fas fa-tag me-2" style="color:var(--gold)"></i>Category: ' + f.category;
    new bootstrap.Modal(document.getElementById('foodDetailModal')).show();
}
</script>

<?php require_once 'includes/footer.php'; ?>
