<?php
require_once 'includes/header.php';

// ============ DASHBOARD DATA ============

// Today's stats
$calRes  = $conn->query("SELECT COALESCE(SUM(calories),0) as total FROM meal_plans WHERE user_id=$uid AND plan_date='$today'");
$todayCal = round($calRes->fetch_assoc()['total']);

$watRes  = $conn->query("SELECT COALESCE(SUM(amount_ml),0) as total FROM water_intake WHERE user_id=$uid AND intake_date='$today'");
$todayWater = round($watRes->fetch_assoc()['total']);

// BMI
$bmiRes  = $conn->query("SELECT bmi,category FROM bmi_records WHERE user_id=$uid ORDER BY recorded_date DESC LIMIT 1");
$bmiData = $bmiRes->num_rows > 0 ? $bmiRes->fetch_assoc() : ['bmi'=>0,'category'=>'Not Calculated'];

// Weekly calorie data for chart
$weekCal = []; $weekLabels = [];
for ($i = 6; $i >= 0; $i--) {
    $d  = date('Y-m-d', strtotime("-$i days"));
    $lbl= date('D', strtotime("-$i days"));
    $r  = $conn->query("SELECT COALESCE(SUM(calories),0) as total FROM meal_plans WHERE user_id=$uid AND plan_date='$d'");
    $weekCal[]    = round($r->fetch_assoc()['total']);
    $weekLabels[] = $lbl;
}

// Recent meals
$recentMeals = $conn->query("SELECT mp.*, f.name as food_name FROM meal_plans mp LEFT JOIN foods f ON mp.food_id=f.id WHERE mp.user_id=$uid ORDER BY mp.plan_date DESC,mp.id DESC LIMIT 5");

// Today's macros
$macroRes = $conn->query("SELECT COALESCE(SUM(mp.calories),0) as cal, COALESCE(SUM(f.protein * mp.quantity),0) as prot, COALESCE(SUM(f.carbs * mp.quantity),0) as carbs, COALESCE(SUM(f.fat * mp.quantity),0) as fat FROM meal_plans mp LEFT JOIN foods f ON mp.food_id=f.id WHERE mp.user_id=$uid AND mp.plan_date='$today'");
$macros = $macroRes->fetch_assoc();

$calGoal   = $goals['daily_calorie_goal'];
$waterGoal = $goals['daily_water_goal'];
$calPct    = $calGoal > 0 ? min(100, round($todayCal / $calGoal * 100)) : 0;
$waterPct  = $waterGoal > 0 ? min(100, round($todayWater / $waterGoal * 100)) : 0;

// Greeting
$hour = date('H');
$greeting = $hour < 12 ? 'Good Morning' : ($hour < 17 ? 'Good Afternoon' : 'Good Evening');
?>

<div class="page-header">
  <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
    <div>
      <h2><i class="fas fa-tachometer-alt me-3"></i>Dashboard</h2>
      <p><?= $greeting ?>, <span class="gold-text font-weight-700"><?= htmlspecialchars($user['name']) ?></span>! Here's your health summary for today.</p>
    </div>
    <div class="d-flex gap-2">
      <span style="background:rgba(255,215,0,0.1);border:var(--border-gold);border-radius:8px;padding:8px 16px;font-size:0.85rem;color:var(--gold)">
        <i class="fas fa-calendar-day me-2"></i><?= date('l, F j, Y') ?>
      </span>
    </div>
  </div>
</div>

<!-- ===== STAT CARDS ===== -->
<div class="row g-4 mb-4">
  <div class="col-xl-3 col-md-6">
    <div class="card-stat" onclick="location.href='calories.php'">
      <div class="stat-icon"><i class="fas fa-fire"></i></div>
      <div class="stat-value"><?= $todayCal ?></div>
      <div class="stat-label">Calories Consumed</div>
      <div class="progress-gold mt-3" style="height:6px">
        <div class="progress-bar" style="width:<?= $calPct ?>%"></div>
      </div>
      <div class="d-flex justify-content-between mt-1">
        <small class="text-muted-gold" style="font-size:0.7rem">Goal: <?= $calGoal ?></small>
        <small class="gold-text" style="font-size:0.7rem"><?= $calPct ?>%</small>
      </div>
    </div>
  </div>
  <div class="col-xl-3 col-md-6">
    <div class="card-stat" onclick="location.href='water.php'">
      <div class="stat-icon"><i class="fas fa-tint" style="color:#17a2b8"></i></div>
      <div class="stat-value" style="color:#17a2b8"><?= round($todayWater/1000,1) ?>L</div>
      <div class="stat-label">Water Intake</div>
      <div class="progress-gold mt-3" style="height:6px">
        <div class="progress-bar" style="width:<?= $waterPct ?>%;background:linear-gradient(135deg,#17a2b8,#0d6efd)"></div>
      </div>
      <div class="d-flex justify-content-between mt-1">
        <small class="text-muted-gold" style="font-size:0.7rem">Goal: <?= $waterGoal ?>ml</small>
        <small style="color:#17a2b8;font-size:0.7rem"><?= $waterPct ?>%</small>
      </div>
    </div>
  </div>
  <div class="col-xl-3 col-md-6">
    <div class="card-stat" onclick="location.href='bmi.php'">
      <div class="stat-icon"><i class="fas fa-weight" style="color:<?= $bmiData['bmi']>0 && $bmiData['bmi']<25 ? '#28a745' : '#ffc107' ?>"></i></div>
      <div class="stat-value" style="color:<?= $bmiData['bmi']>0 && $bmiData['bmi']<25 ? '#28a745' : '#ffc107' ?>"><?= $bmiData['bmi'] > 0 ? $bmiData['bmi'] : 'N/A' ?></div>
      <div class="stat-label">BMI Score</div>
      <div class="mt-2">
        <span class="badge-<?= $bmiData['bmi'] >= 18.5 && $bmiData['bmi'] < 25 ? 'success' : 'info' ?>"><?= $bmiData['category'] ?></span>
      </div>
    </div>
  </div>

</div>

<!-- ===== CHARTS ROW ===== -->
<div class="row g-4 mb-4">
  <!-- Weekly Calorie Chart -->
  <div class="col-lg-8">
    <div class="chart-container">
      <div class="section-title"><i class="fas fa-chart-bar me-2"></i>Weekly Calorie Intake</div>
      <canvas id="weeklyChart" height="80"></canvas>
    </div>
  </div>
  <!-- Macro Pie Chart -->
  <div class="col-lg-4">
    <div class="chart-container">
      <div class="section-title"><i class="fas fa-chart-pie me-2"></i>Today's Macros</div>
      <canvas id="macroChart" height="160"></canvas>
      <div class="row g-2 mt-3">
        <div class="col-4 text-center">
          <div style="font-weight:700;color:#28a745"><?= round($macros['prot']) ?>g</div>
          <div class="text-muted-gold" style="font-size:0.72rem">Protein</div>
        </div>
        <div class="col-4 text-center">
          <div style="font-weight:700;color:#ffc107"><?= round($macros['carbs']) ?>g</div>
          <div class="text-muted-gold" style="font-size:0.72rem">Carbs</div>
        </div>
        <div class="col-4 text-center">
          <div style="font-weight:700;color:#17a2b8"><?= round($macros['fat']) ?>g</div>
          <div class="text-muted-gold" style="font-size:0.72rem">Fat</div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- ===== QUICK ACTIONS + RECENT MEALS ===== -->
<div class="row g-4 mb-4">
  <!-- Quick Actions -->
  <div class="col-lg-4">
    <div class="card-gold h-100">
      <div class="section-title"><i class="fas fa-bolt me-2"></i>Quick Actions</div>
      <div class="d-flex flex-column gap-3">
        <?php
        $actions = [
          ['calories.php','fas fa-plus-circle','Log Meal','#28a745','Add today\'s food'],
          ['water.php','fas fa-tint','Log Water','#17a2b8','Track hydration'],
          ['bmi.php','fas fa-calculator','Calculate BMI','var(--gold)','Check your BMI'],
          ['report.php','fas fa-chart-bar','View Reports','#e91e63','Health analytics'],
          ['diet.php','fas fa-brain','AI Diet Plan','var(--gold)','Get AI suggestions'],
        ];
        foreach($actions as $a): ?>
        <a href="<?=$a[0]?>" class="d-flex align-items-center gap-3 p-3 text-decoration-none" style="background:var(--black-input);border:var(--border-gold);border-radius:var(--radius-sm);transition:all 0.3s;color:var(--white)" onmouseover="this.style.borderColor='var(--gold)';this.style.background='rgba(255,215,0,0.05)'" onmouseout="this.style.borderColor='rgba(255,215,0,0.3)';this.style.background='var(--black-input)'">
          <div style="width:38px;height:38px;background:rgba(255,255,255,0.05);border-radius:8px;display:flex;align-items:center;justify-content:center;color:<?=$a[3]?>;font-size:1.1rem">
            <i class="<?=$a[1]?>"></i>
          </div>
          <div>
            <div style="font-weight:600;font-size:0.9rem"><?=$a[2]?></div>
            <div class="text-muted-gold" style="font-size:0.75rem"><?=$a[4]?></div>
          </div>
          <i class="fas fa-chevron-right ms-auto text-muted-gold" style="font-size:0.75rem"></i>
        </a>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <!-- Recent Meals -->
  <div class="col-lg-8">
    <div class="card-gold h-100">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <div class="section-title mb-0"><i class="fas fa-utensils me-2"></i>Recent Meals</div>
        <a href="mealplanner.php" class="btn-outline-gold btn btn-sm">View All</a>
      </div>
      <?php if($recentMeals->num_rows > 0): ?>
      <div class="table-responsive">
        <table class="table-dark-gold w-100">
          <thead><tr><th>Food</th><th>Type</th><th>Calories</th><th>Date</th><th>Action</th></tr></thead>
          <tbody>
          <?php while($m = $recentMeals->fetch_assoc()): ?>
          <tr>
            <td><div style="font-weight:600"><?= htmlspecialchars($m['food_name'] ?? $m['custom_food'] ?? 'Unknown') ?></div></td>
            <td><span class="badge-info"><?= ucfirst($m['meal_type']) ?></span></td>
            <td><span class="gold-text font-weight-700"><?= round($m['calories']) ?></span> kcal</td>
            <td class="text-muted-gold" style="font-size:0.82rem"><?= date('M j', strtotime($m['plan_date'])) ?></td>
            <td>
              <button class="btn btn-sm" style="background:rgba(220,53,69,0.1);border:1px solid rgba(220,53,69,0.3);color:#dc3545;border-radius:6px;font-size:0.75rem" onclick="deleteMeal(<?=$m['id']?>)"><i class="fas fa-trash"></i></button>
            </td>
          </tr>
          <?php endwhile; ?>
          </tbody>
        </table>
      </div>
      <?php else: ?>
      <div class="text-center py-4">
        <div style="font-size:3rem;margin-bottom:15px">🍽️</div>
        <p class="text-muted-gold">No meals logged today.</p>
        <a href="calories.php" class="btn-gold btn btn-sm"><i class="fas fa-plus me-2"></i>Log Your First Meal</a>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- ===== HEALTH TIP ===== -->
<?php
$tips = [
    "💡 Tip: Drinking water before meals can reduce hunger and help with weight management.",
    "💡 Tip: Eating protein-rich breakfast keeps you full longer and reduces cravings.",
    "💡 Tip: A 30-minute walk burns approximately 150 calories and boosts your mood!",
    "💡 Tip: Sleep 7-8 hours per night — poor sleep increases hunger hormones by 24%.",
    "💡 Tip: Chewing food slowly activates satiety signals and improves digestion.",
];
$tip = $tips[date('N') % count($tips)];
?>
<div class="alert-gold">
  <i class="fas fa-lightbulb me-2"></i><?= $tip ?>
</div>

<script>
// Expose BASE_PATH & login flag for cross-page helpers (used on landing page too)
window.BASE_PATH = '<?= addslashes($basePrefix ?? '') ?>';
window.IS_LOGGED_IN = true;

// Keep today's calories & goal in localStorage for notifications on landing page
try {
    localStorage.setItem('NUTRIGOLD_TODAY_CALORIES', String(<?= (int)$todayCal ?>));
    localStorage.setItem('NUTRIGOLD_GOAL_CALORIES', String(<?= (int)$calGoal ?>));
} catch (e) {
    // ignore if storage not available
}
// Weekly Chart
new Chart(document.getElementById('weeklyChart'), {
    type: 'bar',
    data: {
        labels: <?= json_encode($weekLabels) ?>,
        datasets: [{
            label: 'Calories',
            data: <?= json_encode($weekCal) ?>,
            backgroundColor: 'rgba(255,215,0,0.3)',
            borderColor: '#FFD700',
            borderWidth: 2,
            borderRadius: 8,
        },{
            label: 'Goal',
            data: Array(7).fill(<?= $calGoal ?>),
            type: 'line',
            borderColor: 'rgba(220,53,69,0.6)',
            borderDash: [5,5],
            borderWidth: 2,
            pointRadius: 0,
            fill: false
        }]
    },
    options: {
        responsive: true,
        plugins: { legend: { labels: { color: '#aaa' } } },
        scales: {
            y: { grid: { color: 'rgba(255,215,0,0.05)' }, ticks: { color: '#aaa' } },
            x: { grid: { display: false }, ticks: { color: '#aaa' } }
        }
    }
});

// Macro Chart
const p=<?= round($macros['prot']) ?>, c=<?= round($macros['carbs']) ?>, f=<?= round($macros['fat']) ?>;
new Chart(document.getElementById('macroChart'), {
    type: 'doughnut',
    data: {
        labels: ['Protein','Carbs','Fat'],
        datasets: [{
            data: [p||1, c||1, f||1],
            backgroundColor: ['rgba(40,167,69,0.8)','rgba(255,193,7,0.8)','rgba(23,162,184,0.8)'],
            borderColor: ['#28a745','#ffc107','#17a2b8'],
            borderWidth: 2
        }]
    },
    options: {
        cutout: '65%',
        plugins: { legend: { display: false } }
    }
});

function deleteMeal(id) {
    if(confirm('Delete this meal entry?')) {
        const base = (typeof window.BASE_PATH !== 'undefined') ? window.BASE_PATH : '';
        fetch(base + 'api/meals.php?action=delete&id=' + id, {method:'POST'})
        .then(()=>location.reload());
    }
}
</script>

<?php require_once 'includes/footer.php'; ?>
