<?php
session_start();
require_once 'includes/db.php';

$error = '';
$success = '';
$formEmail = '';
$redirectTarget = $_GET['redirect'] ?? ($_POST['redirect'] ?? 'dashboard.php');

// Avoid POST-resubmit cache prompts on refresh/back (Edge ERR_CACHE_MISS).
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

if (isset($_SESSION['login_error'])) {
    $error = $_SESSION['login_error'];
    unset($_SESSION['login_error']);
}
if (isset($_SESSION['login_email'])) {
    $formEmail = $_SESSION['login_email'];
    unset($_SESSION['login_email']);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email    = sanitize($conn, $_POST['email']);
    $password = $_POST['password'];
    $formEmail = $email;

    $sql = "SELECT * FROM users WHERE email='$email' AND is_active=1";
    $res = $conn->query($sql);

    if ($res->num_rows == 1) {
        $user = $res->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id']   = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_email']= $user['email'];
            $redirect = $_POST['redirect'] ?? $_GET['redirect'] ?? 'dashboard.php';
            $redirect = (preg_match('#^[a-zA-Z0-9_\-/\.]+$#', $redirect) && strpos($redirect, '..') === false) ? $redirect : 'dashboard.php';
            redirect($redirect);
        } else {
            $_SESSION['login_error'] = "Invalid email or password!";
            $_SESSION['login_email'] = $email;
            $next = (preg_match('#^[a-zA-Z0-9_\-/\.]+$#', $redirectTarget) && strpos($redirectTarget, '..') === false)
                ? "login.php?redirect=" . urlencode($redirectTarget)
                : "login.php";
            redirect($next);
        }
    } else {
        $_SESSION['login_error'] = "Invalid email or password!";
        $_SESSION['login_email'] = $email;
        $next = (preg_match('#^[a-zA-Z0-9_\-/\.]+$#', $redirectTarget) && strpos($redirectTarget, '..') === false)
            ? "login.php?redirect=" . urlencode($redirectTarget)
            : "login.php";
        redirect($next);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login | NutriGold</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="auth-wrapper">
  <div class="auth-card animate-in">
    <!-- Logo -->
    <div class="auth-logo"><i class="fas fa-leaf me-2"></i>NutriGold</div>
    <h2 class="auth-title">Welcome Back!</h2>
    <p class="auth-subtitle">Login to continue your health journey</p>

    <?php if($error): ?>
    <div class="alert-danger-dark mb-4"><i class="fas fa-exclamation-circle me-2"></i><?= $error ?></div>
    <?php endif; ?>
    <?php if($success): ?>
    <div class="alert-success-dark mb-4"><i class="fas fa-check-circle me-2"></i><?= $success ?></div>
    <?php endif; ?>

    <form method="POST" action="login.php">
      <input type="hidden" name="redirect" value="<?= htmlspecialchars($redirectTarget) ?>">
      <div class="mb-4">
        <label class="form-label"><i class="fas fa-envelope me-2" style="color:var(--gold)"></i>Email Address</label>
        <input type="email" name="email" class="form-control" placeholder="Enter your email" required value="<?= htmlspecialchars($formEmail) ?>">
      </div>
      <div class="mb-4">
        <label class="form-label"><i class="fas fa-lock me-2" style="color:var(--gold)"></i>Password</label>
        <div class="input-group">
          <input type="password" name="password" class="form-control" id="pwdField" placeholder="Enter your password" required>
          <button type="button" class="input-group-text" onclick="togglePwd()"><i class="fas fa-eye" id="eyeIcon"></i></button>
        </div>
      </div>
      <div class="d-flex justify-content-between align-items-center mb-4">
        <div class="form-check">
          <input class="form-check-input" type="checkbox" id="rememberMe" style="border-color:var(--gold)">
          <label class="form-check-label text-muted-gold" style="font-size:0.85rem" for="rememberMe">Remember me</label>
        </div>
        <a href="forgot-password.php" style="color:var(--gold);font-size:0.85rem;text-decoration:none">Forgot Password?</a>
      </div>
      <button type="submit" class="btn-gold btn w-100 mb-3"><i class="fas fa-sign-in-alt me-2"></i>Login</button>
    </form>

    <div class="auth-divider">or continue with</div>
    <div class="d-flex gap-3 mb-4">
     
    <p class="text-center text-muted-gold" style="font-size:0.88rem">
      Don't have an account? <a href="register.php" style="color:var(--gold);text-decoration:none;font-weight:600">Create Account</a>
    </p>
    <p class="text-center mt-2" style="font-size:0.82rem">
      <a href="admin/admin-login.php" style="color:var(--gray-light);text-decoration:none"><i class="fas fa-user-shield me-1"></i>Admin Login</a>
    </p>
    <!-- Demo Credentials -->
   
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function togglePwd() {
    const f = document.getElementById('pwdField');
    const i = document.getElementById('eyeIcon');
    if (f.type === 'password') { f.type = 'text'; i.className = 'fas fa-eye-slash'; }
    else { f.type = 'password'; i.className = 'fas fa-eye'; }
}
</script>
</body>
</html>
