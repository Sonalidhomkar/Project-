<?php
require_once 'includes/header.php';

// ---- Handle feedback submission ----
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name    = sanitize($conn, $_POST['name'] ?? $user['name']);
    $email   = sanitize($conn, $_POST['email'] ?? $user['email']);
    $subject = sanitize($conn, $_POST['subject'] ?? '');
    $message = sanitize($conn, $_POST['message']);
    $rating  = (int)$_POST['rating'];

    $conn->query("INSERT INTO feedback (user_id,name,email,subject,message,rating) VALUES ($uid,'$name','$email','$subject','$message',$rating)");
    $success = "Thank you for your feedback! We'll get back to you soon.";
}

$myFeedback = $conn->query("SELECT * FROM feedback WHERE user_id=$uid ORDER BY created_at DESC LIMIT 5");

$faqs = [
    ['How do I calculate my BMI?','Go to BMI Calculator, enter your weight in kg and height in cm. The system will instantly calculate your BMI and provide health recommendations.'],
    ['Can I set custom calorie goals?','Yes! Go to Dashboard > Settings or update your goals in the profile section. You can set daily calorie, water, and fitness goals.'],
    ['How does the AI diet plan work?','Our AI analyzes your age, weight, height, gender, and fitness goal to generate a personalized 7-day meal plan with appropriate calorie targets.'],
    ['How do I export my health report?','Go to Reports page and click the Export PDF button. You can also print directly from your browser.'],
    ['Can I add custom foods?','Yes, go to Calorie Tracker and switch to the Custom Food tab to add any food with its nutritional details.'],
    ['What is the Water Tracker for?','Track your daily water intake, set goals, and monitor hydration with our smart water tracker. Proper hydration is key to health!'],
];
?>

<div class="page-header">
  <h2><i class="fas fa-star me-3" style="color:#ffc107"></i>Feedback &amp; Support</h2>
  <p>We value your feedback and are here to help</p>
</div>

<div class="row g-4">
  <!-- Contact Form -->
  <div class="col-lg-6">
    <div class="card-gold">
      <div class="section-title"><i class="fas fa-envelope me-2"></i>Send Feedback</div>

      <?php if(isset($success)): ?>
      <div class="alert-success-dark mb-4"><i class="fas fa-check-circle me-2"></i><?=$success?></div>
      <?php endif; ?>

      <form method="POST">
        <div class="row g-3">
          <div class="col-md-6">
            <label class="form-label">Your Name</label>
            <input type="text" name="name" class="form-control" value="<?=htmlspecialchars($user['name'])?>" required>
          </div>
          <div class="col-md-6">
            <label class="form-label">Email</label>
            <input type="email" name="email" class="form-control" value="<?=htmlspecialchars($user['email'])?>" required>
          </div>
          <div class="col-12">
            <label class="form-label">Subject</label>
            <input type="text" name="subject" class="form-control" placeholder="What is this about?">
          </div>
          <!-- Star Rating -->
          <div class="col-12">
            <label class="form-label">Overall Rating</label>
            <div class="d-flex gap-2 mb-2">
              <?php for($r=1;$r<=5;$r++): ?>
              <label style="cursor:pointer">
                <input type="radio" name="rating" value="<?=$r?>" style="display:none" <?=$r==5?'checked':''?>>
                <i class="fas fa-star star-btn" data-val="<?=$r?>" style="font-size:1.8rem;color:<?=$r<=5?'#ffc107':'var(--gray-text)'?>;transition:all 0.2s"></i>
              </label>
              <?php endfor; ?>
            </div>
          </div>
          <div class="col-12">
            <label class="form-label">Message</label>
            <textarea name="message" class="form-control" rows="5" placeholder="Tell us about your experience, suggestions, or any issues..." required></textarea>
          </div>
          <div class="col-12">
            <button type="submit" class="btn-gold btn w-100"><i class="fas fa-paper-plane me-2"></i>Submit Feedback</button>
          </div>
        </div>
      </form>
    </div>
  </div>

  <!-- FAQs + Previous Feedback -->
  <div class="col-lg-6">
    <!-- FAQ Accordion -->
    <div class="card-gold mb-4">
      <div class="section-title"><i class="fas fa-question-circle me-2"></i>Frequently Asked Questions</div>
      <div id="faqAccordion">
        <?php foreach($faqs as $i=>$faq): ?>
        <div style="border-bottom:1px solid rgba(255,255,255,0.05);padding:4px 0">
          <button style="background:none;border:none;color:var(--white);font-size:0.9rem;font-weight:600;width:100%;text-align:left;padding:12px 0;display:flex;justify-content:space-between;align-items:center;cursor:pointer" onclick="toggleFaq(<?=$i?>)">
            <span><?=$faq[0]?></span>
            <i class="fas fa-chevron-down" id="faq-icon-<?=$i?>" style="color:var(--gold);font-size:0.8rem;transition:transform 0.3s"></i>
          </button>
          <div id="faq-ans-<?=$i?>" style="display:none;padding:0 0 12px;color:var(--gray-text);font-size:0.85rem;line-height:1.6">
            <?=$faq[1]?>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Contact Info -->
    <div class="card-gold mb-4">
      <div class="section-title"><i class="fas fa-headset me-2"></i>Contact Support</div>
      <div class="row g-3">
        <?php foreach([['fas fa-envelope','Email Support','support@nutrigold.com','#17a2b8'],['fas fa-phone','Phone','+ 1 (555) 123-4567','#28a745'],['fas fa-clock','Working Hours','Mon-Fri 9AM - 6PM','#ffc107']] as $c): ?>
        <div class="col-12">
          <div style="background:var(--black-input);border:var(--border-gold);border-radius:8px;padding:14px;display:flex;align-items:center;gap:14px">
            <i class="<?=$c[0]?>" style="color:<?=$c[3]?>;font-size:1.2rem;width:20px"></i>
            <div><div style="font-weight:600;font-size:0.9rem"><?=$c[1]?></div><div style="color:<?=$c[3]?>;font-size:0.85rem"><?=$c[2]?></div></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Previous Feedback -->
    <?php if($myFeedback->num_rows > 0): ?>
    <div class="card-gold">
      <div class="section-title"><i class="fas fa-history me-2"></i>My Previous Feedback</div>
      <?php while($fb=$myFeedback->fetch_assoc()): ?>
      <div style="background:var(--black-input);border:var(--border-gold);border-radius:8px;padding:14px;margin-bottom:10px">
        <div class="d-flex justify-content-between mb-2">
          <div style="font-weight:600;font-size:0.88rem"><?=htmlspecialchars($fb['subject']??'General Feedback')?></div>
          <span class="<?=$fb['status']=='replied'?'badge-success':'badge-info'?>"><?=ucfirst($fb['status'])?></span>
        </div>
        <p class="text-muted-gold mb-1" style="font-size:0.82rem"><?=htmlspecialchars(substr($fb['message'],0,100))?>...</p>
        <div style="font-size:0.75rem;color:var(--gray-light)"><?=date('M j, Y',strtotime($fb['created_at']))?> | <?=$fb['rating']?>⭐</div>
      </div>
      <?php endwhile; ?>
    </div>
    <?php endif; ?>
  </div>
</div>

<script>
function toggleFaq(i){
    const ans=document.getElementById('faq-ans-'+i);
    const icon=document.getElementById('faq-icon-'+i);
    if(ans.style.display==='none'){ans.style.display='block';icon.style.transform='rotate(180deg)'}
    else{ans.style.display='none';icon.style.transform='rotate(0)'}
}

// Star rating interaction
document.querySelectorAll('.star-btn').forEach(star=>{
    star.addEventListener('mouseover',function(){
        const v=parseInt(this.dataset.val);
        document.querySelectorAll('.star-btn').forEach((s,idx)=>{
            s.style.color=idx<v?'#FFD700':'var(--gray-text)';
        });
    });
    star.addEventListener('click',function(){
        const v=parseInt(this.dataset.val);
        document.querySelectorAll('.star-btn').forEach((s,idx)=>{
            s.style.color=idx<v?'#FFD700':'var(--gray-text)';
        });
        document.querySelectorAll('input[name="rating"]')[v-1].checked=true;
    });
});
</script>

<?php require_once 'includes/footer.php'; ?>
