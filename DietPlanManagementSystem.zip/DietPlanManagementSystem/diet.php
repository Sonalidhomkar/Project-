<?php
require_once 'includes/header.php';

// ---- Generate AI Diet Plan ----
$plan = null;
if ($_SERVER['REQUEST_METHOD'] == 'POST' || isset($_GET['auto'])) {
    $w    = $user['weight'] ?? 70;
    $h    = $user['height'] ?? 175;
    $age  = $user['age'] ?? 25;
    $g    = $user['gender'] ?? 'male';
    $goal = $user['fitness_goal'] ?? 'maintain';
    $al   = $user['activity_level'] ?? 'moderate';

    // Calculate TDEE
    if($g=='male') $bmr = 10*$w + 6.25*$h - 5*$age + 5;
    else           $bmr = 10*$w + 6.25*$h - 5*$age - 161;
    $af = ['sedentary'=>1.2,'light'=>1.375,'moderate'=>1.55,'active'=>1.725,'very_active'=>1.9];
    $tdee = round($bmr * ($af[$al]??1.55));

    if($goal=='weight_loss')    $targetCal=$tdee-500;
    elseif($goal=='weight_gain')$targetCal=$tdee+300;
    else                        $targetCal=$tdee;

    // Macro split
    if($goal=='weight_gain')         {$pPct=0.30;$cPct=0.50;$fPct=0.20;}
    elseif($goal=='weight_loss')     {$pPct=0.35;$cPct=0.40;$fPct=0.25;}
    else                             {$pPct=0.25;$cPct=0.50;$fPct=0.25;}

    $protG = round($targetCal*$pPct/4);
    $carbG = round($targetCal*$cPct/4);
    $fatG  = round($targetCal*$fPct/9);

    // Diet plan templates
    $plans = [
        'weight_loss' => [
            'breakfast' => ['Oatmeal with berries + Green tea','Scrambled eggs (2) + whole wheat toast','Greek yogurt + fruits + flaxseeds'],
            'lunch'     => ['Grilled chicken breast + brown rice + salad','Tuna salad wrap + vegetable soup','Lentil soup + mixed greens + whole grain bread'],
            'dinner'    => ['Baked salmon + steamed broccoli + quinoa','Chicken stir-fry with vegetables + cauliflower rice','Tofu curry + brown rice + cucumber salad'],
            'snacks'    => ['Apple + 10 almonds','Greek yogurt (low-fat)','Carrot sticks + hummus','Mixed nuts (small handful)'],
        ],
        'weight_gain' => [
            'breakfast' => ['Banana smoothie (milk+oats+peanut butter+honey)','4 scrambled eggs + whole wheat toast + avocado','Oatmeal with milk + banana + nuts + honey'],
            'lunch'     => ['Chicken + rice + sweet potato + avocado','Beef steak + mashed potatoes + vegetables','Salmon + pasta + cheese + salad'],
            'dinner'    => ['Chicken thighs + brown rice + beans','Ground beef + whole wheat pasta + tomato sauce','Eggs + potatoes + cheese + toast'],
            'snacks'    => ['Peanut butter sandwich','Protein shake + banana','Trail mix (nuts+dried fruits)','Cheese + crackers'],
        ],
        'maintain' => [
            'breakfast' => ['Whole grain cereal + milk + berries','2 eggs + whole wheat toast + orange juice','Yogurt parfait + granola + fruits'],
            'lunch'     => ['Chicken salad + whole grain bread','Veggie wrap + tomato soup','Brown rice + grilled fish + vegetables'],
            'dinner'    => ['Grilled chicken + roasted vegetables + quinoa','Fish tacos + coleslaw','Stir-fried vegetables + tofu + rice'],
            'snacks'    => ['Fruit salad','Rice cakes + peanut butter','Vegetable sticks + dip','Handful of mixed nuts'],
        ],
    ];

    $pd = $plans[$goal] ?? $plans['maintain'];
    $week = [];
    $days = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
    foreach($days as $day) {
        $week[$day] = [
            'breakfast' => $pd['breakfast'][array_rand($pd['breakfast'])],
            'lunch'     => $pd['lunch'][array_rand($pd['lunch'])],
            'dinner'    => $pd['dinner'][array_rand($pd['dinner'])],
            'snack'     => $pd['snacks'][array_rand($pd['snacks'])],
        ];
    }

    $plan = ['targetCal'=>$targetCal,'tdee'=>$tdee,'protG'=>$protG,'carbG'=>$carbG,'fatG'=>$fatG,'goal'=>$goal,'week'=>$week];

    // Save recommendation
    $conn->query("INSERT INTO diet_recommendations (user_id,goal,daily_calories,protein_g,carbs_g,fat_g,recommended_date) VALUES ($uid,'$goal',$targetCal,$protG,$carbG,$fatG,'$today') ON DUPLICATE KEY UPDATE daily_calories=$targetCal,protein_g=$protG,carbs_g=$carbG,fat_g=$fatG");
}
?>

<div class="page-header">
  <h2><i class="fas fa-brain me-3" style="color:var(--gold)"></i>AI-Powered Diet Plan Generator</h2>
  <p>Get personalized meal plans based on your profile, goals, and health metrics</p>
</div>

<?php if(!$plan): ?>
<!-- Profile Summary -->
<div class="row g-4 mb-5">
  <div class="col-lg-6">
    <div class="card-gold">
      <div class="section-title"><i class="fas fa-user me-2"></i>Your Health Profile</div>
      <div class="row g-3">
        <?php
        $stats=[
          ['Weight',$user['weight'].'kg','fas fa-weight','var(--gold)'],
          ['Height',$user['height'].'cm','fas fa-ruler-vertical','#17a2b8'],
          ['Age',$user['age'].' years','fas fa-birthday-cake','#ffc107'],
          ['Gender',ucfirst($user['gender']??'male'),'fas fa-venus-mars','#e91e63'],
          ['Goal',ucwords(str_replace('_',' ',$user['fitness_goal']??'maintain')),'fas fa-bullseye','#28a745'],
          ['Activity',ucfirst($user['activity_level']??'moderate'),'fas fa-running','#ff5722'],
        ];
        foreach($stats as $s): ?>
        <div class="col-6">
          <div style="background:var(--black-input);border:var(--border-gold);border-radius:8px;padding:14px">
            <i class="<?=$s[2]?>" style="color:<?=$s[3]?>;margin-bottom:6px"></i>
            <div style="font-weight:700;color:<?=$s[3]?>"><?=$s[1]?></div>
            <div class="text-muted-gold" style="font-size:0.75rem"><?=$s[0]?></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
  <div class="col-lg-6 d-flex flex-column justify-content-center">
    <div class="card-gold text-center">
      <div style="font-size:4rem;margin-bottom:20px">🤖</div>
      <h3 class="gold-text">Generate Your AI Diet Plan</h3>
      <p class="text-muted-gold mb-4">Our AI will analyze your profile and create a personalized 7-day meal plan tailored to your goals.</p>
      <form method="POST">
        <div class="row g-3 mb-4">
          <div class="col-6">
            <select name="goal_override" class="form-select">
              <option value="">Use My Goal (<?=ucwords(str_replace('_',' ',$user['fitness_goal']??'maintain'))?>)</option>
              <option value="weight_loss">🏃 Lose Weight</option>
              <option value="maintain">⚖️ Maintain</option>
              <option value="weight_gain">💪 Gain Muscle</option>
            </select>
          </div>
          <div class="col-6">
            <select name="diet_type" class="form-select">
              <option value="balanced">Balanced Diet</option>
              <option value="keto">Keto Friendly</option>
              <option value="vegetarian">Vegetarian</option>
              <option value="high_protein">High Protein</option>
            </select>
          </div>
        </div>
        <button type="submit" class="btn-gold btn btn-lg w-100 pulse"><i class="fas fa-magic me-2"></i>Generate My 7-Day Diet Plan</button>
      </form>
    </div>
  </div>
</div>
<?php else: ?>

<!-- Plan Generated -->
<div class="row g-4 mb-4">
  <div class="col-12">
    <div class="card-gold">
      <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
        <div>
          <h4 class="gold-text mb-1"><i class="fas fa-check-circle me-2"></i>Your Personalized 7-Day Diet Plan is Ready!</h4>
          <p class="text-muted-gold mb-0">Goal: <?=ucwords(str_replace('_',' ',$plan['goal']))?> | Daily Target: <?=$plan['targetCal']?> kcal</p>
        </div>
        <div class="d-flex gap-2">
          <a href="diet.php" class="btn-outline-gold btn btn-sm"><i class="fas fa-redo me-2"></i>Regenerate</a>
          <button onclick="window.print()" class="btn-gold btn btn-sm"><i class="fas fa-print me-2"></i>Print Plan</button>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Macro Targets -->
<div class="row g-3 mb-4">
  <?php foreach([['fas fa-fire','Daily Calories',$plan['targetCal'].' kcal','var(--gold)'],['fas fa-drumstick-bite','Protein',$plan['protG'].'g / day','#28a745'],['fas fa-bread-slice','Carbohydrates',$plan['carbG'].'g / day','#ffc107'],['fas fa-bacon','Healthy Fats',$plan['fatG'].'g / day','#17a2b8'],['fas fa-chart-bar','TDEE',$plan['tdee'].' kcal','#e91e63'],['fas fa-bullseye','Goal',ucwords(str_replace('_',' ',$plan['goal'])),'var(--gold)']] as $s): ?>
  <div class="col-md-2 col-4">
    <div style="background:var(--black-card);border:var(--border-gold);border-radius:10px;padding:16px;text-align:center">
      <i class="<?=$s[0]?>" style="color:<?=$s[3]?>;font-size:1.3rem;margin-bottom:8px;display:block"></i>
      <div style="font-weight:700;color:<?=$s[3]?>;font-size:1rem"><?=$s[2]?></div>
      <div class="text-muted-gold" style="font-size:0.72rem"><?=$s[1]?></div>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Weekly Meal Plan -->
<div class="row g-3">
  <?php foreach($plan['week'] as $day=>$meals): ?>
  <div class="col-lg-6">
    <div class="card-gold" style="border-color:rgba(255,215,0,0.3)">
      <div class="d-flex align-items-center gap-3 mb-3">
        <div style="background:var(--gold-gradient);color:#000;border-radius:8px;padding:6px 16px;font-weight:700;font-size:0.9rem"><?=$day?></div>
        <div class="text-muted-gold" style="font-size:0.8rem">~<?=$plan['targetCal']?> kcal</div>
      </div>
      <?php foreach(['breakfast'=>['🌅','Breakfast'],'lunch'=>['☀️','Lunch'],'dinner'=>['🌙','Dinner'],'snack'=>['🍎','Snack']] as $type=>[$icon,$label]): ?>
      <div class="d-flex gap-3 mb-2 p-2" style="background:var(--black-input);border-radius:8px">
        <span style="font-size:1.1rem"><?=$icon?></span>
        <div>
          <div style="font-size:0.75rem;color:var(--gold);font-weight:600"><?=$label?></div>
          <div style="font-size:0.82rem;color:var(--white)"><?=htmlspecialchars($meals[$type])?></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Diet Tips -->
<div class="row g-3 mt-3">
  <div class="col-12">
    <div class="alert-gold"><i class="fas fa-lightbulb me-2"></i><strong>Pro Tip:</strong> Meal prep on Sunday can save time and help you stick to your diet plan all week. Cook in batches and store in portioned containers!</div>
  </div>
</div>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
