# 🏆 NutriGold - Diet Plan Management System

**Black & Gold Theme | PHP + MySQL | Full-Featured Health Platform**

---

## 📋 PROJECT OVERVIEW

NutriGold is a complete **Diet Plan Management System** built with PHP, MySQL, Bootstrap 5.
It features AI-powered diet suggestions, BMI calculator, meal planning, calorie tracking,
water intake monitoring, exercise logging, admin panel, QR payment for premium plans,
interactive food photos with nutrition info, and an AI chatbot.

---

## 🚀 FEATURES

### User Features:
- ✅ Registration & Login (secure password hashing)
- ✅ BMI Calculator with health analysis
- ✅ AI-Powered Diet Plan Generator
- ✅ Weekly Meal Planner
- ✅ Calorie & Nutrition Tracker (Protein, Carbs, Fat)
- ✅ Water Intake Tracker
- ✅ Exercise & Activity Logger
- ✅ Health Reports with Charts (PDF export)
- ✅ Interactive Food Database with Photos
- ✅ AI NutriBot Chat Assistant
- ✅ Premium Plans with QR Code Payment
- ✅ Feedback & Support System
- ✅ User Profile Management

### Admin Features:
- ✅ Admin Dashboard with Analytics
- ✅ Manage Users (activate/deactivate/premium)
- ✅ Manage Food Database (add/edit/delete)
- ✅ System Reports & Charts
- ✅ Revenue Tracking

---

## 🗄️ INSTALLATION

### Requirements:
- PHP 7.4+ 
- MySQL 5.7+
- Apache/XAMPP/WAMP/LAMP

### Steps:

1. **Copy project** to `htdocs/` (XAMPP) or `www/` (WAMP)

2. **Import database:**
   - Open phpMyAdmin
   - Create database: `dietplan_db`
   - Import file: `includes/database.sql`

3. **Configure database** in `includes/db.php`:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_USER', 'root');
   define('DB_PASS', '');  // Your MySQL password
   define('DB_NAME', 'dietplan_db');
   ```

4. **Open browser:** `http://localhost/DietPlanManagementSystem/`

---

## 🔐 DEFAULT CREDENTIALS

### User Login:
- Email: `user@dietplan.com`
- Password: `password`

### Admin Login:
- Email: `admin@dietplan.com`
- Password: `password`

---

## 📁 PROJECT STRUCTURE

```
DietPlanManagementSystem/
├── index.php           ← Home Page (Landing)
├── login.php           ← User Login
├── register.php        ← User Registration
├── dashboard.php       ← User Dashboard
├── bmi.php             ← BMI Calculator
├── diet.php            ← AI Diet Plan Generator
├── mealplanner.php     ← Weekly Meal Planner
├── calories.php        ← Calorie Tracker
├── water.php           ← Water Intake Tracker
├── exercise.php        ← Exercise Logger
├── report.php          ← Health Reports
├── food.php            ← Food Database
├── premium.php         ← Premium Plans + QR Payment
├── profile.php         ← User Profile
├── feedback.php        ← Feedback & Support
├── forgot-password.php ← Password Reset
├── logout.php          ← Logout
│
├── admin/
│   ├── admin-login.php       ← Admin Login
│   ├── admin-dashboard.php   ← Admin Dashboard
│   ├── manage-users.php      ← User Management
│   ├── manage-food.php       ← Food Management
│   └── reports.php           ← System Reports
│
├── includes/
│   ├── db.php          ← Database Connection
│   ├── session.php     ← Session Management
│   ├── header.php      ← Page Header + Navbar + Sidebar
│   ├── footer.php      ← Footer + Chat Widget
│   └── database.sql    ← Database Schema & Sample Data
│
├── api/
│   ├── chat.php        ← Chat API
│   └── payment.php     ← Payment API
│
├── css/
│   └── style.css       ← Master Stylesheet (Black & Gold)
│
└── js/
    └── script.js       ← Global JavaScript
```

---

## 🎨 DESIGN THEME

- **Primary**: Black (`#0A0A0A`) background
- **Accent**: Gold (`#FFD700`) for all highlights
- **Font**: Poppins (body) + Playfair Display (headings)
- **Framework**: Bootstrap 5.3
- **Icons**: Font Awesome 6.4
- **Charts**: Chart.js 4.4

---

## 📊 DATABASE TABLES

| Table | Description |
|-------|-------------|
| users | User accounts and profiles |
| admins | Admin accounts |
| foods | Food database with nutrition info |
| meal_plans | User meal planning data |
| water_intake | Daily water tracking |
| exercises | Exercise sessions |
| bmi_records | BMI history |
| chat_messages | AI chatbot history |
| payments | Payment records |
| notifications | User notifications |
| feedback | User feedback |
| user_goals | Daily goals |
| diet_recommendations | AI diet plans |

---

## 💳 QR PAYMENT

Premium plans use QR code payment (UPI format).
In production, integrate with:
- Razorpay, Stripe, PayPal, or PhonePe APIs
- The QR generates using: `https://api.qrserver.com`

---

## 🤖 AI FEATURES

- **Diet Plan Generator**: Rule-based AI using BMR/TDEE calculations
- **NutriBot Chat**: Keyword-based response system
- **Health Risk Analysis**: BMI-based recommendations
- **Calorie Prediction**: Activity-adjusted TDEE calculation

---

## 📌 NOTES

- All passwords are hashed with `password_hash()` (bcrypt)
- SQL injection protection with `real_escape_string()`
- XSS protection with `htmlspecialchars()`
- Session-based authentication
- Responsive design for mobile/tablet/desktop

---

**Built with ❤️ | PHP + MySQL | Black & Gold Theme**
