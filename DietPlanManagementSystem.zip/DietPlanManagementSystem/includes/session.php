<?php
// ============================================
// SESSION CONFIGURATION - session.php
// ============================================
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check user session
function checkUserSession() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: ../login.php");
        exit();
    }
}

// Check admin session
function checkAdminSession() {
    if (!isset($_SESSION['admin_id'])) {
        header("Location: ../admin/admin-login.php");
        exit();
    }
}
?>
