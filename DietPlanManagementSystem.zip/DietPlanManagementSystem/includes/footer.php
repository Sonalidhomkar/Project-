
  </div><!-- end main-content -->
</div><!-- end wrapper -->

<!-- ===== FLOATING CHAT BUTTON ===== -->
<div id="chatFloat" style="position:fixed;bottom:30px;right:30px;z-index:9999">
  <button onclick="toggleChat()" class="btn-gold btn pulse" style="width:56px;height:56px;border-radius:50%;font-size:1.2rem;padding:0;box-shadow:0 8px 25px rgba(255,215,0,0.4)">
    <i class="fas fa-robot" id="chatIcon"></i>
  </button>
  <div id="chatWidget" style="display:none;position:absolute;bottom:70px;right:0;width:320px">
    <div class="chat-container">
      <div class="chat-header">
        <div class="chat-bot-avatar"><i class="fas fa-robot"></i></div>
        <div><div style="font-weight:700;font-size:0.9rem">NutriBot AI</div><div class="text-muted-gold" style="font-size:0.75rem">Online • Nutrition Expert</div></div>
        <button onclick="toggleChat()" style="background:none;border:none;color:var(--gray-text);margin-left:auto;font-size:1.1rem">×</button>
      </div>
      <div class="chat-messages" id="chatMessages">
        <div class="chat-bubble bot"><i class="fas fa-robot me-2" style="color:var(--gold)"></i>Hi! I'm NutriBot. Ask me anything about diet, nutrition, or healthy eating! 🥗</div>
      </div>
      <div class="chat-input-area">
        <input type="text" id="chatInput" class="form-control" placeholder="Ask about diet..." onkeypress="if(event.key==='Enter')sendChat()">
        <button onclick="sendChat()" class="btn-gold btn" style="white-space:nowrap"><i class="fas fa-paper-plane"></i></button>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Sidebar toggle
document.getElementById('sidebarToggle')?.addEventListener('click', () => {
    document.getElementById('sidebar').classList.toggle('open');
});

// NutriBot responses
const botResponses = {
    'hello': 'Hello! How can I help with your nutrition journey today? 🌟',
    'hi': 'Hi there! Ready to help with your diet plan. What would you like to know?',
    'bmi': 'BMI (Body Mass Index) = weight(kg) / height(m)². Normal BMI is 18.5-24.9. Use our BMI calculator for a detailed analysis!',
    'calories': 'Daily calorie needs vary by person. Generally: 1500-2000 for weight loss, 2000-2500 for maintenance, 2500+ for muscle gain. Check our calorie tracker!',
    'protein': 'Protein goal: 0.8-1.2g per kg body weight for general health, 1.6-2.2g for muscle building. Great sources: chicken, fish, eggs, legumes.',
    'water': 'Aim for 8 glasses (2 litres) daily. More if you exercise! Track your intake with our water tracker.',
    'weight loss': '🏃 Weight Loss Tips:\n• Calorie deficit of 300-500 cal/day\n• High protein diet\n• Regular cardio + strength training\n• Stay hydrated\n• Good sleep (7-8 hrs)',
    'muscle': '💪 Muscle Gain Tips:\n• Calorie surplus of 200-300 cal\n• High protein (1.8-2.2g/kg)\n• Progressive overload training\n• Sufficient rest between workouts',
    'breakfast': '🌅 Healthy Breakfast Ideas:\n• Oatmeal with fruits\n• Greek yogurt with berries\n• Eggs with whole wheat toast\n• Smoothie bowl\n• Avocado toast',
    'lunch': '🌞 Healthy Lunch Ideas:\n• Grilled chicken salad\n• Brown rice + vegetables\n• Tuna sandwich (whole wheat)\n• Quinoa bowl\n• Lentil soup',
    'dinner': '🌙 Healthy Dinner Ideas:\n• Baked salmon + veggies\n• Stir-fry with tofu\n• Chicken + sweet potato\n• Vegetable curry + rice\n• Lean beef + salad',
    'sugar': '⚠️ Reduce sugar intake:\n• Limit to <25g/day (women) <36g (men)\n• Avoid sodas & juice\n• Choose whole fruits\n• Read food labels carefully',
    'help': 'I can help with:\n• Diet plans & tips\n• Calorie information\n• Nutrition advice\n• Exercise guidance\n• Weight management\n• Healthy recipes\n\nJust ask! 😊',
    'default': [
        'Great question! For personalized advice, check out our AI Diet Plan section. 🥗',
        'That\'s a good point about nutrition! Our meal planner can help create the perfect plan for you.',
        'Based on your profile, I recommend logging your meals to track progress! 📊',
        'Consistency is key to achieving your health goals! Keep tracking with NutriGold. 💪',
        'Did you know? Eating slowly helps you eat 20% less! Take time to enjoy your meals. 🍽️'
    ]
};

function toggleChat() {
    const w = document.getElementById('chatWidget');
    const i = document.getElementById('chatIcon');
    if(w.style.display === 'none') {
        w.style.display = 'block';
        i.className = 'fas fa-times';
    } else {
        w.style.display = 'none';
        i.className = 'fas fa-robot';
    }
}

function sendChat() {
    const input = document.getElementById('chatInput');
    const msg = input.value.trim();
    if(!msg) return;

    const messages = document.getElementById('chatMessages');

    // User message
    messages.innerHTML += `<div class="chat-bubble user">${msg}</div>`;

    // Bot response
    const lower = msg.toLowerCase();
    let response = botResponses['default'][Math.floor(Math.random() * botResponses['default'].length)];
    for(const key in botResponses) {
        if(key !== 'default' && lower.includes(key)) {
            response = botResponses[key];
            break;
        }
    }

    setTimeout(() => {
        messages.innerHTML += `<div class="chat-bubble bot"><i class="fas fa-robot me-2" style="color:var(--gold)"></i>${response.replace(/\n/g, '<br>')}</div>`;
        messages.scrollTop = messages.scrollHeight;

        // Save to DB
        const base = (typeof window.BASE_PATH !== 'undefined') ? window.BASE_PATH : '';
        fetch(base + 'api/chat.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({message: msg, response: response})
        }).catch(()=>{});
    }, 600);

    input.value = '';
    messages.scrollTop = messages.scrollHeight;
}

function markAllRead() {
    const base = (typeof window.BASE_PATH !== 'undefined') ? window.BASE_PATH : '';
    fetch(base + 'api/notifications.php?action=mark_read', {method:'POST'})
    .then(() => document.querySelectorAll('.notif-badge').forEach(b => b.remove()));
}
</script>
</body>
</html>
