-- ============================================
-- DATABASE SCHEMA - dietplan_db.sql
-- Diet Plan Management System
-- ============================================

CREATE DATABASE IF NOT EXISTS dietplan_db;
USE dietplan_db;

-- USERS TABLE
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    age INT,
    gender ENUM('male','female','other'),
    weight FLOAT,
    height FLOAT,
    fitness_goal ENUM('weight_loss','weight_gain','maintain') DEFAULT 'maintain',
    activity_level ENUM('sedentary','light','moderate','active','very_active') DEFAULT 'moderate',
    profile_pic VARCHAR(255) DEFAULT 'default.png',
    is_premium TINYINT(1) DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    reset_token VARCHAR(255),
    reset_expires DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ADMIN TABLE
CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- FOOD DATABASE TABLE
CREATE TABLE IF NOT EXISTS foods (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    category VARCHAR(100),
    calories FLOAT NOT NULL,
    protein FLOAT DEFAULT 0,
    carbs FLOAT DEFAULT 0,
    fat FLOAT DEFAULT 0,
    fiber FLOAT DEFAULT 0,
    sugar FLOAT DEFAULT 0,
    sodium FLOAT DEFAULT 0,
    serving_size VARCHAR(100) DEFAULT '100g',
    image VARCHAR(255),
    benefits TEXT,
    is_custom TINYINT(1) DEFAULT 0,
    added_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- MEAL PLANS TABLE
CREATE TABLE IF NOT EXISTS meal_plans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    plan_date DATE NOT NULL,
    meal_type ENUM('breakfast','lunch','dinner','snack') NOT NULL,
    food_id INT,
    custom_food VARCHAR(255),
    quantity FLOAT DEFAULT 1,
    calories FLOAT,
    notes TEXT,
    is_favorite TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- WATER INTAKE TABLE
CREATE TABLE IF NOT EXISTS water_intake (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    intake_date DATE NOT NULL,
    amount_ml FLOAT NOT NULL,
    time_logged TIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- BMI RECORDS TABLE
CREATE TABLE IF NOT EXISTS bmi_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    weight FLOAT NOT NULL,
    height FLOAT NOT NULL,
    bmi FLOAT NOT NULL,
    category VARCHAR(50),
    recorded_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- CHAT MESSAGES TABLE
CREATE TABLE IF NOT EXISTS chat_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    message TEXT NOT NULL,
    is_bot TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- DIET RECOMMENDATIONS TABLE
CREATE TABLE IF NOT EXISTS diet_recommendations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    goal VARCHAR(100),
    daily_calories FLOAT,
    protein_g FLOAT,
    carbs_g FLOAT,
    fat_g FLOAT,
    meal_plan_text TEXT,
    recommended_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- PAYMENTS TABLE
CREATE TABLE IF NOT EXISTS payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    plan_type VARCHAR(100),
    payment_method VARCHAR(100),
    transaction_id VARCHAR(255),
    status ENUM('pending','completed','failed') DEFAULT 'pending',
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- NOTIFICATIONS TABLE
CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    message TEXT NOT NULL,
    type ENUM('meal','water','general') DEFAULT 'general',
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- FEEDBACK TABLE
CREATE TABLE IF NOT EXISTS feedback (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    name VARCHAR(100),
    email VARCHAR(100),
    subject VARCHAR(200),
    message TEXT NOT NULL,
    rating INT DEFAULT 5,
    status ENUM('pending','replied','closed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- USER GOALS TABLE
CREATE TABLE IF NOT EXISTS user_goals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    daily_calorie_goal FLOAT DEFAULT 2000,
    daily_water_goal FLOAT DEFAULT 2500,
    daily_steps_goal INT DEFAULT 10000,
    weekly_workout_goal INT DEFAULT 5,
    target_weight FLOAT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================
-- INSERT DEFAULT ADMIN
-- ============================================
INSERT INTO admins (name, email, password) VALUES 
('Super Admin', 'admin@dietplan.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');
-- Default password: password

-- ============================================
-- INSERT SAMPLE FOODS
-- ============================================
INSERT INTO foods (name, category, calories, protein, carbs, fat, fiber, serving_size, image, benefits) VALUES
('Boiled Egg', 'Protein', 155, 13, 1.1, 11, 0, '100g', 'egg.jpg', 'High protein, good for muscle building, contains vitamins B12 and D'),
('Brown Rice', 'Grains', 216, 5, 45, 1.8, 3.5, '1 cup cooked', 'brown_rice.jpg', 'Complex carbs, high fiber, controls blood sugar'),
('Grilled Chicken Breast', 'Protein', 165, 31, 0, 3.6, 0, '100g', 'chicken.jpg', 'Lean protein, low fat, great for weight loss and muscle building'),
('Banana', 'Fruits', 89, 1.1, 23, 0.3, 2.6, '1 medium', 'banana.jpg', 'Energy boost, potassium rich, good for heart health'),
('Apple', 'Fruits', 52, 0.3, 14, 0.2, 2.4, '1 medium', 'apple.jpg', 'Antioxidants, fiber, promotes gut health'),
('Oatmeal', 'Grains', 71, 2.5, 12, 1.5, 1.7, '100g cooked', 'oatmeal.jpg', 'Heart healthy, lowers cholesterol, sustained energy'),
('Salmon', 'Protein', 208, 20, 0, 13, 0, '100g', 'salmon.jpg', 'Omega-3 fatty acids, brain health, anti-inflammatory'),
('Greek Yogurt', 'Dairy', 100, 17, 6, 0.7, 0, '170g', 'yogurt.jpg', 'Probiotic, high protein, bone health'),
('Spinach', 'Vegetables', 23, 2.9, 3.6, 0.4, 2.2, '100g', 'spinach.jpg', 'Iron rich, antioxidants, eye health, bone strength'),
('Sweet Potato', 'Vegetables', 86, 1.6, 20, 0.1, 3, '100g', 'sweet_potato.jpg', 'Vitamin A, complex carbs, immune boosting'),
('Almonds', 'Nuts', 579, 21, 22, 50, 12.5, '100g', 'almonds.jpg', 'Healthy fats, vitamin E, heart health, energy'),
('Avocado', 'Fruits', 160, 2, 9, 15, 7, '100g', 'avocado.jpg', 'Healthy fats, folate, potassium, skin health'),
('Broccoli', 'Vegetables', 55, 3.7, 11, 0.6, 5.1, '100g', 'broccoli.jpg', 'Vitamin C, cancer fighting compounds, fiber'),
('Quinoa', 'Grains', 222, 8, 39, 3.5, 5, '1 cup cooked', 'quinoa.jpg', 'Complete protein, gluten-free, all 9 essential amino acids'),
('Milk', 'Dairy', 61, 3.2, 4.8, 3.3, 0, '100ml', 'milk.jpg', 'Calcium, vitamin D, bone health'),
('Orange', 'Fruits', 47, 0.9, 12, 0.1, 2.4, '1 medium', 'orange.jpg', 'Vitamin C, immune boost, collagen production'),
('Tuna', 'Protein', 144, 30, 0, 1, 0, '100g', 'tuna.jpg', 'Lean protein, omega-3, heart health'),
('Lentils', 'Legumes', 116, 9, 20, 0.4, 7.9, '100g cooked', 'lentils.jpg', 'Plant protein, iron, folate, weight management'),
('Cottage Cheese', 'Dairy', 206, 28, 3.4, 9, 0, '1 cup', 'cottage_cheese.jpg', 'High protein, low calorie, muscle recovery'),
('Whole Wheat Bread', 'Grains', 247, 13, 41, 3.4, 7, '100g', 'wheat_bread.jpg', 'Complex carbs, B vitamins, sustained energy');

-- INSERT SAMPLE ADMIN USER
INSERT INTO users (name, email, password, age, gender, weight, height, fitness_goal) VALUES
('John Doe', 'user@dietplan.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 25, 'male', 70, 175, 'maintain');
-- Default password: password
