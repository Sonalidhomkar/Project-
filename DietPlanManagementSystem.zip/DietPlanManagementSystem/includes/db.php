<?php
// Start output buffering to prevent "headers already sent" errors
if (!headers_sent()) {
    ob_start();
}

// ============================================
// DATABASE CONNECTION - db.php
// Diet Plan Management System
// ============================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'dietplan_db');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prefer utf8mb4 for full Unicode support.
$conn->set_charset("utf8mb4");

// Ensure database exists, then select it.
$dbName = DB_NAME;
$createDbSql = "CREATE DATABASE IF NOT EXISTS `$dbName` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
if (!$conn->query($createDbSql)) {
    die("Database initialization failed: " . $conn->error);
}
if (!$conn->select_db($dbName)) {
    die("Database selection failed: " . $conn->error);
}

/**
 * Create a new mysqli connection (used for reconnects).
 */
function db_connect(): mysqli {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $conn->set_charset("utf8mb4");

    $dbName = DB_NAME;
    $createDbSql = "CREATE DATABASE IF NOT EXISTS `$dbName` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
    if (!$conn->query($createDbSql)) {
        die("Database initialization failed: " . $conn->error);
    }
    if (!$conn->select_db($dbName)) {
        die("Database selection failed: " . $conn->error);
    }

    return $conn;
}

/**
 * Run a query with a single reconnect attempt if MySQL dropped the connection.
 * Handles common transient errors:
 * - 2006: MySQL server has gone away
 * - 2013: Lost connection to MySQL server during query
 */
function db_query(mysqli &$conn, string $sql) {
    try {
        return $conn->query($sql);
    } catch (mysqli_sql_exception $e) {
        if (in_array((int)$e->getCode(), [2006, 2013], true)) {
            $conn = db_connect();
            return $conn->query($sql);
        }
        throw $e;
    }
}

/**
 * Auto-initialize schema (first run / fresh install).
 * If core tables are missing, import includes/database.sql.
 */
function ensureSchema(mysqli $conn): void {
    $dbName = DB_NAME;
    $requiredTables = [
        'users',
        'admins',
        'foods',
        'meal_plans',
        'water_intake',
        'bmi_records',
        'chat_messages',
        'diet_recommendations',
        'payments',
        'notifications',
        'feedback',
        'user_goals'
    ];

    $placeholders = implode(',', array_fill(0, count($requiredTables), '?'));
    $types = 's' . str_repeat('s', count($requiredTables));

    $stmt = $conn->prepare(
        "SELECT COUNT(DISTINCT table_name) AS cnt
         FROM information_schema.tables
         WHERE table_schema = ? AND table_name IN ($placeholders)"
    );
    if (!$stmt) {
        // If we can't check, fail fast rather than running partial installs.
        die("Schema check failed: " . $conn->error);
    }

    $bindValues = array_merge([$dbName], $requiredTables);
    $stmt->bind_param($types, ...$bindValues);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res ? $res->fetch_assoc() : null;
    $stmt->close();

    $existingCoreTables = isset($row['cnt']) ? (int)$row['cnt'] : 0;
    if ($existingCoreTables === count($requiredTables)) {
        return;
    }

    $schemaPath = __DIR__ . DIRECTORY_SEPARATOR . 'database.sql';
    if (!is_file($schemaPath)) {
        die("Schema file not found: " . $schemaPath);
    }

    $sql = file_get_contents($schemaPath);
    if ($sql === false || trim($sql) === '') {
        die("Schema file is empty or unreadable.");
    }

    if (!$conn->multi_query($sql)) {
        die("Schema import failed: " . $conn->error);
    }

    // Flush all results from multi_query to keep the connection usable.
    do {
        if ($result = $conn->store_result()) {
            $result->free();
        }
    } while ($conn->more_results() && $conn->next_result());

    if ($conn->errno) {
        die("Schema import failed: " . $conn->error);
    }
}

ensureSchema($conn);

// Helper function - sanitize input
function sanitize($conn, $data) {
    return $conn->real_escape_string(htmlspecialchars(strip_tags(trim($data))));
}

// Helper function - redirect
function redirect($url) {
    header("Location: $url");
    exit();
}

// Check if logged in as user
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Check if logged in as admin
function isAdmin() {
    return isset($_SESSION['admin_id']);
}

// Get user info
function getUserInfo($conn, $user_id) {
    $sql = "SELECT * FROM users WHERE id = $user_id";
    $result = $conn->query($sql);
    return $result->fetch_assoc();
}
?>
