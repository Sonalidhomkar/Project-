<?php
// ============================================
// HEADER INCLUDE - header.php
// ============================================

// start buffering in case a downstream redirect is triggered after output
if (!headers_sent()) {
    ob_start();
}
session_start();
require_once __DIR__ . '/db.php';

// Base path so links work from any folder (e.g. /DietPlanManagementSystem or document root)
$base = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
$basePrefix = ($base === '' || $base === '.') ? '' : $base . '/';

if (!isLoggedIn()) { redirect($basePrefix . 'login.php'); }
$user = getUserInfo($conn, $_SESSION['user_id']);
$uid  = $_SESSION['user_id'];

// Get today's calories
$today = date('Y-m-d');
$calRes = $conn->query("SELECT SUM(calories) as total FROM meal_plans WHERE user_id=$uid AND plan_date='$today'");
$todayCal = $calRes->fetch_assoc()['total'] ?? 0;

// Get today's water
$watRes = $conn->query("SELECT SUM(amount_ml) as total FROM water_intake WHERE user_id=$uid AND intake_date='$today'");
$todayWater = $watRes->fetch_assoc()['total'] ?? 0;

// Get user goals
$goalsRes = $conn->query("SELECT * FROM user_goals WHERE user_id=$uid");
$goals = $goalsRes->num_rows > 0 ? $goalsRes->fetch_assoc() : ['daily_calorie_goal'=>2000,'daily_water_goal'=>2500];

// Remove old calorie notifications ("Calories updated: ...") so they don't clutter the bell
$conn->query("DELETE FROM notifications WHERE user_id=$uid AND message LIKE 'Calories updated:%'");

// Unread notifications count (after cleanup)
$notifRes = $conn->query("SELECT COUNT(*) as cnt FROM notifications WHERE user_id=$uid AND is_read=0");
$notifCount = $notifRes->fetch_assoc()['cnt'] ?? 0;

$currentPage = basename($_SERVER['PHP_SELF'], '.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= ucfirst($currentPage) ?> | NutriGold</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="<?= $basePrefix ?>css/style.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>window.BASE_PATH = '<?= $basePrefix ?>';</script>
</head>
<body>

<!-- TOP NAVBAR -->
<nav class="navbar navbar-expand-lg" style="padding-left:20px;padding-right:20px">
  <a class="navbar-brand" href="<?= $basePrefix ?>dashboard.php"><i class="fas fa-leaf me-2" style="color:var(--gold)"></i>NutriGold</a>

  <button class="navbar-toggler ms-2" type="button" id="sidebarToggle">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="topNav">
    <!-- Today's quick stats -->
    <div class="d-flex align-items-center gap-4 ms-4 me-auto">
      <div class="d-none d-lg-flex align-items-center gap-2" style="font-size:0.82rem">
        <i class="fas fa-fire" style="color:var(--gold)"></i>
        <span class="text-muted-gold"><?= round($todayCal) ?> / <?= $goals['daily_calorie_goal'] ?> cal</span>
      </div>
      <div class="d-none d-lg-flex align-items-center gap-2" style="font-size:0.82rem">
        <i class="fas fa-tint" style="color:#17a2b8"></i>
        <span class="text-muted-gold"><?= round($todayWater) ?>ml / <?= $goals['daily_water_goal'] ?>ml water</span>
      </div>
    </div>

    <div class="d-flex align-items-center gap-3">
      <!-- Notifications -->
      <div class="dropdown">
        <button class="btn-dark-card btn position-relative" data-bs-toggle="dropdown">
          <i class="fas fa-bell"></i>
          <?php if($notifCount > 0): ?>
          <span class="notif-badge"><?= $notifCount ?></span>
          <?php endif; ?>
        </button>
        <div class="dropdown-menu dropdown-menu-end" style="background:var(--black-card);border:var(--border-gold);width:320px;padding:0;border-radius:var(--radius)">
          <div style="padding:14px 18px;border-bottom:var(--border-gold);display:flex;justify-content:space-between;align-items:center">
            <span class="gold-text font-weight-700"><i class="fas fa-bell me-2"></i>Notifications</span>
            <?php if($notifCount>0): ?><a href="#" onclick="markAllRead()" style="color:var(--gray-text);font-size:0.8rem;text-decoration:none">Mark all read</a><?php endif; ?>
          </div>
          <?php
          $notifs = $conn->query("SELECT * FROM notifications WHERE user_id=$uid ORDER BY created_at DESC LIMIT 5");
          if($notifs->num_rows > 0):
            while($n = $notifs->fetch_assoc()):
          ?>
          <div class="notif-item <?= !$n['is_read'] ? 'unread' : '' ?>">
            <div style="font-size:0.85rem;color:var(--white)"><?= htmlspecialchars($n['message']) ?></div>
            <div style="font-size:0.72rem;color:var(--gray-text);margin-top:3px"><?= date('M j, g:i A', strtotime($n['created_at'])) ?></div>
          </div>
          <?php endwhile; else: ?>
          <div style="padding:20px;text-align:center;color:var(--gray-text)">No notifications</div>
          <?php endif; ?>
        </div>
      </div>

      <!-- User Dropdown -->
      <div class="dropdown">
        <button class="btn-dark-card btn d-flex align-items-center gap-2" data-bs-toggle="dropdown">
          <div style="width:32px;height:32px;background:var(--gold-gradient);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#000;font-weight:700;font-size:0.9rem">
            <?= strtoupper(substr($user['name'],0,1)) ?>
          </div>
          <span class="d-none d-md-block" style="font-size:0.88rem"><?= htmlspecialchars($user['name']) ?></span>
          <i class="fas fa-chevron-down" style="font-size:0.7rem;color:var(--gray-text)"></i>
        </button>
        <ul class="dropdown-menu dropdown-menu-end" style="background:var(--black-card);border:var(--border-gold)">
          <?php
          $menuItems = [
            ['fas fa-tachometer-alt','dashboard','Dashboard'],
            ['fas fa-user','profile','My Profile'],
            ['fas fa-cog','profile','Settings'],
          ];
          foreach($menuItems as $m): ?>
          <li><a class="dropdown-item" href="<?= $basePrefix . $m[1] . '.php' ?>" style="color:var(--gray-text);font-size:0.88rem;padding:10px 16px;transition:all 0.2s" onmouseover="this.style.color='var(--gold)';this.style.background='rgba(255,215,0,0.05)'" onmouseout="this.style.color='var(--gray-text)';this.style.background='transparent'">
            <i class="<?=$m[0]?> me-2" style="color:var(--gold);width:16px"></i><?=$m[2]?>
          </a></li>
          <?php endforeach; ?>
          <li><hr style="border-color:rgba(255,215,0,0.2);margin:5px 0"></li>
          <li><a class="dropdown-item" href="<?= $basePrefix ?>logout.php" style="color:#dc3545;font-size:0.88rem;padding:10px 16px">
            <i class="fas fa-sign-out-alt me-2"></i>Logout
          </a></li>
        </ul>
      </div>
    </div>
  </div>
</nav>

<!-- WRAPPER -->
<div style="display:flex;flex-direction:row;min-height:calc(100vh - 64px);width:100%">

<!-- SIDEBAR -->
<div class="sidebar" id="sidebar">
  <div style="padding:20px 24px 10px;border-bottom:var(--border-gold);margin-bottom:10px">
    <div class="d-flex align-items-center gap-3">
      <div style="width:48px;height:48px;background:var(--gold-gradient);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#000;font-weight:800;font-size:1.1rem">
        <?= strtoupper(substr($user['name'],0,1)) ?>
      </div>
      <div>
        <div style="font-weight:700;font-size:0.9rem"><?= htmlspecialchars($user['name']) ?></div>
        <div class="text-muted-gold" style="font-size:0.75rem"><?= ucfirst($user['fitness_goal'] ?? 'maintain') ?></div>
        <?php if($user['is_premium']): ?>
        <span class="badge-gold mt-1 d-inline-block">Premium</span>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div class="sidebar-menu">
    <div class="menu-section">Main</div>
    <?php
    $menu = [
      ['fas fa-tachometer-alt','dashboard.php','Dashboard','dashboard'],
      ['fas fa-calculator','bmi.php','BMI Calculator','bmi'],
      ['fas fa-brain','diet.php','AI Diet Plan','diet'],
    ];
    foreach($menu as $m): ?>
    <a href="<?= $basePrefix . $m[1] ?>" class="<?= $currentPage==$m[3] ? 'active' : '' ?>">
      <i class="<?=$m[0]?>"></i><?=$m[2]?>
    </a>
    <?php endforeach; ?>

    <div class="menu-section">Tracking</div>
    <?php
    $menu2 = [
      ['fas fa-calendar-alt','mealplanner.php','Meal Planner','mealplanner'],
      ['fas fa-fire','calories.php','Calories','calories'],
      ['fas fa-tint','water.php','Water Intake','water'],
    ];
    foreach($menu2 as $m): ?>
    <a href="<?= $basePrefix . $m[1] ?>" class="<?= $currentPage==$m[3] ? 'active' : '' ?>">
      <i class="<?=$m[0]?>"></i><?=$m[2]?>
    </a>
    <?php endforeach; ?>

    <div class="menu-section">Reports & More</div>
    <?php
    $menu3 = [
      ['fas fa-chart-bar','report.php','Reports','report'],
      ['fas fa-utensils','food.php','Food Database','food'],
      ['fas fa-comments','chat.php','AI Chat','chat'],
    ];
    foreach($menu3 as $m): ?>
    <a href="<?= $basePrefix . $m[1] ?>" class="<?= $currentPage==$m[3] ? 'active' : '' ?>">
      <i class="<?=$m[0]?>"></i><?=$m[2]?>
    </a>
    <?php endforeach; ?>

    <div class="menu-section">Account</div>
    <a href="<?= $basePrefix ?>profile.php" class="<?= $currentPage=='profile' ? 'active' : '' ?>"><i class="fas fa-user"></i>My Profile</a>
    <a href="<?= $basePrefix ?>feedback.php" class="<?= $currentPage=='feedback' ? 'active' : '' ?>"><i class="fas fa-star"></i>Feedback</a>
    <a href="<?= $basePrefix ?>logout.php" style="color:#dc3545 !important"><i class="fas fa-sign-out-alt"></i>Logout</a>
  </div>
</div>

<div class="main-content" id="mainContent" style="flex:1;overflow-y:auto">
