<?php
http_response_code;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Page Not Found</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: #0A0A0A;
            color: #FFFFFF;
            font-family: 'Poppins', sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }
        .error-container {
            text-align: center;
            max-width: 500px;
        }
        .error-code {
            font-size: 8rem;
            color: #FFD700;
            font-weight: 800;
            margin: 0;
        }
        .error-title {
            font-size: 2rem;
            color: #FFD700;
            margin: 20px 0;
        }
        .error-message {
            color: #AAAAAA;
            font-size: 1rem;
            margin: 20px 0;
        }
        .btn-gold {
            background: #FFD700;
            color: #000;
            border: none;
            padding: 12px 30px;
            border-radius: 8px;
            font-weight: 700;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
            transition: all 0.3s;
        }
        .btn-gold:hover {
            background: #FFE44D;
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(255, 215, 0, 0.3);
        }
        .navbar-brand-style {
            color: #FFD700;
            font-size: 1.8rem;
            font-weight: 800;
            text-decoration: none;
            margin-bottom: 40px;
            display: inline-block;
        }
    </style>
</head>
<body>
    <div class="error-container">
        <a href="index.php" class="navbar-brand-style">
            <i class="fas fa-leaf me-2"></i>NutriGold
        </a>
        <div class="error-code">404</div>
        <div class="error-title">Page Not Found</div>
        <div class="error-message">
            <p>Sorry! The page you're looking for doesn't exist.</p>
            <p style="font-size: 0.9rem; color: #888;">
                <strong>Requested URL:</strong> <?= htmlspecialchars($_SERVER['REQUEST_URI']) ?>
            </p>
        </div>
        <a href="index.php" class="btn-gold"><i class="fas fa-home me-2"></i>Go to Home</a>
        <a href="dashboard.php" class="btn-gold" style="margin-left: 10px;"><i class="fas fa-chart-bar me-2"></i>Dashboard</a>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
