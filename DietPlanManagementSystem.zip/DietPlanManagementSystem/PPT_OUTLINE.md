# Diet Plan Management System (NutriGold) — PPT Outline

## Slide 1 — Title
- Diet Plan Management System (NutriGold)
- Name, Class, Roll No, Guide/College

## Slide 2 — Abstract
- PHP + MySQL web app for meal planning and health tracking
- Tracks calories, water, BMI; provides reports
- Admin panel for management + analytics

## Slide 3 — Problem Statement
- Users need a simple system to plan meals and track health data consistently
- Manual tracking is difficult and error-prone

## Slide 4 — Objectives
- User authentication (secure sessions)
- Meal planning + calorie tracking
- Water intake tracking
- BMI calculation + history
- Diet recommendations storage
- Chat assistant + logging
- Admin management (users, foods, feedback)

## Slide 5 — Technologies Used
- Frontend: HTML, CSS, Bootstrap 5, Font Awesome, Chart.js
- Backend: PHP
- Database: MySQL (XAMPP)
- Auth: Session-based

## Slide 6 — System Architecture
- Presentation layer: PHP pages + Bootstrap UI
- Business logic: PHP + includes
- Data layer: MySQL (`dietplan_db`)

## Slide 7 — Folder Structure
- `includes/` (db, header, footer, schema)
- `admin/` (admin pages)
- `api/` (AJAX endpoints)
- Root pages: dashboard, planner, trackers, etc.

## Slide 8 — Main Modules (User)
- Dashboard
- Meal Planner
- Calories Tracker
- Water Tracker
- BMI Calculator
- AI Diet Plan
- Food Database
- Reports
- Feedback
- AI Chat (NutriBot)

## Slide 9 — Main Modules (Admin)
- Admin Dashboard
- Manage Users
- Manage Foods
- Reports / Analytics
- Feedback handling

## Slide 10 — Database Tables
- users, admins
- foods, meal_plans
- water_intake, bmi_records
- diet_recommendations, chat_messages
- notifications, feedback, payments, user_goals

## Slide 11 — Diagrams: Context Diagram (Mermaid)
```mermaid
flowchart LR
  U[User] -->|Requests| S((NutriGold System))
  A[Admin] -->|Admin Operations| S
  S <-->|Read/Write| DB[(MySQL: dietplan_db)]
```

## Slide 12 — Diagrams: DFD Level-0
```mermaid
flowchart LR
  U[User] --> P1((Auth))
  U --> P2((Meal Planning))
  U --> P3((Tracking))
  U --> P4((Diet Recommendations))
  U --> P5((Chat))
  U --> P6((Feedback))
  A[Admin] --> P7((Admin Panel))
  DB[(Database)] <--> P1
  DB <--> P2
  DB <--> P3
  DB <--> P4
  DB <--> P5
  DB <--> P6
  DB <--> P7
```

## Slide 13 — Diagrams: DFD Level-1 (Detailed)
```mermaid
flowchart TB
  U[User]
  A[Admin]
  DBU[(users)]
  DBA[(admins)]
  DBF[(foods)]
  DBM[(meal_plans)]
  DBW[(water_intake)]
  DBB[(bmi_records)]
  DBD[(diet_recommendations)]
  DBC[(chat_messages)]
  DBFB[(feedback)]
  DBG[(user_goals)]

  U --> P1((Register/Login)) --> DBU
  U --> P2((Dashboard & Goals)) --> DBM
  P2 --> DBW
  P2 --> DBB
  P2 --> DBG

  U --> P3((Meal Planner)) --> DBM
  P3 --> DBF

  U --> P4((Calories/Water/BMI)) --> DBM
  P4 --> DBW
  P4 --> DBB

  U --> P5((Diet Plan)) --> DBD
  U --> P6((Chat)) --> DBC
  U --> P7((Feedback)) --> DBFB

  A --> P8((Admin Login)) --> DBA
  A --> P9((Manage Users)) --> DBU
  A --> P10((Manage Foods)) --> DBF
  A --> P11((Reports)) --> DBM
```

## Slide 14 — Working / Output Screens
- Login screen
- Dashboard screen (charts)
- Meal planner screen
- Calories/water tracking screen
- BMI screen
- Admin dashboard screen

## Slide 15 — Testing (Sample)
- Login valid/invalid
- Meal plan insert + fetch
- Water log update
- BMI record insertion
- Admin access control
- Chat message saved to DB

## Slide 16 — Conclusion
- Provides an integrated platform for diet planning and health tracking
- Admin panel improves data control and monitoring

## Slide 17 — Future Scope
- Prepared statements everywhere
- CSRF protection
- Real AI integration
- Advanced reports (PDF export)

