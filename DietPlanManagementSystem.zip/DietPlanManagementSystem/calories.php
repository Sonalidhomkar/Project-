<?php
require_once 'includes/header.php';

// ---- Handle add meal ----
if (isset($_POST['add_meal'])) {
    $food_id   = (int)($_POST['food_id'] ?? 0);
    $custom    = sanitize($conn, $_POST['custom_food'] ?? '');
    $meal_type = sanitize($conn, $_POST['meal_type']);
    $quantity  = max(0.1,(float)$_POST['quantity']);
    $date      = sanitize($conn, $_POST['plan_date']);
    $notes     = sanitize($conn, $_POST['notes'] ?? '');

    if ($food_id > 0) {
        $food = $conn->query("SELECT * FROM foods WHERE id=$food_id")->fetch_assoc();
        $cal  = round($food['calories'] * $quantity);
        $conn->query("INSERT INTO meal_plans (user_id,plan_date,meal_type,food_id,quantity,calories,notes) VALUES ($uid,'$date','$meal_type',$food_id,$quantity,$cal,'$notes')");
    } elseif($custom) {
        $cal = (float)$_POST['custom_cal'];
        $conn->query("INSERT INTO meal_plans (user_id,plan_date,meal_type,custom_food,quantity,calories,notes) VALUES ($uid,'$date','$meal_type','$custom',$quantity,$cal,'$notes')");
    }

    redirect('calories.php');
}

// ---- Handle delete ----
if (isset($_GET['delete'])) {
    $conn->query("DELETE FROM meal_plans WHERE id=".(int)$_GET['delete']." AND user_id=$uid");
    redirect('calories.php');
}

// ---- Data ----
$foods    = $conn->query("SELECT id,name,calories,protein,carbs,fat,category FROM foods ORDER BY name");
$foodList = [];
while($f=$foods->fetch_assoc()) $foodList[]=$f;

$selectedDate = isset($_GET['date']) ? sanitize($conn,$_GET['date']) : $today;
$meals = $conn->query("SELECT mp.*,f.name as food_name,f.protein,f.carbs,f.fat FROM meal_plans mp LEFT JOIN foods f ON mp.food_id=f.id WHERE mp.user_id=$uid AND mp.plan_date='$selectedDate' ORDER BY FIELD(mp.meal_type,'breakfast','lunch','dinner','snack')");

$mealRows = [];
while($m=$meals->fetch_assoc()) $mealRows[]=$m;

$totals = ['cal'=>0,'prot'=>0,'carbs'=>0,'fat'=>0];
foreach($mealRows as $m) {
    $totals['cal']   += $m['calories'];
    $totals['prot']  += ($m['protein']??0) * $m['quantity'];
    $totals['carbs'] += ($m['carbs']??0) * $m['quantity'];
    $totals['fat']   += ($m['fat']??0) * $m['quantity'];
}

$calGoal = $conn->query("SELECT daily_calorie_goal FROM user_goals WHERE user_id=$uid")->fetch_assoc()['daily_calorie_goal'] ?? 2000;

// Group by meal type
$grouped = ['breakfast'=>[],'lunch'=>[],'dinner'=>[],'snack'=>[]];
foreach($mealRows as $m) $grouped[$m['meal_type']][]=$m;
?>

<div class="page-header">
  <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
    <div>
      <h2><i class="fas fa-fire me-3"></i>Calorie &amp; Nutrition Tracker</h2>
      <p>Track your daily food intake and macronutrients</p>
    </div>
    <div class="d-flex gap-2">
      <input type="date" id="dateFilter" class="form-control" style="width:160px" value="<?=$selectedDate?>" onchange="location.href='calories.php?date='+this.value">
      <button class="btn-gold btn" data-bs-toggle="modal" data-bs-target="#addMealModal"><i class="fas fa-plus me-2"></i>Add Food</button>
    </div>
  </div>
</div>

<!-- Summary Cards -->
<div class="row g-3 mb-4">
  <?php
  $calPct = min(100,round($totals['cal']/$calGoal*100));
  $remaining = max(0,$calGoal-$totals['cal']);
  foreach([['fas fa-fire','Calories',round($totals['cal']).' / '.$calGoal.' kcal','var(--gold)',$calPct],['fas fa-drumstick-bite','Protein',round($totals['prot']).'g','#28a745',min(100,round($totals['prot']/150*100))],['fas fa-bread-slice','Carbs',round($totals['carbs']).'g','#ffc107',min(100,round($totals['carbs']/300*100))],['fas fa-bacon','Fat',round($totals['fat']).'g','#17a2b8',min(100,round($totals['fat']/65*100))]] as $s):
  ?>
  <div class="col-md-3 col-6">
    <div class="card-stat">
      <div class="stat-icon"><i class="<?=$s[0]?>" style="color:<?=$s[3]?>"></i></div>
      <div class="stat-value" style="color:<?=$s[3]?>;font-size:1.4rem"><?=$s[2]?></div>
      <div class="stat-label"><?=$s[1]?></div>
      <div class="progress-gold mt-2" style="height:5px"><div class="progress-bar" style="width:<?=$s[4]?>%;background:<?=$s[3]?>"></div></div>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Remaining Calories Alert -->
<?php if($remaining > 0): ?>
<div class="alert-gold mb-4"><i class="fas fa-info-circle me-2"></i>You can still eat <strong><?=$remaining?> kcal</strong> today to meet your goal of <?=$calGoal?> kcal.</div>
<?php elseif($totals['cal'] > $calGoal): ?>
<div class="alert-danger-dark mb-4"><i class="fas fa-exclamation-circle me-2"></i>You've exceeded your daily calorie goal by <strong><?=round($totals['cal']-$calGoal)?> kcal</strong>.</div>
<?php endif; ?>

<div class="row g-4">
  <!-- Meal Groups -->
  <div class="col-lg-8">
    <?php
    $mealIcons = ['breakfast'=>['🌅','Breakfast'],'lunch'=>['☀️','Lunch'],'dinner'=>['🌙','Dinner'],'snack'=>['🍎','Snacks']];
    foreach($mealIcons as $type=>[$icon,$label]):
      $items = $grouped[$type];
      $mealCal = array_sum(array_column($items,'calories'));
    ?>
    <div class="card-gold mb-4">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <div class="d-flex align-items-center gap-3">
          <span style="font-size:1.5rem"><?=$icon?></span>
          <div>
            <div style="font-weight:700;font-size:1rem"><?=$label?></div>
            <div class="text-muted-gold" style="font-size:0.78rem"><?=count($items)?> items &bull; <?=round($mealCal)?> kcal</div>
          </div>
        </div>
        <button class="btn-outline-gold btn btn-sm" data-bs-toggle="modal" data-bs-target="#addMealModal" onclick="document.getElementById('mealTypeSelect').value='<?=$type?>'">
          <i class="fas fa-plus me-1"></i>Add
        </button>
      </div>
      <?php if($items): ?>
      <table class="table-dark-gold w-100">
        <thead><tr><th>Food</th><th>Qty</th><th>Cal</th><th>P</th><th>C</th><th>F</th><th></th></tr></thead>
        <tbody>
        <?php foreach($items as $m): ?>
        <tr>
          <td style="font-weight:600"><?=htmlspecialchars($m['food_name']??$m['custom_food']??'?')?></td>
          <td class="text-muted-gold"><?=$m['quantity']?>x</td>
          <td><span class="gold-text font-weight-700"><?=round($m['calories'])?></span></td>
          <td style="color:#28a745"><?=round(($m['protein']??0)*$m['quantity'])?>g</td>
          <td style="color:#ffc107"><?=round(($m['carbs']??0)*$m['quantity'])?>g</td>
          <td style="color:#17a2b8"><?=round(($m['fat']??0)*$m['quantity'])?>g</td>
          <td><a href="calories.php?delete=<?=$m['id']?>" onclick="return confirm('Delete?')" style="color:#dc3545;font-size:0.85rem"><i class="fas fa-trash"></i></a></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      <?php else: ?>
      <div class="text-center py-3 text-muted-gold" style="font-size:0.88rem">No <?=strtolower($label)?> logged yet</div>
      <?php endif; ?>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Right: Charts & Summary -->
  <div class="col-lg-4">
    <div class="chart-container mb-4">
      <div class="section-title"><i class="fas fa-chart-pie me-2"></i>Macro Breakdown</div>
      <canvas id="macroPieChart" height="180"></canvas>
    </div>
    <!-- Food Search Quick Add -->
    <div class="card-gold">
      <div class="section-title"><i class="fas fa-search me-2"></i>Quick Food Search</div>
      <input type="text" id="foodSearch" class="form-control mb-3" placeholder="Search foods..." oninput="searchFoods(this.value)">
      <div id="searchResults" style="max-height:250px;overflow-y:auto">
        <?php foreach(array_slice($foodList,0,5) as $f): ?>
        <div class="food-search-item p-2 mb-1" style="background:var(--black-input);border:var(--border-gold);border-radius:8px;cursor:pointer;transition:all 0.2s" onclick="quickAdd(<?=$f['id']?>,'<?=addslashes($f['name'])?>',<?=$f['calories']?>)" onmouseover="this.style.background='rgba(255,215,0,0.05)'" onmouseout="this.style.background='var(--black-input)'">
          <div style="font-weight:600;font-size:0.88rem"><?=htmlspecialchars($f['name'])?></div>
          <div class="d-flex gap-3" style="font-size:0.75rem;color:var(--gray-text)">
            <span class="gold-text"><?=$f['calories']?> kcal</span>
            <span style="color:#28a745">P:<?=$f['protein']?>g</span>
            <span style="color:#ffc107">C:<?=$f['carbs']?>g</span>
            <span style="color:#17a2b8">F:<?=$f['fat']?>g</span>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<!-- Add Meal Modal -->
<div class="modal fade" id="addMealModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-dark">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="fas fa-plus me-2"></i>Add Food to Meal Plan</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST">
        <div class="modal-body">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">Meal Type</label>
              <select name="meal_type" id="mealTypeSelect" class="form-select" required>
                <option value="breakfast">🌅 Breakfast</option>
                <option value="lunch">☀️ Lunch</option>
                <option value="dinner">🌙 Dinner</option>
                <option value="snack">🍎 Snack</option>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label">Date</label>
              <input type="date" name="plan_date" class="form-control" value="<?=$selectedDate?>" required>
            </div>
            <div class="col-12">
              <ul class="nav nav-tabs mb-3" style="border-color:rgba(255,215,0,0.3)">
                <li class="nav-item">
                  <a class="nav-link active" id="tab-food" href="#" onclick="switchTab('food')" style="color:var(--gold);background:rgba(255,215,0,0.1);border-color:rgba(255,215,0,0.3)">Food Database</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" id="tab-custom" href="#" onclick="switchTab('custom')" style="color:var(--gray-text)">Custom Food</a>
                </li>
              </ul>
              <!-- Food DB Tab -->
              <div id="tab-food-content">
                <label class="form-label">Select Food</label>
                <select name="food_id" id="foodSelect" class="form-select">
                  <option value="">-- Select from database --</option>
                  <?php foreach($foodList as $f): ?>
                  <option value="<?=$f['id']?>" data-cal="<?=$f['calories']?>" data-prot="<?=$f['protein']?>" data-carb="<?=$f['carbs']?>" data-fat="<?=$f['fat']?>"><?=htmlspecialchars($f['name'])?> (<?=$f['calories']?> kcal)</option>
                  <?php endforeach; ?>
                </select>
              </div>
              <!-- Custom Tab -->
              <div id="tab-custom-content" style="display:none">
                <div class="row g-2">
                  <div class="col-8"><input type="text" name="custom_food" class="form-control" placeholder="Food name"></div>
                  <div class="col-4"><input type="number" name="custom_cal" class="form-control" placeholder="Calories" min="0"></div>
                </div>
              </div>
            </div>
            <div class="col-6">
              <label class="form-label">Quantity (servings)</label>
              <input type="number" name="quantity" class="form-control" value="1" min="0.1" step="0.1" required>
            </div>
            <div class="col-6">
              <label class="form-label">Est. Calories</label>
              <input type="text" id="calPreview" class="form-control" readonly style="color:var(--gold);font-weight:700">
            </div>
            <div class="col-12">
              <label class="form-label">Notes (optional)</label>
              <input type="text" name="notes" class="form-control" placeholder="e.g. grilled, no sauce">
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn-dark-card btn" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" name="add_meal" class="btn-gold btn"><i class="fas fa-plus me-2"></i>Add to Meal Plan</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
// Keep today's selected date calories & goal in localStorage for cross-page notifications
try {
    if ('<?= $selectedDate ?>' === '<?= $today ?>') {
        localStorage.setItem('NUTRIGOLD_TODAY_CALORIES', String(<?= (int)$totals['cal'] ?>));
        localStorage.setItem('NUTRIGOLD_GOAL_CALORIES', String(<?= (int)$calGoal ?>));
    }
} catch (e) {
    // ignore if storage is blocked
}

const foodData = <?=json_encode($foodList)?>;

new Chart(document.getElementById('macroPieChart'),{
    type:'doughnut',
    data:{
        labels:['Protein','Carbs','Fat'],
        datasets:[{data:[<?=round($totals['prot'])||1?>,<?=round($totals['carbs'])||1?>,<?=round($totals['fat'])||1?>],backgroundColor:['rgba(40,167,69,0.8)','rgba(255,193,7,0.8)','rgba(23,162,184,0.8)'],borderColor:['#28a745','#ffc107','#17a2b8'],borderWidth:2}]
    },
    options:{cutout:'65%',plugins:{legend:{labels:{color:'#aaa',font:{size:11}}}}}
});

document.getElementById('foodSelect').addEventListener('change',function(){
    const opt=this.options[this.selectedIndex];
    const q=parseFloat(document.querySelector('[name="quantity"]').value)||1;
    document.getElementById('calPreview').value=(opt.dataset.cal?Math.round(opt.dataset.cal*q)+' kcal':'');
});

function switchTab(t){
    document.getElementById('tab-food-content').style.display=t==='food'?'block':'none';
    document.getElementById('tab-custom-content').style.display=t==='custom'?'block':'none';
    document.getElementById('tab-food').className='nav-link'+(t==='food'?' active':'');
    document.getElementById('tab-custom').className='nav-link'+(t==='custom'?' active':'');
    if(t==='food'){document.getElementById('tab-food').style.cssText='color:var(--gold);background:rgba(255,215,0,0.1);border-color:rgba(255,215,0,0.3)';}
    else{document.getElementById('tab-custom').style.cssText='color:var(--gold);background:rgba(255,215,0,0.1);border-color:rgba(255,215,0,0.3)';}
}

function searchFoods(q){
    const res=document.getElementById('searchResults');
    if(!q){res.innerHTML='';return;}
    const matches=foodData.filter(f=>f.name.toLowerCase().includes(q.toLowerCase())).slice(0,8);
    res.innerHTML=matches.map(f=>`<div class="food-search-item p-2 mb-1" style="background:var(--black-input);border:var(--border-gold);border-radius:8px;cursor:pointer" onclick="quickAdd(${f.id},'${f.name.replace(/'/g,"\\'")}',${f.calories})"><div style="font-weight:600;font-size:0.88rem">${f.name}</div><div style="font-size:0.75rem;color:var(--gray-text)"><span class="gold-text">${f.calories} kcal</span> P:${f.protein}g C:${f.carbs}g F:${f.fat}g</div></div>`).join('');
}

function quickAdd(id,name,cal){
    document.getElementById('foodSelect').value=id;
    document.getElementById('calPreview').value=cal+' kcal';
    new bootstrap.Modal(document.getElementById('addMealModal')).show();
}
</script>

<?php require_once 'includes/footer.php'; ?>
