<?php
require_once 'includes/header.php';
?>

<div class="page-header">
  <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
    <div>
      <h2><i class="fas fa-comments me-3"></i>AI Chat</h2>
      <p>Chat with <span class="gold-text font-weight-700">NutriBot</span> for quick nutrition tips and healthy meal ideas.</p>
    </div>
    <div class="d-flex gap-2">
      <button class="btn-gold btn" onclick="openChatFromPage()">
        <i class="fas fa-robot me-2"></i>Start Chat
      </button>
    </div>
  </div>
</div>

<div class="row g-4">
  <div class="col-lg-7">
    <div class="card-gold h-100">
      <div class="section-title"><i class="fas fa-lightbulb me-2"></i>Try asking</div>
      <div class="text-muted-gold" style="line-height:1.7">
        <div class="mb-2"><span class="badge-info">Calories</span> “How many calories should I eat daily?”</div>
        <div class="mb-2"><span class="badge-info">Protein</span> “How much protein do I need for muscle gain?”</div>
        <div class="mb-2"><span class="badge-info">Weight Loss</span> “Give me a simple weight loss meal plan.”</div>
        <div class="mb-2"><span class="badge-info">Breakfast</span> “Healthy breakfast ideas under 400 calories.”</div>
        <div class="mb-2"><span class="badge-info">Water</span> “How much water should I drink per day?”</div>
      </div>
      <hr style="border-color:rgba(255,215,0,0.15)">
      <div class="text-muted-gold" style="font-size:0.9rem">
        Tip: the chat opens from the floating robot button (bottom-right) too.
      </div>
    </div>
  </div>

  <div class="col-lg-5">
    <div class="card-gold h-100">
      <div class="section-title"><i class="fas fa-shield-alt me-2"></i>Privacy</div>
      <div class="text-muted-gold" style="line-height:1.7">
        We store your messages to improve your experience inside the app.
        Avoid sharing passwords, OTPs, or sensitive personal information.
      </div>
    </div>
  </div>
</div>

<script>
function openChatFromPage() {
  const w = document.getElementById('chatWidget');
  if (!w) return;
  if (w.style.display === 'none') toggleChat();
  const input = document.getElementById('chatInput');
  if (input) input.focus();
}

// Open chat automatically when visiting this page
window.addEventListener('load', () => {
  openChatFromPage();
});
</script>

<?php
require_once 'includes/footer.php';
?>

