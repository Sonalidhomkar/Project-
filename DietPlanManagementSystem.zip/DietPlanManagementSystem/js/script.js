// ============================================
// GLOBAL SCRIPTS - script.js
// NutriGold Diet Plan Management System
// ============================================

document.addEventListener('DOMContentLoaded', function () {

    // ---- SIDEBAR TOGGLE (Mobile) ----
    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebar       = document.getElementById('sidebar');
    const mainContent   = document.getElementById('mainContent');

    if (sidebarToggle && sidebar) {
        sidebarToggle.addEventListener('click', () => {
            sidebar.classList.toggle('open');
        });
        // Close sidebar when clicking outside
        document.addEventListener('click', (e) => {
            if (!sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
                sidebar.classList.remove('open');
            }
        });
    }

    // ---- ANIMATE ON SCROLL ----
    const animateOnScroll = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
                entry.target.style.opacity = '1';
            }
        });
    }, { threshold: 0.1 });

    document.querySelectorAll('.card-gold, .card-stat, .food-card, .plan-card').forEach(el => {
        el.style.opacity = '0';
        animateOnScroll.observe(el);
    });

    // ---- TOOLTIP INIT ----
    const tooltips = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    tooltips.forEach(t => new bootstrap.Tooltip(t));

    // ---- FORM VALIDATION ----
    const forms = document.querySelectorAll('form[data-validate="true"]');
    forms.forEach(form => {
        form.addEventListener('submit', function (e) {
            if (!form.checkValidity()) {
                e.preventDefault();
                e.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    });

    // ---- AUTO HIDE ALERTS ----
    document.querySelectorAll('.alert-success-dark, .alert-gold').forEach(alert => {
        setTimeout(() => {
            alert.style.transition = 'opacity 0.5s ease';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        }, 5000);
    });

    // ---- NUMBER COUNTER ANIMATION ----
    document.querySelectorAll('.stat-value').forEach(el => {
        const target = parseFloat(el.textContent.replace(/[^0-9.]/g, ''));
        if (!isNaN(target) && target > 0) {
            let start = 0;
            const step = target / 40;
            const timer = setInterval(() => {
                start += step;
                if (start >= target) { start = target; clearInterval(timer); }
                el.textContent = el.textContent.replace(/[\d.]+/, Math.round(start));
            }, 30);
        }
    });

    // ---- TABLE ROW HIGHLIGHT ----
    document.querySelectorAll('.table-dark-gold tbody tr').forEach(row => {
        row.addEventListener('mouseenter', () => row.style.background = 'rgba(255,215,0,0.04)');
        row.addEventListener('mouseleave', () => row.style.background = '');
    });

    // ---- CONFIRM DELETE BUTTONS ----
    document.querySelectorAll('[data-confirm]').forEach(btn => {
        btn.addEventListener('click', function (e) {
            if (!confirm(this.dataset.confirm || 'Are you sure?')) {
                e.preventDefault();
            }
        });
    });

    // ---- DATE INPUT: Set today as default ----
    document.querySelectorAll('input[type="date"]:not([value])').forEach(input => {
        input.valueAsDate = new Date();
    });

    // ---- SEARCH HIGHLIGHT ----
    const searchInput = document.getElementById('foodSearch');
    if (searchInput) {
        searchInput.addEventListener('input', debounce(function () {
            highlightSearchResults(this.value);
        }, 300));
    }

    // ---- PRINT STYLES ----
    window.addEventListener('beforeprint', () => {
        document.body.style.background = '#fff';
    });
    window.addEventListener('afterprint', () => {
        document.body.style.background = '';
    });

});

// ============================================
// UTILITY FUNCTIONS
// ============================================

// Debounce
function debounce(fn, delay) {
    let timer;
    return function (...args) {
        clearTimeout(timer);
        timer = setTimeout(() => fn.apply(this, args), delay);
    };
}

// Highlight search results
function highlightSearchResults(query) {
    if (!query) return;
    document.querySelectorAll('.food-search-item .food-name').forEach(el => {
        const text = el.textContent;
        const regex = new RegExp(`(${query})`, 'gi');
        el.innerHTML = text.replace(regex, '<mark style="background:var(--gold);color:#000;border-radius:2px;padding:0 2px">$1</mark>');
    });
}

// Format number with commas
function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

// Calculate calories from macros
function calcCalories(protein, carbs, fat) {
    return Math.round(protein * 4 + carbs * 4 + fat * 9);
}

// BMI Category
function getBMICategory(bmi) {
    if (bmi < 18.5) return { label: 'Underweight', color: '#17a2b8' };
    if (bmi < 25)   return { label: 'Normal',       color: '#28a745' };
    if (bmi < 30)   return { label: 'Overweight',   color: '#ffc107' };
    return              { label: 'Obese',        color: '#dc3545' };
}

// Toast notification
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    const colors = { success: '#28a745', error: '#dc3545', warning: '#ffc107', info: '#17a2b8' };
    toast.style.cssText = `
        position:fixed;bottom:30px;left:50%;transform:translateX(-50%);
        background:${colors[type] || colors.success};color:#fff;padding:12px 24px;
        border-radius:8px;font-weight:600;font-size:0.9rem;z-index:9999;
        box-shadow:0 4px 20px rgba(0,0,0,0.4);animation:fadeInUp 0.3s ease;
    `;
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => { toast.style.opacity = '0'; setTimeout(() => toast.remove(), 300); }, 3000);
}

// Quick Calorie Calculator (Global)
function quickCalcCalories(weight, height, age, gender, activity) {
    let bmr;
    if (gender === 'male') bmr = 10 * weight + 6.25 * height - 5 * age + 5;
    else                   bmr = 10 * weight + 6.25 * height - 5 * age - 161;
    const factors = { sedentary: 1.2, light: 1.375, moderate: 1.55, active: 1.725, very_active: 1.9 };
    return Math.round(bmr * (factors[activity] || 1.55));
}

// Water intake tracker quick add
function quickAddWater(ml) {
    fetch('api/water.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: ml })
    }).then(r => r.json()).then(d => {
        if (d.success) showToast(`+${ml}ml water logged! 💧`, 'info');
    }).catch(() => showToast('Failed to log water', 'error'));
}

// Charts default options
const chartTheme = {
    responsive: true,
    plugins: {
        legend: { labels: { color: '#aaa', font: { family: 'Poppins', size: 11 } } },
        tooltip: {
            backgroundColor: 'rgba(17,17,17,0.95)',
            borderColor: 'rgba(255,215,0,0.4)',
            borderWidth: 1,
            titleColor: '#FFD700',
            bodyColor: '#aaa',
            padding: 12,
        }
    },
    scales: {
        y: {
            grid: { color: 'rgba(255,215,0,0.05)', drawBorder: false },
            ticks: { color: '#aaa', font: { family: 'Poppins' } }
        },
        x: {
            grid: { display: false },
            ticks: { color: '#aaa', font: { family: 'Poppins' } }
        }
    }
};
