<?php
// API: Chat messages
session_start();
require_once '../includes/db.php';
header('Content-Type: application/json');

if (!isLoggedIn()) { echo json_encode(['error'=>'Unauthorized']); exit; }
$uid = $_SESSION['user_id'];

$data = json_decode(file_get_contents('php://input'), true);
$message  = $conn->real_escape_string($data['message'] ?? '');
$response = $conn->real_escape_string($data['response'] ?? '');

if ($message) {
    $conn->query("INSERT INTO chat_messages (user_id,message,is_bot) VALUES ($uid,'$message',0)");
    if ($response) {
        $conn->query("INSERT INTO chat_messages (user_id,message,is_bot) VALUES ($uid,'$response',1)");
    }
}
echo json_encode(['success'=>true]);
?>
