<?php
session_start();
require_once '../includes/db.php';
if (!isAdmin()) redirect('admin-login.php');

// Actions
if (isset($_GET['delete'])) {
    $conn->query("DELETE FROM foods WHERE id=".(int)$_GET['delete']);
    redirect('manage-food.php');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name     = sanitize($conn, $_POST['name']);
    $category = sanitize($conn, $_POST['category']);
    $calories = (float)$_POST['calories'];
    $protein  = (float)$_POST['protein'];
    $carbs    = (float)$_POST['carbs'];
    $fat      = (float)$_POST['fat'];
    $fiber    = (float)$_POST['fiber'];
    $serving  = sanitize($conn, $_POST['serving_size']);
    $benefits = sanitize($conn, $_POST['benefits']);
    $id       = (int)$_POST['edit_id'];

    if ($id > 0) {
        $result = $conn->query("UPDATE foods SET name='$name',category='$category',calories=$calories,protein=$protein,carbs=$carbs,fat=$fat,fiber=$fiber,serving_size='$serving',benefits='$benefits' WHERE id=$id");
        if (!$result) {
            die("Update failed: " . $conn->error);
        }
    } else {
        $result = $conn->query("INSERT INTO foods (name,category,calories,protein,carbs,fat,fiber,serving_size,benefits) VALUES ('$name','$category',$calories,$protein,$carbs,$fat,$fiber,'$serving','$benefits')");
        if (!$result) {
            die("Insert failed: " . $conn->error);
        }
    }
    redirect('manage-food.php');
}

$editFood = null;
if (isset($_GET['edit'])) {
    $editFood = $conn->query("SELECT * FROM foods WHERE id=".(int)$_GET['edit'])->fetch_assoc();
}

$search = sanitize($conn, $_GET['search'] ?? '');
$where  = $search ? "WHERE name LIKE '%$search%' OR category LIKE '%$search%'" : '';
$foods  = $conn->query("SELECT * FROM foods $where ORDER BY category,name");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Foods | Admin</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<nav class="navbar navbar-expand-lg">
  <div class="container-fluid">
    <a class="navbar-brand" href="admin-dashboard.php"><i class="fas fa-user-shield me-2" style="color:var(--gold)"></i>NutriGold ADMIN</a>
    <div class="ms-auto"><a href="../logout.php?admin=1" class="btn-outline-gold btn btn-sm"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></div>
  </div>
</nav>
<div class="d-flex">
  <div style="width:240px;min-height:100vh;background:var(--black-sidebar);border-right:1px solid rgba(255,215,0,0.2);padding-top:20px;position:fixed;left:0;top:64px">
    <div class="sidebar-menu">
      <?php foreach([['fas fa-tachometer-alt','admin-dashboard.php','Dashboard'],['fas fa-users','manage-users.php','Manage Users'],['fas fa-utensils','manage-food.php','Manage Foods'],['fas fa-chart-bar','reports.php','Reports']] as $m): ?>
      <a href="<?=$m[1]?>" class="<?=basename($_SERVER['PHP_SELF'])==$m[1]?'active':''?>"><i class="<?=$m[0]?>"></i><?=$m[2]?></a>
      <?php endforeach; ?>
    </div>
  </div>
  <div style="margin-left:240px;padding:30px;flex:1">
    <div class="page-header d-flex justify-content-between align-items-center">
      <div>
        <h2><i class="fas fa-utensils me-3"></i>Manage Food Database</h2>
        <p>Add, edit, and delete food items</p>
      </div>
      <button class="btn-gold btn" data-bs-toggle="modal" data-bs-target="#foodModal"><i class="fas fa-plus me-2"></i>Add New Food</button>
    </div>

    <!-- Search -->
    <div class="card-gold mb-4">
      <form method="GET" class="row g-3 align-items-end">
        <div class="col-md-8"><input type="text" name="search" class="form-control" placeholder="Search food name or category..." value="<?=htmlspecialchars($search)?>"></div>
        <div class="col-md-2"><button type="submit" class="btn-gold btn w-100"><i class="fas fa-search me-2"></i>Search</button></div>
        <div class="col-md-2"><a href="manage-food.php" class="btn-outline-gold btn w-100">Reset</a></div>
      </form>
    </div>

    <div class="card-gold">
      <div class="section-title"><i class="fas fa-database me-2"></i>Food Database (<?=$foods->num_rows?> items)</div>
      <div class="table-responsive">
        <table class="table-dark-gold w-100">
          <thead><tr><th>#</th><th>Name</th><th>Category</th><th>Calories</th><th>Protein</th><th>Carbs</th><th>Fat</th><th>Serving</th><th>Actions</th></tr></thead>
          <tbody>
          <?php $i=1; while($f=$foods->fetch_assoc()): ?>
          <tr>
            <td><?=$i++?></td>
            <td style="font-weight:600"><?=htmlspecialchars($f['name'])?></td>
            <td><span class="badge-info" style="font-size:0.72rem"><?=htmlspecialchars($f['category']??'General')?></span></td>
            <td><span class="gold-text font-weight-700"><?=$f['calories']?></span></td>
            <td style="color:#28a745"><?=$f['protein']?>g</td>
            <td style="color:#ffc107"><?=$f['carbs']?>g</td>
            <td style="color:#17a2b8"><?=$f['fat']?>g</td>
            <td class="text-muted-gold" style="font-size:0.8rem"><?=htmlspecialchars($f['serving_size'])?></td>
            <td>
              <div class="d-flex gap-1">
                <button onclick='loadEdit(<?=json_encode($f)?>)' class="btn btn-sm" style="background:rgba(255,215,0,0.1);border:1px solid rgba(255,215,0,0.3);color:var(--gold);border-radius:6px;padding:4px 8px;font-size:0.72rem"><i class="fas fa-edit"></i></button>
                <a href="manage-food.php?delete=<?=$f['id']?>" onclick="return confirm('Delete this food?')" class="btn btn-sm" style="background:rgba(220,53,69,0.1);border:1px solid rgba(220,53,69,0.3);color:#dc3545;border-radius:6px;padding:4px 8px;font-size:0.72rem"><i class="fas fa-trash"></i></a>
              </div>
            </td>
          </tr>
          <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- Food Add/Edit Modal -->
<div class="modal fade" id="foodModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-dark modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="fas fa-utensils me-2"></i><span id="modalTitle">Add New Food</span></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST">
        <input type="hidden" name="edit_id" id="editId" value="0">
        <div class="modal-body">
          <div class="row g-3">
            <div class="col-md-6"><label class="form-label">Food Name</label><input type="text" name="name" id="fName" class="form-control" required></div>
            <div class="col-md-6">
              <label class="form-label">Category</label>
              <select name="category" id="fCat" class="form-select">
                <?php foreach(['Protein','Grains','Fruits','Vegetables','Dairy','Legumes','Nuts','Beverages','Snacks','Other'] as $c): ?>
                <option value="<?=$c?>"><?=$c?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-3"><label class="form-label">Calories (kcal)</label><input type="number" name="calories" id="fCal" class="form-control" step="0.1" required></div>
            <div class="col-md-3"><label class="form-label">Protein (g)</label><input type="number" name="protein" id="fProt" class="form-control" step="0.1" value="0"></div>
            <div class="col-md-3"><label class="form-label">Carbs (g)</label><input type="number" name="carbs" id="fCarb" class="form-control" step="0.1" value="0"></div>
            <div class="col-md-3"><label class="form-label">Fat (g)</label><input type="number" name="fat" id="fFat" class="form-control" step="0.1" value="0"></div>
            <div class="col-md-4"><label class="form-label">Fiber (g)</label><input type="number" name="fiber" id="fFib" class="form-control" step="0.1" value="0"></div>
            <div class="col-md-8"><label class="form-label">Serving Size</label><input type="text" name="serving_size" id="fServ" class="form-control" placeholder="e.g. 100g, 1 cup" value="100g"></div>
            <div class="col-12"><label class="form-label">Health Benefits</label><textarea name="benefits" id="fBen" class="form-control" rows="2" placeholder="Health benefits of this food..."></textarea></div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn-dark-card btn" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn-gold btn"><i class="fas fa-save me-2"></i>Save Food</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function loadEdit(f) {
    document.getElementById('editId').value=f.id;
    document.getElementById('fName').value=f.name;
    document.getElementById('fCat').value=f.category;
    document.getElementById('fCal').value=f.calories;
    document.getElementById('fProt').value=f.protein;
    document.getElementById('fCarb').value=f.carbs;
    document.getElementById('fFat').value=f.fat;
    document.getElementById('fFib').value=f.fiber||0;
    document.getElementById('fServ').value=f.serving_size;
    document.getElementById('fBen').value=f.benefits||'';
    document.getElementById('modalTitle').textContent='Edit Food: '+f.name;
    new bootstrap.Modal(document.getElementById('foodModal')).show();
}
</script>
</body>
</html>
