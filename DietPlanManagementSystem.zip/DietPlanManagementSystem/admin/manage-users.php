<?php
session_start();
require_once '../includes/db.php';
if (!isAdmin()) redirect('admin-login.php');

// Actions
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM users WHERE id=$id");
    redirect('manage-users.php');
}
if (isset($_GET['toggle'])) {
    $id = (int)$_GET['toggle'];
    $conn->query("UPDATE users SET is_active = 1 - is_active WHERE id=$id");
    redirect('manage-users.php');
}
if (isset($_GET['toggle_premium'])) {
    $id = (int)$_GET['toggle_premium'];
    $conn->query("UPDATE users SET is_premium = 1 - is_premium WHERE id=$id");
    redirect('manage-users.php');
}

$search = sanitize($conn, $_GET['search'] ?? '');
$filter = sanitize($conn, $_GET['filter'] ?? 'all');

$where = "WHERE 1=1";
if ($search) $where .= " AND (name LIKE '%$search%' OR email LIKE '%$search%')";
if ($filter == 'premium') $where .= " AND is_premium=1";
if ($filter == 'active')  $where .= " AND is_active=1";
if ($filter == 'inactive')$where .= " AND is_active=0";

$users = $conn->query("SELECT * FROM users $where ORDER BY created_at DESC");
$adminName = $_SESSION['admin_name'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Users | Admin</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<nav class="navbar navbar-expand-lg">
  <div class="container-fluid">
    <a class="navbar-brand" href="admin-dashboard.php"><i class="fas fa-user-shield me-2" style="color:var(--gold)"></i>NutriGold ADMIN</a>
    <div class="ms-auto"><a href="../logout.php?admin=1" class="btn-outline-gold btn btn-sm"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></div>
  </div>
</nav>
<div class="d-flex">
  <div style="width:240px;min-height:100vh;background:var(--black-sidebar);border-right:1px solid rgba(255,215,0,0.2);padding-top:20px;position:fixed;left:0;top:64px">
    <div class="sidebar-menu">
      <?php foreach([['fas fa-tachometer-alt','admin-dashboard.php','Dashboard'],['fas fa-users','manage-users.php','Manage Users'],['fas fa-utensils','manage-food.php','Manage Foods'],['fas fa-chart-bar','reports.php','Reports']] as $m): ?>
      <a href="<?=$m[1]?>" class="<?=basename($_SERVER['PHP_SELF'])==$m[1]?'active':''?>"><i class="<?=$m[0]?>"></i><?=$m[2]?></a>
      <?php endforeach; ?>
    </div>
  </div>
  <div style="margin-left:240px;padding:30px;flex:1">
    <div class="page-header">
      <h2><i class="fas fa-users me-3"></i>Manage Users</h2>
    </div>

    <!-- Search & Filter -->
    <div class="card-gold mb-4">
      <form method="GET" class="row g-3 align-items-end">
        <div class="col-md-5">
          <label class="form-label">Search Users</label>
          <input type="text" name="search" class="form-control" placeholder="Name or email..." value="<?=htmlspecialchars($search)?>">
        </div>
        <div class="col-md-3">
          <label class="form-label">Filter</label>
          <select name="filter" class="form-select">
            <option value="all" <?=$filter=='all'?'selected':''?>>All Users</option>
            <option value="active" <?=$filter=='active'?'selected':''?>>Active</option>
            <option value="inactive" <?=$filter=='inactive'?'selected':''?>>Inactive</option>
            <option value="premium" <?=$filter=='premium'?'selected':''?>>Premium</option>
          </select>
        </div>
        <div class="col-md-2"><button type="submit" class="btn-gold btn w-100"><i class="fas fa-search me-2"></i>Search</button></div>
        <div class="col-md-2"><a href="manage-users.php" class="btn-outline-gold btn w-100">Reset</a></div>
      </form>
    </div>

    <div class="card-gold">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <div class="section-title mb-0"><i class="fas fa-list me-2"></i>Users (<?=$users->num_rows?>)</div>
      </div>
      <div class="table-responsive">
        <table class="table-dark-gold w-100">
          <thead><tr><th>#</th><th>Name</th><th>Email</th><th>Goal</th><th>BMI</th><th>Status</th><th>Premium</th><th>Joined</th><th>Actions</th></tr></thead>
          <tbody>
          <?php while($u=$users->fetch_assoc()):
            $bmiR=$conn->query("SELECT bmi FROM bmi_records WHERE user_id={$u['id']} ORDER BY recorded_date DESC LIMIT 1");
            $bmi = $bmiR->num_rows ? $bmiR->fetch_assoc()['bmi'] : '-';
          ?>
          <tr>
            <td><?=$u['id']?></td>
            <td>
              <div class="d-flex align-items-center gap-2">
                <div style="width:32px;height:32px;background:var(--gold-gradient);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#000;font-weight:700;font-size:0.8rem"><?=strtoupper(substr($u['name'],0,1))?></div>
                <div>
                  <div style="font-weight:600"><?=htmlspecialchars($u['name'])?></div>
                  <div class="text-muted-gold" style="font-size:0.72rem"><?=$u['gender'] ? ucfirst($u['gender']) : '' ?> <?=$u['age']?? ''?><?=$u['age']?' yrs':''?></div>
                </div>
              </div>
            </td>
            <td class="text-muted-gold" style="font-size:0.85rem"><?=htmlspecialchars($u['email'])?></td>
            <td><span class="badge-info" style="font-size:0.72rem"><?=ucwords(str_replace('_',' ',$u['fitness_goal']??'N/A'))?></span></td>
            <td>
              <?php if(is_numeric($bmi)): ?>
              <span style="color:<?=$bmi<18.5?'#17a2b8':($bmi<25?'#28a745':($bmi<30?'#ffc107':'#dc3545'))?>;font-weight:700"><?=$bmi?></span>
              <?php else: ?><span class="text-muted-gold">-</span><?php endif; ?>
            </td>
            <td>
              <?php if($u['is_active']): ?>
              <span class="badge-success">Active</span>
              <?php else: ?>
              <span class="badge-danger">Inactive</span>
              <?php endif; ?>
            </td>
            <td>
              <?php if($u['is_premium']): ?>
              <span class="badge-gold">Premium</span>
              <?php else: ?>
              <span class="text-muted-gold" style="font-size:0.8rem">Free</span>
              <?php endif; ?>
            </td>
            <td class="text-muted-gold" style="font-size:0.8rem"><?=date('M j Y',strtotime($u['created_at']))?></td>
            <td>
              <div class="d-flex gap-1">
                <a href="manage-users.php?toggle=<?=$u['id']?>" class="btn btn-sm" style="background:rgba(255,193,7,0.1);border:1px solid rgba(255,193,7,0.3);color:#ffc107;border-radius:6px;padding:4px 8px;font-size:0.72rem" title="Toggle Active"><i class="fas fa-power-off"></i></a>
                <a href="manage-users.php?toggle_premium=<?=$u['id']?>" class="btn btn-sm" style="background:rgba(255,215,0,0.1);border:1px solid rgba(255,215,0,0.3);color:var(--gold);border-radius:6px;padding:4px 8px;font-size:0.72rem" title="Toggle Premium"><i class="fas fa-crown"></i></a>
                <a href="manage-users.php?delete=<?=$u['id']?>" onclick="return confirm('Delete user permanently?')" class="btn btn-sm" style="background:rgba(220,53,69,0.1);border:1px solid rgba(220,53,69,0.3);color:#dc3545;border-radius:6px;padding:4px 8px;font-size:0.72rem"><i class="fas fa-trash"></i></a>
              </div>
            </td>
          </tr>
          <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
