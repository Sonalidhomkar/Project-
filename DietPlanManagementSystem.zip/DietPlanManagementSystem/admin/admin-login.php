<?php
session_start();
require_once '../includes/db.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = sanitize($conn, $_POST['email']);
    $pass  = $_POST['password'];
    $res   = $conn->query("SELECT * FROM admins WHERE email='$email'");
    if ($res->num_rows == 1) {
        $admin = $res->fetch_assoc();
        if (password_verify($pass, $admin['password'])) {
            $_SESSION['admin_id']   = $admin['id'];
            $_SESSION['admin_name'] = $admin['name'];
            redirect('../admin/admin-dashboard.php');
        } else $error = 'Invalid credentials!';
    } else $error = 'Invalid credentials!';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Login | NutriGold</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="auth-wrapper">
  <div class="auth-card animate-in">
    <div class="auth-logo"><i class="fas fa-user-shield me-2"></i>Admin Panel</div>
    <h2 class="auth-title">Administrator Login</h2>
    <p class="auth-subtitle">Secured admin access for NutriGold management</p>
    <?php if($error): ?><div class="alert-danger-dark mb-4"><i class="fas fa-exclamation-circle me-2"></i><?=$error?></div><?php endif; ?>
    <form method="POST">
      <div class="mb-3">
        <label class="form-label">Admin Email</label>
        <input type="email" name="email" class="form-control" placeholder="admin@dietplan.com" required>
      </div>
      <div class="mb-4">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" placeholder="Admin password" required>
      </div>
      <button type="submit" class="btn-gold btn w-100"><i class="fas fa-lock me-2"></i>Login to Admin Panel</button>
    </form>
    <p class="text-center text-muted-gold mt-4" style="font-size:0.82rem">
      <a href="../login.php" style="color:var(--gray-text);text-decoration:none"><i class="fas fa-arrow-left me-1"></i>Back to User Login</a>
    </p>
    <div style="background:rgba(255,215,0,0.06);border:var(--border-gold);border-radius:8px;padding:12px;margin-top:16px;text-align:center;font-size:0.8rem">
      <div class="gold-text mb-1">Demo: admin@dietplan.com / password</div>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
