<?php
session_start();
require_once '../includes/db.php';
if (!isAdmin()) redirect('admin-login.php');

$adminName = $_SESSION['admin_name'] ?? 'Admin';
$today = date('Y-m-d');

// Stats
$totalUsers    = $conn->query("SELECT COUNT(*) as c FROM users")->fetch_assoc()['c'];
$activeUsers   = $conn->query("SELECT COUNT(*) as c FROM users WHERE is_active=1")->fetch_assoc()['c'];
$totalFoods    = $conn->query("SELECT COUNT(*) as c FROM foods")->fetch_assoc()['c'];
$totalMeals    = $conn->query("SELECT COUNT(*) as c FROM meal_plans")->fetch_assoc()['c'];
$todayRegistrations = $conn->query("SELECT COUNT(*) as c FROM users WHERE DATE(created_at)='$today'")->fetch_assoc()['c'];
$totalFeedback = $conn->query("SELECT COUNT(*) as c FROM feedback WHERE status='pending'")->fetch_assoc()['c'];

// Recent users
$recentUsers = $conn->query("SELECT * FROM users ORDER BY created_at DESC LIMIT 8");

// Monthly signups for chart
$monthlySignups=[]; $monthLabels=[];
for($i=5;$i>=0;$i--){
    $m=date('Y-m',strtotime("-$i months"));
    $cnt=$conn->query("SELECT COUNT(*) as c FROM users WHERE DATE_FORMAT(created_at,'%Y-%m')='$m'")->fetch_assoc()['c'];
    $monthlySignups[]=$cnt;
    $monthLabels[]=date('M',strtotime("-$i months"));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard | NutriGold</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="../css/style.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
</head>
<body>

<!-- Admin Navbar -->
<nav class="navbar navbar-expand-lg">
  <div class="container-fluid">
    <a class="navbar-brand" href="admin-dashboard.php"><i class="fas fa-user-shield me-2" style="color:var(--gold)"></i>NutriGold <span style="font-size:0.7rem;color:var(--gold);vertical-align:top;margin-top:5px;display:inline-block">ADMIN</span></a>
    <div class="ms-auto d-flex align-items-center gap-3">
      <span class="text-muted-gold d-none d-md-block"><i class="fas fa-calendar me-2" style="color:var(--gold)"></i><?=date('l, M j Y')?></span>
      <div class="dropdown">
        <button class="btn-dark-card btn" data-bs-toggle="dropdown">
          <i class="fas fa-user-cog me-2"></i><?=$adminName?><i class="fas fa-chevron-down ms-2" style="font-size:0.7rem"></i>
        </button>
        <ul class="dropdown-menu dropdown-menu-end" style="background:var(--black-card);border:var(--border-gold)">
          <li><a class="dropdown-item" href="../logout.php?admin=1" style="color:#dc3545;font-size:0.88rem;padding:10px 16px"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
        </ul>
      </div>
    </div>
  </div>
</nav>

<div class="d-flex">
  <!-- Admin Sidebar -->
  <div style="width:240px;min-height:100vh;background:var(--black-sidebar);border-right:1px solid rgba(255,215,0,0.2);padding-top:20px;position:fixed;left:0;top:64px">
    <div class="sidebar-menu">
      <div class="menu-section">Navigation</div>
      <?php
      $amenu=[
        ['fas fa-tachometer-alt','admin-dashboard.php','Dashboard'],
        ['fas fa-users','manage-users.php','Manage Users'],
        ['fas fa-utensils','manage-food.php','Manage Foods'],
        ['fas fa-chart-bar','reports.php','Reports'],
        ['fas fa-comments','feedback.php','Feedback'],
      ];
      $cp=basename($_SERVER['PHP_SELF']);
      foreach($amenu as $m): ?>
      <a href="<?=$m[1]?>" class="<?=$cp==$m[1]?'active':''?>"><i class="<?=$m[0]?>"></i><?=$m[2]?></a>
      <?php endforeach; ?>
      <div class="menu-section">Links</div>
      <a href="../index.php"><i class="fas fa-home"></i>View Site</a>
      <a href="../logout.php?admin=1" style="color:#dc3545 !important"><i class="fas fa-sign-out-alt"></i>Logout</a>
    </div>
  </div>

  <!-- Admin Main Content -->
  <div style="margin-left:240px;padding:30px;flex:1;min-height:100vh">
    <div class="page-header">
      <h2><i class="fas fa-tachometer-alt me-3"></i>Admin Dashboard</h2>
      <p>System overview and management controls</p>
    </div>

    <!-- Stat Cards -->
    <div class="row g-4 mb-4">
      <?php foreach([['fas fa-users','Total Users',$totalUsers,'var(--gold)','manage-users.php'],['fas fa-user-check','Active Users',$activeUsers,'#28a745','manage-users.php'],['fas fa-utensils','Food Items',$totalFoods,'#17a2b8','manage-food.php'],['fas fa-calendar-alt','Meal Logs',$totalMeals,'#6f42c1','reports.php'],['fas fa-calendar-day','New Today',$todayRegistrations,'#e91e63','manage-users.php'],['fas fa-star','Pending Feedback',$totalFeedback,'#ff5722','feedback.php']] as $s): ?>
      <div class="col-xl-2 col-md-4 col-6">
        <a href="<?=$s[4]?>" class="text-decoration-none">
          <div class="card-stat" style="padding:18px">
            <i class="<?=$s[0]?>" style="color:<?=$s[3]?>;font-size:1.8rem;margin-bottom:10px;display:block"></i>
            <div style="font-size:1.6rem;font-weight:800;color:<?=$s[3]?>"><?=$s[2]?></div>
            <div class="stat-label"><?=$s[1]?></div>
          </div>
        </a>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- Charts Row -->
    <div class="row g-4 mb-4">
      <div class="col-lg-8">
        <div class="chart-container">
          <div class="section-title"><i class="fas fa-user-plus me-2"></i>Monthly User Registrations</div>
          <canvas id="signupChart" height="80"></canvas>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="chart-container">
          <div class="section-title"><i class="fas fa-chart-pie me-2"></i>User Status</div>
          <canvas id="userPie" height="180"></canvas>
        </div>
      </div>
    </div>

    <!-- Recent Users Table -->
    <div class="card-gold mb-4">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <div class="section-title mb-0"><i class="fas fa-users me-2"></i>Recent Users</div>
        <a href="manage-users.php" class="btn-gold btn btn-sm"><i class="fas fa-eye me-2"></i>View All</a>
      </div>
      <div class="table-responsive">
        <table class="table-dark-gold w-100">
          <thead><tr><th>#</th><th>Name</th><th>Email</th><th>Goal</th><th>Joined</th><th>Action</th></tr></thead>
          <tbody>
          <?php while($u=$recentUsers->fetch_assoc()): ?>
          <tr>
            <td><?=$u['id']?></td>
            <td>
              <div class="d-flex align-items-center gap-2">
                <div style="width:32px;height:32px;background:var(--gold-gradient);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#000;font-weight:700;font-size:0.8rem"><?=strtoupper(substr($u['name'],0,1))?></div>
                <span style="font-weight:600"><?=htmlspecialchars($u['name'])?></span>
              </div>
            </td>
            <td class="text-muted-gold"><?=htmlspecialchars($u['email'])?></td>
            <td><span class="badge-info"><?=ucwords(str_replace('_',' ',$u['fitness_goal']??'N/A'))?></span></td>
            <td class="text-muted-gold" style="font-size:0.82rem"><?=date('M j, Y',strtotime($u['created_at']))?></td>
            <td>
              <a href="manage-users.php?toggle=<?=$u['id']?>" class="btn btn-sm me-1" style="background:rgba(255,193,7,0.1);border:1px solid rgba(255,193,7,0.3);color:#ffc107;border-radius:6px;font-size:0.75rem" title="Toggle Status"><i class="fas fa-toggle-on"></i></a>
              <a href="manage-users.php?delete=<?=$u['id']?>" onclick="return confirm('Delete user?')" class="btn btn-sm" style="background:rgba(220,53,69,0.1);border:1px solid rgba(220,53,69,0.3);color:#dc3545;border-radius:6px;font-size:0.75rem"><i class="fas fa-trash"></i></a>
            </td>
          </tr>
          <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Quick Actions Grid -->
    <div class="row g-3">
      <?php foreach([['manage-users.php','fas fa-users','Manage Users','View, edit, ban or delete users','var(--gold)'],['manage-food.php','fas fa-utensils','Manage Food DB','Add, edit, delete food items','#28a745'],['reports.php','fas fa-chart-bar','View Reports','System-wide analytics','#17a2b8'],['../index.php','fas fa-globe','View Website','Open the public site','#ffc107']] as $a): ?>
      <div class="col-md-3 col-6">
        <a href="<?=$a[0]?>" class="text-decoration-none">
          <div class="card-gold h-100 text-center" style="padding:20px">
            <i class="<?=$a[1]?>" style="color:<?=$a[4]?>;font-size:2rem;margin-bottom:10px;display:block"></i>
            <div style="font-weight:700;margin-bottom:5px"><?=$a[2]?></div>
            <div class="text-muted-gold" style="font-size:0.78rem"><?=$a[3]?></div>
          </div>
        </a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
new Chart(document.getElementById('signupChart'),{type:'bar',data:{labels:<?=json_encode($monthLabels)?>,datasets:[{label:'New Users',data:<?=json_encode($monthlySignups)?>,backgroundColor:'rgba(255,215,0,0.35)',borderColor:'#FFD700',borderWidth:2,borderRadius:8}]},options:{responsive:true,plugins:{legend:{labels:{color:'#aaa'}}},scales:{y:{grid:{color:'rgba(255,215,0,0.05)'},ticks:{color:'#aaa',stepSize:1}},x:{grid:{display:false},ticks:{color:'#aaa'}}}}});
new Chart(document.getElementById('userPie'),{type:'doughnut',data:{labels:['Active','Inactive'],datasets:[{data:[<?=$activeUsers?>,<?=max(0, (int)$totalUsers - (int)$activeUsers)?>],backgroundColor:['rgba(40,167,69,0.8)','rgba(220,53,69,0.7)'],borderWidth:2}]},options:{cutout:'60%',plugins:{legend:{labels:{color:'#aaa'}}}}});
</script>
</body>
</html>
