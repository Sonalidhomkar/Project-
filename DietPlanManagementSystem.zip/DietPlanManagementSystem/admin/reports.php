<?php
session_start();
require_once '../includes/db.php';
if (!isAdmin()) redirect('admin-login.php');

// Stats for reports
$today = date('Y-m-d');
$totalUsers   = $conn->query("SELECT COUNT(*) as c FROM users")->fetch_assoc()['c'];
$totalMeals   = $conn->query("SELECT COUNT(*) as c FROM meal_plans")->fetch_assoc()['c'];
$totalWater   = $conn->query("SELECT COALESCE(SUM(amount_ml),0) as t FROM water_intake")->fetch_assoc()['t'];
$avgBMI       = $conn->query("SELECT AVG(bmi) as a FROM bmi_records")->fetch_assoc()['a'];
$premiumRevenue = $conn->query("SELECT COUNT(*) as c FROM users WHERE is_premium=1")->fetch_assoc()['c'] * 9.99;

// Monthly data
$months=[]; $userCounts=[]; $mealCounts=[];
for($i=5;$i>=0;$i--) {
    $m=date('Y-m',strtotime("-$i months"));
    $months[]=date('M Y',strtotime("-$i months"));
    $userCounts[]=$conn->query("SELECT COUNT(*) as c FROM users WHERE DATE_FORMAT(created_at,'%Y-%m')='$m'")->fetch_assoc()['c'];
    $mealCounts[]=$conn->query("SELECT COUNT(*) as c FROM meal_plans WHERE DATE_FORMAT(plan_date,'%Y-%m')='$m'")->fetch_assoc()['c'];
}

// Goal distribution
$goals=$conn->query("SELECT fitness_goal,COUNT(*) as cnt FROM users GROUP BY fitness_goal");
$goalLabels=[]; $goalData=[];
while($g=$goals->fetch_assoc()){$goalLabels[]=ucwords(str_replace('_',' ',$g['fitness_goal']));$goalData[]=$g['cnt'];}

$adminName=$_SESSION['admin_name'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Reports | NutriGold</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="../css/style.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
</head>
<body>
<nav class="navbar navbar-expand-lg">
  <div class="container-fluid">
    <a class="navbar-brand" href="admin-dashboard.php"><i class="fas fa-user-shield me-2" style="color:var(--gold)"></i>NutriGold ADMIN</a>
    <div class="ms-auto d-flex gap-2">
      <button onclick="window.print()" class="btn-dark-card btn btn-sm"><i class="fas fa-print me-2"></i>Print</button>
      <a href="../logout.php?admin=1" class="btn-outline-gold btn btn-sm"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
    </div>
  </div>
</nav>
<div class="d-flex">
  <div style="width:240px;min-height:100vh;background:var(--black-sidebar);border-right:1px solid rgba(255,215,0,0.2);padding-top:20px;position:fixed;left:0;top:64px">
    <div class="sidebar-menu">
      <?php foreach([['fas fa-tachometer-alt','admin-dashboard.php','Dashboard'],['fas fa-users','manage-users.php','Manage Users'],['fas fa-utensils','manage-food.php','Manage Foods'],['fas fa-chart-bar','reports.php','Reports']] as $m): ?>
      <a href="<?=$m[1]?>" class="<?=basename($_SERVER['PHP_SELF'])==$m[1]?'active':''?>"><i class="<?=$m[0]?>"></i><?=$m[2]?></a>
      <?php endforeach; ?>
    </div>
  </div>
  <div style="margin-left:240px;padding:30px;flex:1">
    <div class="page-header">
      <h2><i class="fas fa-chart-bar me-3"></i>System Reports</h2>
      <p>Platform-wide analytics and insights</p>
    </div>

    <!-- Summary Stats -->
    <div class="row g-4 mb-4">
      <?php foreach([['fas fa-users','Total Users',$totalUsers,'var(--gold)'],['fas fa-utensils','Meals Logged',$totalMeals,'#28a745'],['fas fa-tint','Water Logged (L)',round($totalWater/1000),'#17a2b8'],['fas fa-weight','Avg BMI',round($avgBMI,1),'#e91e63'],['fas fa-dollar-sign','Est. Revenue','$'.round($premiumRevenue,2),'var(--gold)']] as $s): ?>
      <div class="col-xl-2 col-md-4 col-6">
        <div class="card-stat" style="padding:18px">
          <i class="<?=$s[0]?>" style="color:<?=$s[3]?>;font-size:1.8rem;margin-bottom:8px;display:block"></i>
          <div style="font-size:1.4rem;font-weight:800;color:<?=$s[3]?>"><?=$s[2]?></div>
          <div class="stat-label" style="font-size:0.75rem"><?=$s[1]?></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- Charts -->
    <div class="row g-4 mb-4">
      <div class="col-lg-8">
        <div class="chart-container">
          <div class="section-title"><i class="fas fa-chart-line me-2"></i>Monthly Growth</div>
          <canvas id="growthChart" height="80"></canvas>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="chart-container">
          <div class="section-title"><i class="fas fa-chart-pie me-2"></i>User Goals Distribution</div>
          <canvas id="goalChart" height="180"></canvas>
        </div>
      </div>
    </div>

    <!-- Top Logged Foods -->
    <div class="row g-4">
      <div class="col-lg-6">
        <div class="card-gold">
          <div class="section-title"><i class="fas fa-fire me-2"></i>Most Popular Foods</div>
          <?php
          $topFoods=$conn->query("SELECT f.name,COUNT(*) as cnt FROM meal_plans mp JOIN foods f ON mp.food_id=f.id GROUP BY f.id ORDER BY cnt DESC LIMIT 8");
          while($tf=$topFoods->fetch_assoc()): ?>
          <div class="d-flex justify-content-between align-items-center mb-3">
            <div style="font-weight:600;font-size:0.88rem"><?=htmlspecialchars($tf['name'])?></div>
            <div class="d-flex align-items-center gap-2">
              <div style="width:80px;height:6px;background:var(--black-input);border-radius:3px;overflow:hidden">
                <div style="width:<?=min(100,round($tf['cnt']/max(1,$topFoods->num_rows)*100*3))?>%;height:100%;background:var(--gold-gradient)"></div>
              </div>
              <span class="gold-text" style="font-size:0.82rem;font-weight:700"><?=$tf['cnt']?>x</span>
            </div>
          </div>
          <?php endwhile; ?>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="card-gold">
          <div class="section-title"><i class="fas fa-users me-2"></i>User Activity This Week</div>
          <?php
          $weekActive=$conn->query("SELECT u.name,u.email,COUNT(mp.id) as meals FROM users u LEFT JOIN meal_plans mp ON u.id=mp.user_id AND mp.plan_date>=DATE_SUB('$today',INTERVAL 7 DAY) GROUP BY u.id ORDER BY meals DESC LIMIT 6");
          while($ua=$weekActive->fetch_assoc()): ?>
          <div class="d-flex align-items-center gap-3 mb-3">
            <div style="width:32px;height:32px;background:var(--gold-gradient);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#000;font-weight:700;font-size:0.8rem"><?=strtoupper(substr($ua['name'],0,1))?></div>
            <div style="flex:1">
              <div style="font-weight:600;font-size:0.85rem"><?=htmlspecialchars($ua['name'])?></div>
              <div class="text-muted-gold" style="font-size:0.72rem"><?=htmlspecialchars($ua['email'])?></div>
            </div>
            <div style="text-align:right">
              <div class="gold-text" style="font-weight:700"><?=$ua['meals']?></div>
              <div class="text-muted-gold" style="font-size:0.7rem">meals</div>
            </div>
          </div>
          <?php endwhile; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
new Chart(document.getElementById('growthChart'),{
    type:'line',
    data:{labels:<?=json_encode($months)?>,datasets:[{label:'New Users',data:<?=json_encode($userCounts)?>,borderColor:'#FFD700',backgroundColor:'rgba(255,215,0,0.1)',fill:true,tension:0.4,pointBackgroundColor:'#FFD700',pointRadius:5},{label:'Meals Logged',data:<?=json_encode($mealCounts)?>,borderColor:'#28a745',backgroundColor:'rgba(40,167,69,0.1)',fill:true,tension:0.4,pointBackgroundColor:'#28a745',pointRadius:5}]},
    options:{responsive:true,plugins:{legend:{labels:{color:'#aaa'}}},scales:{y:{grid:{color:'rgba(255,215,0,0.05)'},ticks:{color:'#aaa'}},x:{grid:{display:false},ticks:{color:'#aaa'}}}}
});
new Chart(document.getElementById('goalChart'),{
    type:'doughnut',
    data:{labels:<?=json_encode($goalLabels)?>,datasets:[{data:<?=json_encode($goalData)?>,backgroundColor:['rgba(255,215,0,0.8)','rgba(40,167,69,0.8)','rgba(23,162,184,0.8)'],borderWidth:2}]},
    options:{cutout:'60%',plugins:{legend:{labels:{color:'#aaa'}}}}
});
</script>
</body>
</html>
