<?php
require_once 'includes/header.php';

// ---- Handle profile update ----
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name   = sanitize($conn, $_POST['name']);
    $phone  = sanitize($conn, $_POST['phone']);
    $age    = (int)$_POST['age'];
    $gender = sanitize($conn, $_POST['gender']);
    $weight = (float)$_POST['weight'];
    $height = (float)$_POST['height'];
    $goal   = sanitize($conn, $_POST['fitness_goal']);
    $al     = sanitize($conn, $_POST['activity_level']);

    if (!empty($_POST['new_password'])) {
        $np = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
        $conn->query("UPDATE users SET name='$name',phone='$phone',age=$age,gender='$gender',weight=$weight,height=$height,fitness_goal='$goal',activity_level='$al',password='$np' WHERE id=$uid");
    } else {
        $conn->query("UPDATE users SET name='$name',phone='$phone',age=$age,gender='$gender',weight=$weight,height=$height,fitness_goal='$goal',activity_level='$al' WHERE id=$uid");
    }

    // Update goals
    $calGoal  = (int)$_POST['calorie_goal'];
    $watGoal  = (int)$_POST['water_goal'];
    $tWeight  = (float)$_POST['target_weight'];
    $gExists  = $conn->query("SELECT id FROM user_goals WHERE user_id=$uid")->num_rows;
    if ($gExists)
        $conn->query("UPDATE user_goals SET daily_calorie_goal=$calGoal,daily_water_goal=$watGoal,target_weight=$tWeight WHERE user_id=$uid");
    else
        $conn->query("INSERT INTO user_goals (user_id,daily_calorie_goal,daily_water_goal,target_weight) VALUES ($uid,$calGoal,$watGoal,$tWeight)");

    $_SESSION['user_name'] = $name;
    $user = getUserInfo($conn, $uid);
    $success = "Profile updated successfully!";
}

$user  = getUserInfo($conn, $uid);
$goals = $conn->query("SELECT * FROM user_goals WHERE user_id=$uid")->fetch_assoc() ?? ['daily_calorie_goal'=>2000,'daily_water_goal'=>2500,'target_weight'=>0];

// Stats
$totalMeals = $conn->query("SELECT COUNT(*) as c FROM meal_plans WHERE user_id=$uid")->fetch_assoc()['c'];
$totalWater = $conn->query("SELECT COALESCE(SUM(amount_ml),0) as t FROM water_intake WHERE user_id=$uid")->fetch_assoc()['t'];
$latestBMI = $conn->query("SELECT bmi,category FROM bmi_records WHERE user_id=$uid ORDER BY recorded_date DESC LIMIT 1")->fetch_assoc();

// Calculate BMI if weight/height available
$bmi = 0;
if ($user['weight'] && $user['height']) {
    $h = $user['height'] / 100;
    $bmi = round($user['weight'] / ($h * $h), 1);
}
?>

<div class="page-header">
  <h2><i class="fas fa-user me-3"></i>My Profile</h2>
  <p>Manage your personal information and health goals</p>
</div>

<?php if(isset($success)): ?><div class="alert-success-dark mb-4"><i class="fas fa-check-circle me-2"></i><?=$success?></div><?php endif; ?>

<div class="row g-4">
  <!-- Profile Card -->
  <div class="col-lg-4">
    <div class="card-gold text-center mb-4">
      <div style="width:100px;height:100px;background:var(--gold-gradient);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#000;font-size:2.5rem;font-weight:800;margin:0 auto 20px"><?=strtoupper(substr($user['name'],0,1))?></div>
      <h4 style="font-weight:700"><?=htmlspecialchars($user['name'])?></h4>
      <p class="text-muted-gold"><?=htmlspecialchars($user['email'])?></p>
     

      <!-- Mini Stats -->      <div class="row g-2 mt-3">
        <?php foreach([['Meals Logged',$totalMeals,'fas fa-utensils','var(--gold)'],['Water (L)',round($totalWater/1000,1),'fas fa-tint','#17a2b8']] as $s): ?>
        <div class="col-6">
          <div style="background:var(--black-input);border:var(--border-gold);border-radius:8px;padding:12px;text-align:center">
            <i class="<?=$s[2]?>" style="color:<?=$s[3]?>;margin-bottom:4px;font-size:1rem;display:block"></i>
            <div style="font-weight:700;color:<?=$s[3]?>"><?=$s[1]?></div>
            <div class="text-muted-gold" style="font-size:0.72rem"><?=$s[0]?></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>

      <!-- Current BMI -->
      <?php if($bmi > 0): ?>
      <div class="mt-4 p-3" style="background:rgba(255,215,0,0.06);border:var(--border-gold);border-radius:8px">
        <div style="font-size:0.8rem;color:var(--gray-text);margin-bottom:5px">Current BMI</div>
        <div style="font-size:2rem;font-weight:800;color:<?=$bmi<18.5?'#17a2b8':($bmi<25?'#28a745':($bmi<30?'#ffc107':'#dc3545'))?>"><?=$bmi?></div>
        <div style="color:<?=$bmi<18.5?'#17a2b8':($bmi<25?'#28a745':($bmi<30?'#ffc107':'#dc3545'))?>;font-size:0.85rem"><?=$latestBMI['category']??(($bmi<18.5?'Underweight':($bmi<25?'Normal':($bmi<30?'Overweight':'Obese'))))?></div>
      </div>
      <?php endif; ?>
    </div>

    <!-- Member Since -->
    <div style="background:var(--black-card);border:var(--border-gold);border-radius:var(--radius);padding:16px;text-align:center">
      <div class="text-muted-gold" style="font-size:0.8rem">Member Since</div>
      <div style="font-weight:700;color:var(--gold)"><?=date('F Y',strtotime($user['created_at']))?></div>
    </div>
  </div>

  <!-- Edit Form -->
  <div class="col-lg-8">
    <form method="POST">
      <!-- Personal Info -->
      <div class="card-gold mb-4">
        <div class="section-title"><i class="fas fa-user-edit me-2"></i>Personal Information</div>
        <div class="row g-3">
          <div class="col-md-6"><label class="form-label">Full Name</label><input type="text" name="name" class="form-control" value="<?=htmlspecialchars($user['name'])?>" required></div>
          <div class="col-md-6"><label class="form-label">Email <small class="text-muted-gold">(cannot change)</small></label><input type="email" class="form-control" value="<?=htmlspecialchars($user['email'])?>" disabled></div>
          <div class="col-md-6"><label class="form-label">Phone</label><input type="tel" name="phone" class="form-control" value="<?=htmlspecialchars($user['phone']??'')?>"></div>
          <div class="col-md-3"><label class="form-label">Age</label><input type="number" name="age" class="form-control" value="<?=$user['age']??''?>" min="10" max="100"></div>
          <div class="col-md-3">
            <label class="form-label">Gender</label>
            <select name="gender" class="form-select">
              <option value="male" <?=($user['gender']??'')==='male'?'selected':''?>>Male</option>
              <option value="female" <?=($user['gender']??'')==='female'?'selected':''?>>Female</option>
              <option value="other">Other</option>
            </select>
          </div>
        </div>
      </div>

      <!-- Health Metrics -->
      <div class="card-gold mb-4">
        <div class="section-title"><i class="fas fa-heartbeat me-2"></i>Health Metrics &amp; Goals</div>
        <div class="row g-3">
          <div class="col-md-3"><label class="form-label">Weight (kg)</label><input type="number" name="weight" class="form-control" value="<?=$user['weight']??''?>" step="0.1"></div>
          <div class="col-md-3"><label class="form-label">Height (cm)</label><input type="number" name="height" class="form-control" value="<?=$user['height']??''?>"></div>
          <div class="col-md-3"><label class="form-label">Target Weight (kg)</label><input type="number" name="target_weight" class="form-control" value="<?=$goals['target_weight']??''?>" step="0.1"></div>
          <div class="col-md-3">
            <label class="form-label">Fitness Goal</label>
            <select name="fitness_goal" class="form-select">
              <option value="weight_loss" <?=($user['fitness_goal']??'')==='weight_loss'?'selected':''?>>Lose Weight</option>
              <option value="maintain" <?=($user['fitness_goal']??'')==='maintain'?'selected':''?>>Maintain</option>
              <option value="weight_gain" <?=($user['fitness_goal']??'')==='weight_gain'?'selected':''?>>Gain Muscle</option>
            </select>
          </div>
          <div class="col-md-6">
            <label class="form-label">Activity Level</label>
            <select name="activity_level" class="form-select">
              <?php foreach(['sedentary'=>'Sedentary','light'=>'Lightly Active','moderate'=>'Moderately Active','active'=>'Very Active','very_active'=>'Extremely Active'] as $v=>$l): ?>
              <option value="<?=$v?>" <?=($user['activity_level']??'')===$v?'selected':''?>><?=$l?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-3"><label class="form-label">Daily Calorie Goal</label><input type="number" name="calorie_goal" class="form-control" value="<?=$goals['daily_calorie_goal']??2000?>"></div>
          <div class="col-md-3"><label class="form-label">Daily Water Goal (ml)</label><input type="number" name="water_goal" class="form-control" value="<?=$goals['daily_water_goal']??2500?>"></div>
        </div>
      </div>

      <!-- Change Password -->
      <div class="card-gold mb-4">
        <div class="section-title"><i class="fas fa-lock me-2"></i>Change Password <small class="text-muted-gold" style="font-size:0.75rem">(optional)</small></div>
        <div class="row g-3">
          <div class="col-md-6"><label class="form-label">New Password</label><input type="password" name="new_password" class="form-control" placeholder="Leave empty to keep current" minlength="8"></div>
          <div class="col-md-6"><label class="form-label">Confirm New Password</label><input type="password" id="confirmPwd" class="form-control" placeholder="Confirm new password"></div>
        </div>
      </div>

      <button type="submit" class="btn-gold btn btn-lg w-100"><i class="fas fa-save me-2"></i>Save All Changes</button>
    </form>
  </div>
</div>

<?php require_once 'includes/footer.php'; ?>
