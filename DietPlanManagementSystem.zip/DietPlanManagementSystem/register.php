<?php
session_start();
require_once 'includes/db.php';

$error = ''; $success = '';

// Prevent browser POST resubmission/cache issues on refresh (Edge ERR_CACHE_MISS).
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

if (isset($_SESSION['register_error'])) {
    $error = $_SESSION['register_error'];
    unset($_SESSION['register_error']);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name     = sanitize($conn, $_POST['name']);
    $email    = sanitize($conn, $_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $phone    = sanitize($conn, $_POST['phone']);
    $age      = (int)$_POST['age'];
    $gender   = sanitize($conn, $_POST['gender']);
    $weight   = (float)$_POST['weight'];
    $height   = (float)$_POST['height'];
    $goal     = sanitize($conn, $_POST['fitness_goal']);
    $activity = sanitize($conn, $_POST['activity_level'] ?? 'moderate');

    // Check email exists
    $chk = $conn->query("SELECT id FROM users WHERE email='$email'");
    if ($chk->num_rows > 0) {
        $_SESSION['register_error'] = "Email already registered!";
        redirect('register.php');
    } else {
        $sql = "INSERT INTO users (name,email,password,phone,age,gender,weight,height,fitness_goal,activity_level)
                VALUES ('$name','$email','$password','$phone',$age,'$gender',$weight,$height,'$goal','$activity')";
        if ($conn->query($sql)) {
            $uid = $conn->insert_id;
            // Create default goals
            $conn->query("INSERT INTO user_goals (user_id) VALUES ($uid)");
            $_SESSION['user_id']   = $uid;
            $_SESSION['user_name'] = $name;
            $_SESSION['user_email']= $email;
            redirect('dashboard.php');
        } else {
            $_SESSION['register_error'] = "Registration failed: " . $conn->error;
            redirect('register.php');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Register | NutriGold</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="auth-wrapper" style="padding:40px 30px">
  <div class="auth-card animate-in" style="max-width:640px">
    <div class="auth-logo"><i class="fas fa-leaf me-2"></i>NutriGold</div>
    <h2 class="auth-title">Create Account</h2>
    <p class="auth-subtitle">Start your personalized diet journey today — it's free!</p>

    <?php if($error): ?><div class="alert-danger-dark mb-4"><i class="fas fa-exclamation-circle me-2"></i><?= $error ?></div><?php endif; ?>
    <div id="formError" class="alert-danger-dark mb-4" style="display:none"></div>

    <!-- Progress Steps -->
    <div class="d-flex justify-content-center gap-2 mb-4">
      <?php for($s=1;$s<=3;$s++): ?>
      <div class="d-flex align-items-center">
        <div class="step-dot" id="step-dot-<?=$s?>" style="width:32px;height:32px;border-radius:50%;border:2px solid <?=$s==1?'var(--gold)':'rgba(255,215,0,0.3)'?>;background:<?=$s==1?'rgba(255,215,0,0.15)':'transparent'?>;display:flex;align-items:center;justify-content:center;font-size:0.8rem;font-weight:700;color:<?=$s==1?'var(--gold)':'var(--gray-text)'?>;transition:all 0.3s"><?=$s?></div>
        <?php if($s<3): ?><div style="width:40px;height:2px;background:rgba(255,215,0,0.2)"></div><?php endif; ?>
      </div>
      <?php endfor; ?>
    </div>

    <form method="POST" id="regForm">
      <!-- Step 1 -->
      <div id="step1">
        <div class="section-title"><i class="fas fa-user me-2"></i>Personal Info</div>
        <div class="row g-3">
          <div class="col-12">
            <label class="form-label">Full Name</label>
            <input type="text" name="name" class="form-control" placeholder="Your full name" required>
          </div>
          <div class="col-md-6">
            <label class="form-label">Email Address</label>
            <input type="email" name="email" class="form-control" placeholder="email@example.com" required>
          </div>
          <div class="col-md-6">
            <label class="form-label">Phone Number</label>
            <input type="tel" name="phone" class="form-control" placeholder="+1 (555) 000-0000">
          </div>
          <div class="col-md-6">
            <label class="form-label">Password</label>
            <input type="password" name="password" id="pwd" class="form-control" placeholder="Min 8 characters" required minlength="8">
          </div>
          <div class="col-md-6">
            <label class="form-label">Confirm Password</label>
            <input type="password" id="cpwd" class="form-control" placeholder="Confirm password" required>
          </div>
        </div>
        <button type="button" class="btn-gold btn w-100 mt-4" onclick="goStep(2)">Next Step <i class="fas fa-arrow-right ms-2"></i></button>
      </div>

      <!-- Step 2 -->
      <div id="step2" style="display:none">
        <div class="section-title"><i class="fas fa-heartbeat me-2"></i>Health Profile</div>
        <div class="row g-3">
          <div class="col-md-4">
            <label class="form-label">Age</label>
            <input type="number" name="age" class="form-control" placeholder="Years" min="10" max="100" required>
          </div>
          <div class="col-md-4">
            <label class="form-label">Gender</label>
            <select name="gender" class="form-select" required>
              <option value="">Select</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div class="col-md-4">
            <label class="form-label">Activity Level</label>
            <select name="activity_level" class="form-select">
              <option value="sedentary">Sedentary</option>
              <option value="light">Lightly Active</option>
              <option value="moderate" selected>Moderately Active</option>
              <option value="active">Very Active</option>
            </select>
          </div>
          <div class="col-md-6">
            <label class="form-label">Weight (kg)</label>
            <input type="number" name="weight" class="form-control" placeholder="e.g. 70" step="0.1" min="20" max="300" required>
          </div>
          <div class="col-md-6">
            <label class="form-label">Height (cm)</label>
            <input type="number" name="height" class="form-control" placeholder="e.g. 175" min="100" max="250" required>
          </div>
        </div>
        <div class="d-flex gap-3 mt-4">
          <button type="button" class="btn-dark-card btn flex-fill" onclick="goStep(1)"><i class="fas fa-arrow-left me-2"></i>Back</button>
          <button type="button" class="btn-gold btn flex-fill" onclick="goStep(3)">Next Step <i class="fas fa-arrow-right ms-2"></i></button>
        </div>
      </div>

      <!-- Step 3 -->
      <div id="step3" style="display:none">
        <div class="section-title"><i class="fas fa-bullseye me-2"></i>Your Goal</div>
        <div class="row g-3 mb-4">
          <?php
          $goals = [
            ['weight_loss','🏃‍♂️','Lose Weight','Reduce body fat with smart calorie deficit plans'],
            ['maintain','⚖️','Maintain Weight','Keep your current weight with balanced nutrition'],
            ['weight_gain','💪','Gain Muscle','Build muscle mass with protein-rich meal plans'],
          ];
          foreach($goals as $g): ?>
          <div class="col-12">
            <div class="plan-card p-3 d-flex align-items-center gap-3" onclick="selectGoal('<?=$g[0]?>')" id="goal-<?=$g[0]?>" style="cursor:pointer">
              <div style="font-size:2rem"><?=$g[1]?></div>
              <div>
                <div style="font-weight:700"><?=$g[2]?></div>
                <div class="text-muted-gold" style="font-size:0.82rem"><?=$g[3]?></div>
              </div>
              <div class="ms-auto"><i class="fas fa-circle" id="icon-<?=$g[0]?>" style="color:rgba(255,215,0,0.2)"></i></div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
        <input type="hidden" name="fitness_goal" id="goalInput" value="maintain">
        <div class="form-check mb-3">
          <input class="form-check-input" type="checkbox" id="terms" required style="border-color:var(--gold)">
          <label class="form-check-label text-muted-gold" style="font-size:0.85rem" for="terms">
            I agree to the <a href="#" style="color:var(--gold)">Terms of Service</a> and <a href="#" style="color:var(--gold)">Privacy Policy</a>
          </label>
        </div>
        <div class="d-flex gap-3">
          <button type="button" class="btn-dark-card btn flex-fill" onclick="goStep(2)"><i class="fas fa-arrow-left me-2"></i>Back</button>
          <button type="button" id="createAccountBtn" class="btn-gold btn flex-fill" onclick="submitRegistration()"><i class="fas fa-user-plus me-2"></i>Create Account</button>
        </div>
      </div>
    </form>
    <p class="text-center text-muted-gold mt-4" style="font-size:0.88rem">
      Already have an account? <a href="login.php" style="color:var(--gold);text-decoration:none;font-weight:600">Login Here</a>
    </p>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function updateStepValidation(activeStep) {
    [1,2,3].forEach(step => {
        const container = document.getElementById('step' + step);
        const fields = container.querySelectorAll('input, select, textarea');
        fields.forEach(field => {
            if (field.dataset.wasRequired === undefined) {
                field.dataset.wasRequired = field.required ? '1' : '0';
            }
            field.required = (step === activeStep && field.dataset.wasRequired === '1');
        });
    });
}

function showFormError(message) {
    const box = document.getElementById('formError');
    box.innerHTML = '<i class="fas fa-exclamation-circle me-2"></i>' + message;
    box.style.display = 'block';
}

function clearFormError() {
    const box = document.getElementById('formError');
    box.style.display = 'none';
    box.innerHTML = '';
}

function goStep(n) {
    clearFormError();
    if(n==2) {
        const p=document.getElementById('pwd').value, c=document.getElementById('cpwd').value;
        if(p!==c){showFormError('Passwords do not match.');return;}
        if(p.length < 8){showFormError('Password must be at least 8 characters.');return;}
    }
    [1,2,3].forEach(s=>{
        document.getElementById('step'+s).style.display = s==n?'block':'none';
        const dot=document.getElementById('step-dot-'+s);
        if(s<n){dot.style.background='rgba(255,215,0,0.3)';dot.style.borderColor='var(--gold)';dot.style.color='var(--gold)';dot.innerHTML='<i class="fas fa-check" style="font-size:0.7rem"></i>';}
        else if(s==n){dot.style.background='rgba(255,215,0,0.15)';dot.style.borderColor='var(--gold)';dot.style.color='var(--gold)';dot.innerHTML=s;}
        else{dot.style.background='transparent';dot.style.borderColor='rgba(255,215,0,0.3)';dot.style.color='var(--gray-text)';dot.innerHTML=s;}
    });
    updateStepValidation(n);
}

function selectGoal(g) {
    ['weight_loss','maintain','weight_gain'].forEach(x=>{
        document.getElementById('goal-'+x).style.borderColor='rgba(255,215,0,0.3)';
        document.getElementById('goal-'+x).style.background='var(--black-card)';
        document.getElementById('icon-'+x).style.color='rgba(255,215,0,0.2)';
    });
    document.getElementById('goal-'+g).style.borderColor='var(--gold)';
    document.getElementById('goal-'+g).style.background='rgba(255,215,0,0.05)';
    document.getElementById('icon-'+g).style.color='var(--gold)';
    document.getElementById('goalInput').value=g;
}

function submitRegistration() {
    const form = document.getElementById('regForm');
    const terms = document.getElementById('terms').checked;
    const name = form.querySelector('input[name="name"]').value.trim();
    const email = form.querySelector('input[name="email"]').value.trim();
    const password = document.getElementById('pwd').value;
    const confirmPassword = document.getElementById('cpwd').value;
    const age = form.querySelector('input[name="age"]').value.trim();
    const gender = form.querySelector('select[name="gender"]').value.trim();
    const weight = form.querySelector('input[name="weight"]').value.trim();
    const height = form.querySelector('input[name="height"]').value.trim();

    clearFormError();
    if (!name || !email || !password || !confirmPassword || !age || !gender || !weight || !height) {
        showFormError('Please fill all required fields in all steps.');
        return;
    }
    if (password.length < 8) {
        showFormError('Password must be at least 8 characters.');
        return;
    }
    if (password !== confirmPassword) {
        showFormError('Passwords do not match.');
        return;
    }
    if (!terms) {
        showFormError('Please agree to Terms of Service and Privacy Policy.');
        return;
    }
    // Use direct submit to avoid browser validation blocking hidden step inputs.
    form.submit();
}

document.getElementById('regForm').addEventListener('submit', function(e) {
    const terms = document.getElementById('terms').checked;
    if (!terms) {
        e.preventDefault();
        showFormError('Please agree to Terms of Service and Privacy Policy.');
        return false;
    }
});

selectGoal('maintain');
updateStepValidation(1);
</script>
</body>
</html>
