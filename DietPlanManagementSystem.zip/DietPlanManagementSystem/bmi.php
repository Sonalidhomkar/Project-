<?php
require_once 'includes/header.php';

$bmiResult = null;
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $weight   = (float)$_POST['weight'];
    $heightCm = (float)$_POST['height'];
    $heightM  = $heightCm / 100;
    $age      = (int)$_POST['age'];
    $gender   = sanitize($conn, $_POST['gender']);
    $activity = sanitize($conn, $_POST['activity_level']);

    if ($weight > 0 && $heightM > 0) {
        $bmi = round($weight / ($heightM * $heightM), 1);

        if ($bmi < 18.5)      { $category='Underweight'; $color='#17a2b8'; $advice='Gain weight with calorie-dense nutritious foods.'; }
        elseif ($bmi < 25)    { $category='Normal Weight'; $color='#28a745'; $advice='Great! Maintain your healthy lifestyle.'; }
        elseif ($bmi < 30)    { $category='Overweight'; $color='#ffc107'; $advice='Reduce calories and increase physical activity.'; }
        else                  { $category='Obese'; $color='#dc3545'; $advice='Consult a doctor and start structured diet & exercise.'; }

        $idealMin = round(18.5 * ($heightM * $heightM), 1);
        $idealMax = round(24.9 * ($heightM * $heightM), 1);

        if ($gender == 'male') $bmr = 10*$weight + 6.25*$heightCm - 5*$age + 5;
        else                   $bmr = 10*$weight + 6.25*$heightCm - 5*$age - 161;

        $af = ['sedentary'=>1.2,'light'=>1.375,'moderate'=>1.55,'active'=>1.725,'very_active'=>1.9];
        $tdee = round($bmr * ($af[$activity] ?? 1.55));

        $bmiResult = ['bmi'=>$bmi,'category'=>$category,'color'=>$color,'advice'=>$advice,
                      'idealMin'=>$idealMin,'idealMax'=>$idealMax,'bmr'=>round($bmr),
                      'tdee'=>$tdee,'loseWeight'=>$tdee-500,'gainWeight'=>$tdee+300,'weight'=>$weight];

        $d = date('Y-m-d');
        $conn->query("INSERT INTO bmi_records (user_id,weight,height,bmi,category,recorded_date) VALUES ($uid,$weight,$heightCm,$bmi,'$category','$d')");
        $conn->query("UPDATE users SET weight=$weight, height=$heightCm, age=$age, gender='$gender' WHERE id=$uid");
    }
}

$history = $conn->query("SELECT * FROM bmi_records WHERE user_id=$uid ORDER BY recorded_date DESC LIMIT 10");
$histDates=[]; $histBMI=[]; $histArr=[];
while ($r = $history->fetch_assoc()) $histArr[] = $r;
foreach (array_reverse($histArr) as $r) { $histDates[]=date('M j',strtotime($r['recorded_date'])); $histBMI[]=$r['bmi']; }
?>

<div class="page-header">
  <h2><i class="fas fa-calculator me-3"></i>BMI Calculator &amp; Health Analysis</h2>
  <p>Calculate your Body Mass Index and get personalized health recommendations</p>
</div>

<div class="row g-4">
  <div class="col-lg-5">
    <div class="card-gold">
      <div class="section-title"><i class="fas fa-user-circle me-2"></i>Enter Your Measurements</div>
      <form method="POST">
        <div class="row g-3">
          <div class="col-6">
            <label class="form-label">Weight (kg)</label>
            <input type="number" name="weight" class="form-control" placeholder="e.g. 70" step="0.1" min="20" max="300" required value="<?= $user['weight'] ?? '' ?>">
          </div>
          <div class="col-6">
            <label class="form-label">Height (cm)</label>
            <input type="number" name="height" class="form-control" placeholder="e.g. 175" min="100" max="250" required value="<?= $user['height'] ?? '' ?>">
          </div>
          <div class="col-6">
            <label class="form-label">Age</label>
            <input type="number" name="age" class="form-control" placeholder="Years" min="10" max="100" required value="<?= $user['age'] ?? '' ?>">
          </div>
          <div class="col-6">
            <label class="form-label">Gender</label>
            <select name="gender" class="form-select">
              <option value="male" <?= ($user['gender']??'')==='male'?'selected':'' ?>>Male</option>
              <option value="female" <?= ($user['gender']??'')==='female'?'selected':'' ?>>Female</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div class="col-12">
            <label class="form-label">Activity Level</label>
            <select name="activity_level" class="form-select">
              <option value="sedentary">Sedentary (desk job, no exercise)</option>
              <option value="light">Lightly Active (1-3 days/week)</option>
              <option value="moderate" selected>Moderately Active (3-5 days/week)</option>
              <option value="active">Very Active (6-7 days/week)</option>
              <option value="very_active">Extremely Active (athlete)</option>
            </select>
          </div>
          <div class="col-12">
            <button type="submit" class="btn-gold btn w-100 mt-2"><i class="fas fa-calculator me-2"></i>Calculate BMI &amp; Calories</button>
          </div>
        </div>
      </form>
      <div class="mt-4 p-3" style="background:var(--black-input);border-radius:var(--radius-sm)">
        <div class="mb-2" style="font-size:0.85rem;font-weight:600;color:var(--gold)">BMI Scale Reference</div>
        <?php foreach([['< 18.5','Underweight','#17a2b8'],['18.5 - 24.9','Normal','#28a745'],['25.0 - 29.9','Overweight','#ffc107'],['30.0+','Obese','#dc3545']] as $s): ?>
        <div class="d-flex justify-content-between mb-1" style="font-size:0.82rem">
          <span style="color:<?=$s[2]?>"><?=$s[0]?></span>
          <span style="background:rgba(0,0,0,0.3);border:1px solid <?=$s[2]?>33;color:<?=$s[2]?>;padding:2px 10px;border-radius:10px;font-size:0.75rem"><?=$s[1]?></span>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <div class="col-lg-7">
    <?php if($bmiResult): ?>
    <div class="bmi-gauge mb-4 animate-in">
      <div class="row align-items-center">
        <div class="col-md-4 text-center">
          <div class="bmi-value"><?= $bmiResult['bmi'] ?></div>
          <div class="bmi-category" style="color:<?= $bmiResult['color'] ?>"><?= $bmiResult['category'] ?></div>
          <p class="text-muted-gold mt-2" style="font-size:0.82rem"><?= $bmiResult['advice'] ?></p>
        </div>
        <div class="col-md-8">
          <div class="bmi-bar">
            <?php $pct = min(95,max(2,($bmiResult['bmi']-10)/30*100)); ?>
            <div class="bmi-indicator" style="left:<?=$pct?>%"></div>
          </div>
          <div class="d-flex justify-content-between" style="font-size:0.7rem;color:var(--gray-text);margin-top:4px">
            <span>10</span><span>18.5</span><span>25</span><span>30</span><span>40</span>
          </div>
          <div class="row g-2 mt-3">
            <?php foreach([['BMR (Base)','fas fa-heartbeat','#e91e63',$bmiResult['bmr'].' kcal','Resting calories'],['Maintain Weight','fas fa-balance-scale','var(--gold)',$bmiResult['tdee'].' kcal','Daily TDEE'],['Lose Weight','fas fa-arrow-down','#28a745',$bmiResult['loseWeight'].' kcal','-500 cal deficit'],['Gain Weight','fas fa-arrow-up','#17a2b8',$bmiResult['gainWeight'].' kcal','+300 cal surplus']] as $c): ?>
            <div class="col-6">
              <div style="background:var(--black-input);border:1px solid rgba(255,215,0,0.15);border-radius:8px;padding:12px;text-align:center">
                <i class="<?=$c[1]?>" style="color:<?=$c[2]?>;font-size:1.1rem"></i>
                <div style="font-weight:700;font-size:0.9rem;color:<?=$c[2]?>;margin-top:4px"><?=$c[3]?></div>
                <div style="font-size:0.7rem;color:var(--gray-text)"><?=$c[0]?></div>
                <div style="font-size:0.68rem;color:var(--gray-light)"><?=$c[4]?></div>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    </div>
    <div class="card-gold mb-4">
      <div class="section-title"><i class="fas fa-bullseye me-2"></i>Ideal Weight Range</div>
      <div class="d-flex align-items-center gap-4">
        <div>
          <div style="font-size:1.8rem;font-weight:800;color:var(--gold)"><?=$bmiResult['idealMin']?> - <?=$bmiResult['idealMax']?> kg</div>
          <div class="text-muted-gold" style="font-size:0.85rem">Healthy BMI (18.5–24.9)</div>
        </div>
        <div style="flex:1">
          <?php $wPct=min(100,max(5,($bmiResult['weight']-$bmiResult['idealMin'])/max(1,$bmiResult['idealMax']-$bmiResult['idealMin'])*100)); ?>
          <div class="progress-gold" style="height:12px"><div class="progress-bar" style="width:<?=$wPct?>%"></div></div>
          <div class="d-flex justify-content-between mt-1" style="font-size:0.72rem;color:var(--gray-text)">
            <span><?=$bmiResult['idealMin']?>kg</span><span><?=$bmiResult['idealMax']?>kg</span>
          </div>
        </div>
      </div>
    </div>
    <?php else: ?>
    <div class="card-gold text-center py-5">
      <div style="font-size:5rem;margin-bottom:20px">📊</div>
      <h4 class="gold-text">Enter Your Details</h4>
      <p class="text-muted-gold">Fill the form to calculate your BMI and get personalized recommendations</p>
    </div>
    <?php endif; ?>

    <?php if(count($histBMI)>1): ?>
    <div class="chart-container">
      <div class="section-title"><i class="fas fa-history me-2"></i>BMI History</div>
      <canvas id="bmiHistChart" height="80"></canvas>
    </div>
    <?php endif; ?>
  </div>
</div>

<?php if(count($histBMI)>1): ?>
<script>
new Chart(document.getElementById('bmiHistChart'),{
    type:'line',
    data:{
        labels:<?=json_encode($histDates)?>,
        datasets:[{label:'BMI',data:<?=json_encode($histBMI)?>,borderColor:'#FFD700',backgroundColor:'rgba(255,215,0,0.1)',fill:true,tension:0.4,pointBackgroundColor:'#FFD700',pointRadius:5},{label:'Normal Upper (24.9)',data:Array(<?=count($histBMI)?>).fill(24.9),borderColor:'rgba(40,167,69,0.5)',borderDash:[5,5],pointRadius:0,fill:false},{label:'Underweight (18.5)',data:Array(<?=count($histBMI)?>).fill(18.5),borderColor:'rgba(23,162,184,0.5)',borderDash:[5,5],pointRadius:0,fill:false}]
    },
    options:{responsive:true,plugins:{legend:{labels:{color:'#aaa'}}},scales:{y:{grid:{color:'rgba(255,215,0,0.05)'},ticks:{color:'#aaa'},min:10,max:40},x:{grid:{display:false},ticks:{color:'#aaa'}}}}
});
</script>
<?php endif; ?>
<?php require_once 'includes/footer.php'; ?>
