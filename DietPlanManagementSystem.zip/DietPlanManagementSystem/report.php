<?php
require_once 'includes/header.php';
?>
<div class="page-header">
  <h2><i class="fas fa-chart-bar me-3"></i>Health Reports &amp; Analytics</h2>
  <p>View your progress, export reports, and track health trends</p>
</div>

<?php
// ---- Report period ----
$period = $_GET['period'] ?? 'week';
$periodDays = ['week'=>7,'month'=>30,'year'=>365][$period] ?? 7;
$startDate = date('Y-m-d', strtotime("-$periodDays days"));

// ---- Data Collection ----
$calData=[]; $waterData=[]; $labels=[];
for($i=$periodDays-1;$i>=0;$i--) {
    $d=date('Y-m-d',strtotime("-$i days"));
    $lbl = $periodDays<=7 ? date('D',strtotime($d)) : date('M j',strtotime($d));
    $labels[]=$lbl;
    $cal=$conn->query("SELECT COALESCE(SUM(calories),0) as t FROM meal_plans WHERE user_id=$uid AND plan_date='$d'")->fetch_assoc()['t'];
    $wat=$conn->query("SELECT COALESCE(SUM(amount_ml),0) as t FROM water_intake WHERE user_id=$uid AND intake_date='$d'")->fetch_assoc()['t'];
    $calData[]=round($cal); $waterData[]=round($wat);
}

// ---- Summary Stats ----
$avgCal  = count($calData) ? round(array_sum($calData)/count($calData)) : 0;
$avgWater= count($waterData) ? round(array_sum($waterData)/count($waterData)) : 0;
$bmiHistory=$conn->query("SELECT bmi,recorded_date FROM bmi_records WHERE user_id=$uid AND recorded_date>='$startDate' ORDER BY recorded_date");
$bmiDates=[]; $bmiVals=[];
while($b=$bmiHistory->fetch_assoc()){$bmiDates[]=date('M j',strtotime($b['recorded_date']));$bmiVals[]=$b['bmi'];}

$calGoal = $conn->query("SELECT daily_calorie_goal FROM user_goals WHERE user_id=$uid")->fetch_assoc()['daily_calorie_goal'] ?? 2000;
$daysOnTarget = 0;
foreach($calData as $c) if($c>0 && abs($c-$calGoal)<200) $daysOnTarget++;
?>

<!-- Period Selector -->
<div class="d-flex gap-2 mb-4">
  <?php foreach(['week'=>'7 Days','month'=>'30 Days','year'=>'Year'] as $p=>$l): ?>
  <a href="report.php?period=<?=$p?>" class="<?=$period==$p?'btn-gold':'btn-outline-gold'?> btn btn-sm"><?=$l?></a>
  <?php endforeach; ?>
  <div class="ms-auto d-flex gap-2">
    <button onclick="window.print()" class="btn-dark-card btn btn-sm"><i class="fas fa-print me-2"></i>Print</button>
    <button onclick="exportReport()" class="btn-gold btn btn-sm"><i class="fas fa-download me-2"></i>Export PDF</button>
  </div>
</div>

<!-- Summary Stats -->
<div class="row g-4 mb-4">
  <?php foreach([['fas fa-fire','Avg Daily Calories',$avgCal.' kcal','var(--gold)'],['fas fa-tint','Avg Water Intake',$avgWater.'ml','#17a2b8'],['fas fa-check-circle','Days On Target',$daysOnTarget.' / '.$periodDays,'#28a745']] as $s): ?>
  <div class="col-md-3 col-6">
    <div class="card-stat"><div class="stat-icon"><i class="<?=$s[0]?>" style="color:<?=$s[3]?>"></i></div><div class="stat-value" style="color:<?=$s[3]?>;font-size:1.4rem"><?=$s[2]?></div><div class="stat-label"><?=$s[1]?></div></div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Charts Row 1 -->
<div class="row g-4 mb-4">
  <div class="col-lg-8">
    <div class="chart-container">
      <div class="section-title"><i class="fas fa-fire me-2"></i>Calorie Intake vs Goal</div>
      <canvas id="calLineChart" height="80"></canvas>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="chart-container">
      <div class="section-title"><i class="fas fa-chart-pie me-2"></i>Meal Type Distribution</div>
      <canvas id="mealTypePie" height="180"></canvas>
    </div>
  </div>
</div>

<!-- Charts Row 2 -->
<div class="row g-4 mb-4">
  <div class="col-lg-6">
    <div class="chart-container">
      <div class="section-title"><i class="fas fa-tint me-2"></i>Water Intake Trend</div>
      <canvas id="waterChart" height="100"></canvas>
    </div>
  </div>
</div>

<?php if(count($bmiVals)>1): ?>
<div class="chart-container mb-4">
  <div class="section-title"><i class="fas fa-weight me-2"></i>BMI Trend</div>
  <canvas id="bmiChart" height="60"></canvas>
</div>
<?php endif; ?>

<!-- Food Category Breakdown -->
<?php
$catRes=$conn->query("SELECT f.category, COALESCE(SUM(mp.calories),0) as total FROM meal_plans mp JOIN foods f ON mp.food_id=f.id WHERE mp.user_id=$uid AND mp.plan_date>='$startDate' GROUP BY f.category");
$catLabels=[]; $catData=[];
while($c=$catRes->fetch_assoc()){$catLabels[]=$c['category'];$catData[]=$c['total'];}
?>
<?php if($catData): ?>
<div class="row g-4">
  <div class="col-lg-6">
    <div class="chart-container">
      <div class="section-title"><i class="fas fa-utensils me-2"></i>Food Category Breakdown</div>
      <canvas id="catChart" height="140"></canvas>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="card-gold">
      <div class="section-title"><i class="fas fa-star me-2"></i>Top Foods This Period</div>
      <?php
      $topFoods=$conn->query("SELECT f.name,COUNT(*) as cnt,SUM(mp.calories) as total FROM meal_plans mp JOIN foods f ON mp.food_id=f.id WHERE mp.user_id=$uid AND mp.plan_date>='$startDate' GROUP BY f.id ORDER BY cnt DESC LIMIT 5");
      while($tf=$topFoods->fetch_assoc()): ?>
      <div class="d-flex justify-content-between align-items-center mb-3">
        <div style="font-weight:600;font-size:0.9rem"><?=htmlspecialchars($tf['name'])?></div>
        <div class="d-flex gap-3">
          <span class="text-muted-gold" style="font-size:0.8rem"><?=$tf['cnt']?>x</span>
          <span class="gold-text" style="font-weight:700;font-size:0.85rem"><?=round($tf['total'])?> kcal</span>
        </div>
      </div>
      <?php endwhile; ?>
    </div>
  </div>
</div>
<?php endif; ?>

<script>
const goldGradient=(ctx,alpha=0.3)=>{const g=ctx.createLinearGradient(0,0,0,300);g.addColorStop(0,`rgba(255,215,0,${alpha})`);g.addColorStop(1,'rgba(255,215,0,0)');return g;};
const chartDefaults={responsive:true,plugins:{legend:{labels:{color:'#aaa'}}},scales:{y:{grid:{color:'rgba(255,215,0,0.05)'},ticks:{color:'#aaa'}},x:{grid:{display:false},ticks:{color:'#aaa',maxRotation:45}}}};

const ctx1=document.getElementById('calLineChart').getContext('2d');
new Chart(ctx1,{type:'line',data:{labels:<?=json_encode($labels)?>,datasets:[{label:'Calories',data:<?=json_encode($calData)?>,borderColor:'#FFD700',backgroundColor:goldGradient(ctx1),fill:true,tension:0.4,pointBackgroundColor:'#FFD700',pointRadius:4},{label:'Goal (<?=$calGoal?>)',data:Array(<?=$periodDays?>).fill(<?=$calGoal?>),borderColor:'rgba(220,53,69,0.7)',borderDash:[6,4],pointRadius:0,fill:false}]},options:chartDefaults});

<?php
$mtRes=$conn->query("SELECT meal_type,COUNT(*) as cnt FROM meal_plans WHERE user_id=$uid AND plan_date>='$startDate' GROUP BY meal_type");
$mtLabels=[]; $mtData=[];
while($mt=$mtRes->fetch_assoc()){$mtLabels[]=ucfirst($mt['meal_type']);$mtData[]=$mt['cnt'];}
?>
new Chart(document.getElementById('mealTypePie'),{type:'doughnut',data:{labels:<?=json_encode($mtLabels)?>,datasets:[{data:<?=json_encode($mtData)?>,backgroundColor:['rgba(255,215,0,0.8)','rgba(40,167,69,0.8)','rgba(23,162,184,0.8)','rgba(255,193,7,0.8)'],borderWidth:2}]},options:{cutout:'55%',plugins:{legend:{labels:{color:'#aaa'}}}}});

new Chart(document.getElementById('waterChart'),{type:'bar',data:{labels:<?=json_encode($labels)?>,datasets:[{label:'Water (ml)',data:<?=json_encode($waterData)?>,backgroundColor:'rgba(23,162,184,0.4)',borderColor:'#17a2b8',borderWidth:2,borderRadius:6}]},options:chartDefaults});

<?php if(count($bmiVals)>1): ?>
new Chart(document.getElementById('bmiChart'),{type:'line',data:{labels:<?=json_encode($bmiDates)?>,datasets:[{label:'BMI',data:<?=json_encode($bmiVals)?>,borderColor:'#FFD700',backgroundColor:'rgba(255,215,0,0.1)',fill:true,tension:0.4,pointBackgroundColor:'#FFD700',pointRadius:5}]},options:chartDefaults});
<?php endif; ?>

<?php if($catData): ?>
new Chart(document.getElementById('catChart'),{type:'bar',data:{labels:<?=json_encode($catLabels)?>,datasets:[{label:'Calories',data:<?=json_encode($catData)?>,backgroundColor:'rgba(255,215,0,0.4)',borderColor:'#FFD700',borderWidth:2,borderRadius:8}]},options:{...chartDefaults,indexAxis:'y'}});
<?php endif; ?>

function exportReport(){
    const w=window.open('','_blank','width=800,height=600');
    w.document.write(`
        <html><head><title>NutriGold Report</title>
        <style>body{font-family:Arial;background:#111;color:#fff;padding:30px} h1{color:#FFD700} table{width:100%;border-collapse:collapse} th{background:#222;color:#FFD700;padding:10px} td{padding:10px;border-bottom:1px solid #333;color:#aaa}</style></head>
        <body><h1>🏆 NutriGold Health Report</h1>
        <p>Period: Last <?=$periodDays?> days | Generated: <?=date('M j, Y')?></p>
        <table><tr><th>Metric</th><th>Value</th></tr>
        <tr><td>Avg Daily Calories</td><td><?=$avgCal?> kcal</td></tr>
        <tr><td>Avg Water Intake</td><td><?=$avgWater?> ml</td></tr>
        <tr><td>Days On Target</td><td><?=$daysOnTarget?> / <?=$periodDays?> days</td></tr>
        </table>
        <script>window.onload=()=>window.print()<\/script></body></html>
    `);
}
</script>

<?php require_once 'includes/footer.php'; ?>
