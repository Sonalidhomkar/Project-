<?php
// ====================================
// FORGOT PASSWORD PAGE
// ====================================
session_start();
require_once 'includes/db.php';

$msg = ''; $err = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = sanitize($conn, $_POST['email']);
    $res = $conn->query("SELECT * FROM users WHERE email='$email'");
    if ($res->num_rows > 0) {
        $token = bin2hex(random_bytes(32));
        $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
        $conn->query("UPDATE users SET reset_token='$token',reset_expires='$expires' WHERE email='$email'");
        // In real app: send email with reset link
        // mail($email, "Password Reset - NutriGold", "Click here to reset: http://yoursite.com/reset-password.php?token=$token");
        $msg = "Password reset link has been sent to your email! (Token: $token — copy for demo)";
    } else {
        $err = "No account found with this email address.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Forgot Password | NutriGold</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="auth-wrapper">
  <div class="auth-card animate-in">
    <div class="auth-logo"><i class="fas fa-lock-open me-2"></i>Reset Password</div>
    <h2 class="auth-title">Forgot Password?</h2>
    <p class="auth-subtitle">Enter your email and we'll send you a reset link</p>
    <?php if($msg): ?><div class="alert-success-dark mb-4"><i class="fas fa-check-circle me-2"></i><?=$msg?></div><?php endif; ?>
    <?php if($err): ?><div class="alert-danger-dark mb-4"><i class="fas fa-exclamation-circle me-2"></i><?=$err?></div><?php endif; ?>
    <form method="POST">
      <div class="mb-4">
        <label class="form-label">Email Address</label>
        <div class="input-group">
          <span class="input-group-text"><i class="fas fa-envelope"></i></span>
          <input type="email" name="email" class="form-control" placeholder="Enter your email" required>
        </div>
      </div>
      <button type="submit" class="btn-gold btn w-100 mb-3"><i class="fas fa-paper-plane me-2"></i>Send Reset Link</button>
    </form>
    <p class="text-center text-muted-gold" style="font-size:0.88rem">
      Remember your password? <a href="login.php" style="color:var(--gold);text-decoration:none">Back to Login</a>
    </p>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
