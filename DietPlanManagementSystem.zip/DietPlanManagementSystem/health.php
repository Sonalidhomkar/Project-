<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Health Check</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body{background:#0A0A0A;color:#fff;font-family:'Poppins';padding:20px}
        .status-ok{color:#28a745}
        .status-error{color:#dc3545}
        .status-warning{color:#ffc107}
        .health-item{background:#111;border:1px solid rgba(255,215,0,0.3);border-radius:8px;padding:15px;margin:10px 0}
        h1{color:#FFD700;margin-bottom:20px}
    </style>
</head>
<body>
    <div class="container">
        <h1><i class="fas fa-heartbeat"></i> System Health Check</h1>
        
        <div class="health-item">
            <h5>Server Information</h5>
            <p><strong>Server Software:</strong> <?= htmlspecialchars($_SERVER['SERVER_SOFTWARE']) ?></p>
            <p><strong>PHP Version:</strong> <?= phpversion() ?></p>
            <p><strong>Current URL:</strong> <?= htmlspecialchars("http://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}") ?></p>
        </div>

        <div class="health-item">
            <h5>Database Connection</h5>
            <?php
            require_once 'includes/db.php';
            if ($conn && !$conn->connect_error) {
                echo '<p class="status-ok"><i class="fas fa-check-circle"></i> Database connected successfully</p>';
                echo '<p><strong>Database Host:</strong> ' . DB_HOST . '</p>';
                echo '<p><strong>Database Name:</strong> ' . DB_NAME . '</p>';
            } else {
                echo '<p class="status-error"><i class="fas fa-times-circle"></i> Database connection failed</p>';
                if ($conn) echo '<p>' . htmlspecialchars($conn->connect_error) . '</p>';
            }
            ?>
        </div>

        <div class="health-item">
            <h5>File System</h5>
            <?php
            $files = ['includes/db.php', 'includes/header.php', 'includes/footer.php', 'css/style.css', 'js/script.js'];
            foreach ($files as $file) {
                $status = file_exists($file) ? '<span class="status-ok"><i class="fas fa-check"></i></span>' : '<span class="status-error"><i class="fas fa-times"></i></span>';
                echo "<p>$status $file</p>";
            }
            ?>
        </div>

        <div class="health-item">
            <h5>Available Pages</h5>
            <?php
            $pages = ['index.php', 'login.php', 'register.php', 'dashboard.php', 'profile.php', 'report.php', 'calories.php', 'water.php', 'food.php', 'mealplanner.php', 'diet.php', 'bmi.php', 'premium.php', 'feedback.php'];
            foreach ($pages as $page) {
                $status = file_exists($page) ? '<span class="status-ok"><i class="fas fa-check"></i></span>' : '<span class="status-error"><i class="fas fa-times"></i></span>';
                echo "<p>$status <a href=\"$page\" style=\"color:#FFD700\">$page</a></p>";
            }
            ?>
        </div>

        <div class="health-item">
            <h5>Session Information</h5>
            <?php
            if (isset($_SESSION['user_id'])) {
                echo '<p class="status-ok"><i class="fas fa-user"></i> User logged in (ID: ' . htmlspecialchars($_SESSION['user_id']) . ')</p>';
            } else {
                echo '<p class="status-warning"><i class="fas fa-user-slash"></i> No user session</p>';
            }
            
            if (isset($_SESSION['admin_id'])) {
                echo '<p class="status-ok"><i class="fas fa-shield-alt"></i> Admin logged in (ID: ' . htmlspecialchars($_SESSION['admin_id']) . ')</p>';
            } else {
                echo '<p class="status-warning"><i class="fas fa-user-slash"></i> No admin session</p>';
            }
            ?>
        </div>

        <div class="health-item">
            <h5>Recent Errors (if any)</h5>
            <p><small>Check your server error logs for more details: <code>C:\xampp\apache\logs\error.log</code></small></p>
        </div>

        <a href="index.php" class="btn btn-primary mt-3"><i class="fas fa-home"></i> Go to Home</a>
        <a href="dashboard.php" class="btn btn-success mt-3"><i class="fas fa-chart-bar"></i> Go to Dashboard</a>
    </div>
</body>
</html>
